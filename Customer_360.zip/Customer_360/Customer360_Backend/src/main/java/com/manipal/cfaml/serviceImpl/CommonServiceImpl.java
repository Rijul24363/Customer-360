package com.manipal.cfaml.serviceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.entity.EmployeeDetails;
import com.manipal.cfaml.repository.AccountRelationRepository;
import com.manipal.cfaml.repository.CommonRepo;
import com.manipal.cfaml.repository.CountryCodeRepository;
import com.manipal.cfaml.repository.EmployeeDetailsRepo;
import com.manipal.cfaml.repository.KycMasterDataRepository;
import com.manipal.cfaml.service.CommonService;

@Service
public class CommonServiceImpl implements CommonService {

	@Autowired
	private CommonRepo commonRepo;

	@Autowired
	private EmployeeDetailsRepo employeeDetailsRepo;

	@Autowired
	AccountRelationRepository accRelRepo;

	@Autowired
	KycMasterDataRepository kycMasRepo;

	@Autowired
	CountryCodeRepository countryCodeRepo;

	@Override
	public List<EmployeeDetails> getEmployeeListExceptEmpId(String userId) {

		return employeeDetailsRepo.getEmployeeListExceptEmpId(userId);
	}

	@Override
	public Map<String, Object> getEnum() {
		Map<String, Object> datas = new HashMap<>();
		try {
			datas.put("countryList", countryCodeRepo.findAll());
			datas.put("accountTypeList", commonRepo.getAllAccountTypeList());
			datas.put("currencyList", commonRepo.getCurrency());
			datas.put("maritalStatusList", commonRepo.maritalStatus());
			datas.put("educationList", commonRepo.getEducationList());
			datas.put("docTypeList", commonRepo.getIdentificationType());
			datas.put("accStatusList", commonRepo.accountStatus());
			datas.put("natureOfBusinessList", commonRepo.getNatureOfBusiness());
			datas.put("getBusinessList", accRelRepo.findAll());
			datas.put("accStatusTypeList", commonRepo.accountStatusType());

			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datas;
	}

	@Override
	public List<Map<String, Object>> getKycMasterData() {
		return kycMasRepo.getKycMasterData();
	}

	@Override
	public List<Map<String, Object>> getBranchList() {
		return commonRepo.getBranchList();
	}

}
