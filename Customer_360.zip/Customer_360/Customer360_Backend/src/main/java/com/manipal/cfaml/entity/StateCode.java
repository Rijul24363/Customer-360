package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name="STATE_CODE")
public class StateCode {
	
	@Id
	@Column(name = "STATE_NAME")
	private String stateCode;

	@Column(name = "CODE")
	private String code;
	
//	
//	@Id
//	@Column(name = "Pincode")
//	private String pinCode;
//	
//	@Column(name = "officetype")
//	private String officeType;
//	
//	@Column(name = "CITYCODE")
//	private Integer cityCode;	
//	
//	@Column(name = "CITYHQCD")
//	private Integer cityHQCD;
//	
//	@Column(name = "District")
//	private String district;
	
}
