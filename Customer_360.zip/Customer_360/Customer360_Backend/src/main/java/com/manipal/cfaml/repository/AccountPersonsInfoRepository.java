package com.manipal.cfaml.repository;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.manipal.cfaml.entity.AccountPersonsInfo;


@Repository
public interface AccountPersonsInfoRepository extends JpaRepository<AccountPersonsInfo, String> {
	List<AccountPersonsInfo> findBycustomerId(String customerId);

	@Query(nativeQuery=true, value="select id, concat(First_Name,' ',Middle_Name, ' ', last_name)as fullName,'' as relation,\r\n"
			+ "mobile_Number as contactNumber, FORMAT(date_of_birth,'yyyy-MM-dd') as dob, Pcity_name as pCity, Pstate as pState,\r\n"
			+ "pcountry, paddress1 , paddress2 ,paddress3 , paddress4, \r\n"
			+ " tcity_name as tCity, tstate as tState,\r\n"
			+ "tcountry, taddress1 , taddress2 ,taddress3 , taddress4 , identification_doc_issue_country ,\r\n"
			+ "identification_doc_issued_by ,FORMAT(identification_doc_issued_date,'yyyy-MM-dd') as identification_doc_issued_date, identification_doc_type,"
			+ "sIdentification_doc_type,sIdentification_doc_number,FORMAT(sIdentification_doc_issued_date,'yyyy-MM-dd')as sIdentification_doc_issued_date,sIdenification_doc_issued_by,"
			+ "FORMAT(sIdentification_doc_expiry_date,'yyyy-MM-dd') sIdentification_doc_expiry_date,sIdentification_doc_issue_country, "
			+"FORMAT(identification_doc_expiry_date,'yyyy-MM-dd') identification_doc_expiry_date," 
			+"identification_doc_number,api.cbs_account_person_role_type,api.GPLUS_CODE as gPlusCode,api.pzipcode,api.tzipcode,api.P_GPLUS_CODE as pgPlusCode,api.cbs_party_role_type as cbsPartyRoleType \r\n"
			+ "from entprod.ACCOUNT_PERSONS_INFO api where ACCOUNT_ID  like :accountId \r\n"
			+ "and customer_id = :customerId and cbs_party_role_type = :cbsPartyRoleType")
	List<Map<String,Object>> findByCustomerIdAndAccountIdAndCbsPartyRoleType(String customerId, String accountId, String cbsPartyRoleType);
	
	@Query(nativeQuery=true, value="select c from AccountPersonsInfo c  where c.customerId = :customerId and c.accountId =:accountId")
	AccountPersonsInfo getDetailsByCustomerIdAndAccountId(String customerId,String accountId);
	
	Optional<AccountPersonsInfo> findById(String id);

	
	@Query(nativeQuery=true, value="select account_id,cbs_party_role_type,id, concat(First_Name,' ',Middle_Name, ' ', last_name)as fullName,'' as relation,\r\n"
			+ "mobile_Number as contactNumber, FORMAT(date_of_birth,'yyyy-MM-dd') as dob, Pcity_name as pCity, Pstate as pState,\r\n"
			+ "pcountry, paddress1 , paddress2 ,paddress3 , paddress4, \r\n"
			+ " tcity_name as tCity, tstate as tState,\r\n"
			+ "tcountry, taddress1 , taddress2 ,taddress3 , taddress4 , identification_doc_issue_country ,\r\n"
			+ "identification_doc_issued_by ,FORMAT(identification_doc_issued_date,'yyyy-MM-dd') as identification_doc_issued_date, identification_doc_type,"
			+ "sIdentification_doc_type,sIdentification_doc_number,FORMAT(sIdentification_doc_issued_date,'yyyy-MM-dd')as sIdentification_doc_issued_date,sIdenification_doc_issued_by,"
			+ "FORMAT(sIdentification_doc_expiry_date,'yyyy-MM-dd') sIdentification_doc_expiry_date,sIdentification_doc_issue_country, "
			+ "identification_doc_number,api.cbs_account_person_role_type,api.GPLUS_CODE as gPlusCode,api.pzipcode,api.tzipcode,api.P_GPLUS_CODE as pgPlusCode,FORMAT(identification_doc_expiry_date,'yyyy-MM-dd') identification_doc_expiry_date \r\n"
			+ "from entprod.ACCOUNT_PERSONS_INFO api where  \r\n"
			+ "customer_id = :customerId")
	List<Map<String,Object>> findByCustomerIdForPdf(String customerId);
}
