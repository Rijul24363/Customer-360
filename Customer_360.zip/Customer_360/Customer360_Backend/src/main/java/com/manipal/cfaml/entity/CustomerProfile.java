package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name="CUSTOMER_PROFILE")
public class CustomerProfile {
	
	@Id
	@Column(name = "ACCOUNT_ID")
	private String accountId;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Column(name = "TITLE")
	private String title;
	
	@Column(name = "FIRST_NAME")
	private String firstName;
	
	@Column(name = "MIDDLE_NAME")
	private String middleName;
	
	@Column(name = "LAST_NAME")
	private String lastName;
	
	@Column(name = "CUST_TYPE")
	private String custType;
	
	@Column(name = "PAN_NUMBER")
	private String panNo;
	
	@Column(name = "PEP")
	private String pep;
	
	@Column(name = "FATCA")
	private String fatca;
	
	@Column(name = "PRODUCT_TYPE")
	private String productType;
	
	@Column(name = "MARITAL_STATUS_DESCRIPTION")
	private String maritalStatusDiscription;
	
	@Column(name = "RESIDENCE")
	private String residence;
	
	@Column(name = "SEX")
	private String sex;
	
	@Column(name = "DATE_OF_BIRTH")
	private Date dateOfBirth;
	
	@Column(name = "NATIONALITY")
	private String nationality;
	
	@Column(name = "INCORPORATION_ISSUED_COUNTRY")
	private String incoporationIssuedCountry;
	
	@Column(name = "INCORPORATION_NUMBER")
	private String incorporationNumber;
	
	@Column(name = "INCORPORATION_ISSUED_BY")
	private String incoprporationIssuedBy;
	
	@Column(name = "pan_issue_date")
	private Date panIssueDate;
	
	@Column(name = "COUNTRY")
	private String country;
	
	@Column(name = "country_prefix")
	private String countryPrefix;
	
	@Column(name = "TELEPHONE_NUMBER")
	private String landlineNumber;
	
	@Column(name = "MOBILE_NUMBER")
	private String mobileNumber;
	
	@Column(name = "EMAIL_ID")
	private String emailId;
	
	@Column(name = "CURRENCY_TYPE")
	private String currencyType;
	
	@Column(name = "ACCOUNT_STATUS_TYPE")
	private String accountStatusType;
	
	@Column(name = "branch_code")
	private String branchCode;
	
	@Column(name = "ACCOUNT_TYPE")
	private String accountType;
	
	@Column(name = "ACCOUNT_NAME")
	private String accountName;
	
	@Column(name = "PROFILE_CREATIONDATE")
	private Date profileCreationDate;
	
	@Column(name = "OVERDRAFT_LIMIT")
	private String overDraftLimit;
	
	@Column(name = "ACC_PURPOSE")
	private String purposeOfAccount;
	
	@Column(name = "work_experience")
	private String workExperience;
	
	@Column(name = "EMP_DEPT")
	private String department;
	
	@Column(name = "source_wealth")
	private String sourceOfWealth;
	
	@Column(name = "EMP_CONTACT_NO")
	private String employersContactNumber;
	
	@Column(name = "source_income")
	private String sourceOfIncome;
	
	@Column(name = "net_worth")
	private String netWorth;
	
	@Column(name = "education_level")
	private String educationLevel;
	
	@Column(name = "employer_name")
	private String nameOfTheEmployer;
	
	@Column(name = "employer_business")
	private String nameOfBusiness;
	
	@Column(name = "sector_code")
	private String typeOfBusiness;
	
	@Column(name = "alias")
	private String alias;
	
	@Column(name = "designation")
	private String designation;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "CRR")
	private String crr;
	
	@Column(name = "branch_id")
	private String branchId;
	
	@Column(name = "child_name")
	private String childName;

	@Column(name = "identification_doc_type")
	private String identificationDocType;

	@Column(name = "identification_doc_number")
	private String identificationDocNumber;

	@Column(name = "identification_doc_issued_by")
	private String idenificationDocIssuedBy;

	@Column(name = "identification_doc_issued_date")
	private Date identificationDocIssuedDate;

	@Column(name = "identification_doc_expiry_date")
	private Date identificationDocExpiredDate;

	@Column(name = "identification_doc_issue_country")
	private String identificationDocIssueCountry;

	@Column(name = "SIdentification_doc_type")
	private String sIdentificationDocType;

	@Column(name = "SIdentification_doc_number")
	private String sIdentificationDocNumber;

	@Column(name = "SIdenification_doc_issued_by")
	private String sIdenificationDocIssuedBy;

	@Column(name = "SIdentification_doc_issued_date")
	private Date sIdentificationDocIssuedDate;

	@Column(name = "SIdentification_doc_expiry_date")
	private Date sIdentificationDocExpiredDate;

	@Column(name = "SIdentification_doc_issue_country")
	private String sIdentificationDocIssueCountry;
	
	@Column(name = "grandmother_name")
	private String grandMotherName;
	
	@Column(name = "FATHERS_NAME")
	private String fatherName;
	
	@Column(name = "grandfather_name")
	private String grandFatherName;
	
	@Column(name = "SPOUSE_NAME")
	private String spouseName;
	
	@Column(name = "MOTHERS_NAME")
	private String motherName;
	
	@Column(name = "website")
	private String website;
	
	@Column(name = "TURNOVER")
	private String turnover;
	
	@Column(name = "ACCOUNT_RELATION")
	private String accountRelation;
	
	@Column(name = "ACCOUNT_STATUS")
	private String accountStatus;
	
	@Column(name = "INCOME")
	private String income;
	
	@Column(name = "KYC_STATUS")
	private String kycStatus;
	
	@Column(name = "LAST_KYC_DATE")
	private Date lastKycDate;
}