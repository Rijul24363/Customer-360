package com.manipal.cfaml.service;

import java.util.List;
import java.util.Map;

import com.manipal.cfaml.entity.RiskIndicator;

/**
 * @author Rahul Rathod
 *
 * 
 */

public interface RiskRatingService {

	List<Map<String,Object>>  getComputationInfo(String custID, String accId, String startDate, String endDate);

	List<RiskIndicator> getRiskIndicatorData();

}
