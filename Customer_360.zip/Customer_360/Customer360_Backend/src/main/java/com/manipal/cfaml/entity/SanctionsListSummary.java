package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "SANCTIONSLISTSUMMARY")
public class SanctionsListSummary {

	@Id
	@Column(name = "SD_ACCOUNT_ID")
	private String sdAccountId;

	@Column(name = "CREATEDDATE")
	private Date sdCreateDate;

	@Column(name = "SD_LIST_NAME")
	private String sdListName;

	@Column(name = "SD_SCORE")
	private String sdScore;

	@Column(name = "SD_CUSTOMER_ID")
	private String sdCustomerId;

	@Column(name = "SFDC_FIELD_MATCHED")
	private String sfdcFieldMatched;

	@Column(name = "SD_FIELD_MATCHED")
	private String sdFieldMatched;

	@Column(name = "SFDC_CONTENT_MATCHED")
	private String sfdcContentmatched;

	@Column(name = "SD_CONTENT_MATCHED")
	private String sdContentMatched;

	@Column(name = "SD_VERSION")
	private String sdVersion;

	@Column(name = "SD_MATCHEDID")
	private String sdMatchedId;

	@Column(name = "WATCHLIST_MATCH")
	private String watchlistMatch;

//	@Column(name = "REQUEST_DATE_TIME")
//	private Date RequestDateTime;

	@Column(name = "TEXT_SCORE")
	private String textScore;

	@Column(name = "PHONETIC_SCORE")
	private String PhoneticScore;

	@Column(name = "RECOMMENDATION")
	private String recommendation;

	@Column(name = "COMMENTS")
	private String comments;

	@Column(name = "CUSTOMER_TYPE")
	private String customerType;

	@Column(name = "OTHER_DETAILS")
	private String otherDetails;

	@Column(name = "PERCENTAGE_SCORE")
	private String percentageScore;
}
