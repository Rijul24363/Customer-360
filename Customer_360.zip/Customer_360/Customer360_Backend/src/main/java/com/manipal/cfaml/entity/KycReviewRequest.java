package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "KYC_REVIEW_REQUEST", schema = "VIZPROD")
public class KycReviewRequest {
	
	@Id
	@Column(name = "REQUEST_ID")
	private Long requestId;

	@Column(name = "ACCOUNT_ID")
	private String accountId;
	
	@Column(name = "APPROVED_BY")
	private String approvedBy;
	
	@Column(name = "APPROVED_DATE")
	private Date approvedDate;
	
	@Column(name = "COMMENT")
	private String comment;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Column(name = "FIELDS_UPDATED")
	private String fieldsUpdated;

	@Column(name = "SCREEN_NAME")
	private String screenName;
	
	@Column(name = "STATUS")
	private String status;

	@Column(name = "CBSACCOUNTID")
	private String cbsAccountId;

	@Column(name = "IDENTIFICATIONID")
	private String identificationId;
}
