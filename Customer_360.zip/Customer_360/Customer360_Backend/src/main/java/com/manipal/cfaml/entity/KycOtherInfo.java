package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@NoArgsConstructor(force = true)
@AllArgsConstructor
@Builder
@Table(name = "KYC_OTHER_INFO")
public class KycOtherInfo {

	@Id
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "account_id")
	private String accountId;

	@Column(name = "service_availed")
	private String serviceAvailed;

	@Column(name = "customer_liability_report")
	private String customerLiabilityReport;

	@Column(name = "other_report")
	private String otherReport;
}
