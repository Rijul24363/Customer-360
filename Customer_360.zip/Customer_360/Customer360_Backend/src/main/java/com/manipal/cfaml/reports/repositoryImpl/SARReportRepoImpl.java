package com.manipal.cfaml.reports.repositoryImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.manipal.cfaml.reports.repository.SARReportRepository;

@Component
public class SARReportRepoImpl implements SARReportRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Map<String, Object>> getSuspiciousActivityReport(String customerId, String fromDate, String toDate,
			String scenarioName, String branchName, String status) {

		List<Map<String, Object>> scenariorprt = new ArrayList<>();

		try {

			String query = "	SELECT	ocd.CASE_ID as caseId,ocd.Account_ID as accountId ,\r\n"
					+ "			ocd.CUSTOMER_ID as customerId ,\r\n"
					+ "			COALESCE(ocd.TITLE ,'')+' '+COALESCE(ocd.FIRST_NAME,'')+' '+COALESCE(ocd.MIDDLE_NAME ,'')+' '+COALESCE(ocd.LAST_NAME ,'') as name,\r\n"
					+ "			ocd.STATUS as status, ocd.CREATED_BY as createdBy from\r\n"
					+ "			VIZPROD.OFFLINE_CASE_DETAILS ocd  where "
					+ "			ocd.event_date_time between CONVERT(DATETIME,'$2 00:00:00',120) and CONVERT(DATETIME,'$3 23:59:59',120) "
					+ "		$accId $scenario $branchName $status";

			query = query.replace("$2", fromDate);
			query = query.replace("$3", toDate);
			if (customerId != null && customerId.trim().length() != 0) {
				query = query.replace("$accId", " and ocd.CUSTOMER_ID ='" + customerId + "'");
			} else {
				query = query.replace("$accId", "");
			}

			if (scenarioName != null && scenarioName.trim().length() != 0) {
				query = query.replace("$scenario", " and ocd.scenario_id ='" + scenarioName + "'");
			} else {
				query = query.replace("$scenario", "");
			}

			if (branchName != null && branchName.trim().length() != 0) {
				query = query.replace("$branchName", " and ocd.event_branch ='" + branchName + "'");
			} else {
				query = query.replace("$branchName", "");
			}

			if (status != null && status.trim().length() != 0) {
				query = query.replace("$status", " and ocd.status='" + status + "'");
			} else {
				query = query.replace("$status", "");
			}

			scenariorprt = jdbcTemplate.queryForList(query);

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return scenariorprt;
	}

	@Override
	public HashMap<String, Object> scenarioAndBranchDetails() {
		HashMap<String, Object> returnOb = new HashMap<>();
		String scenrioQuery = "select id, CONCAT(code,' - ' ,name) as codeName from VIZPROD.offline_scenario_pool order by name";

		String branchQuery = "select distinct BRANCH_ID as id,BRANCH_NAME_SHRT as name from "
				+ " ENTPROD.branch_list order by " + "BRANCH_NAME_SHRT ASC";
		List<Map<String, Object>> scenrioQueryData = jdbcTemplate.queryForList(scenrioQuery);
		List<Map<String, Object>> branchQueryData = jdbcTemplate.queryForList(branchQuery);

		returnOb.put("scenarioList", scenrioQueryData);
		returnOb.put("branchList", branchQueryData);
		return returnOb;
	}

	@Override
	public ArrayList<HashMap<String, Object>> getPersonInfo(String accountPersonInfo, String custType,
			String customerId, String accountId) {
		ArrayList<HashMap<String, Object>> returnData = new ArrayList<>();
		try {
			String query = null;
			if (accountPersonInfo.equalsIgnoreCase("director")) {
				query = "SELECT (CASE WHEN LOWER(GENDER)= 'male' THEN 'M' WHEN LOWER(GENDER)= 'female' THEN 'F' ELSE 'T' END) AS GENDER ,\r\n"
						+ "identification_doc_number AS id_number, Title, First_Name, Middle_Name, last_name, \r\n"
						+ "convert(varchar,date_of_birth,120) as date_of_birth, mother_name, Spouse_Name as alias, \r\n"
						+ "ssn_citizenship, FATHER_NAME as birth_place, PASSPORT_NO, passport_country, \r\n"
						+ "Id, isnull(( select cc.COUNTRY_ALPHA2 FROM ENTPROD.COUNTRY_CODE cc \r\n"
						+ "WHERE cc.NATIONALITY = api.nationality),api.nationality) as nationality, \r\n"
						+ "RESIDENCE, mobile_Number as phone_number, Telephone_Number, \r\n"
						+ "CONCAT(Paddress1, ' ' ,Paddress2, ' ' , Paddress3, ' ', Paddress4) as PAddress, \r\n"
						+ "Pcity_name as PCity, pcountry as PCountry, Paddress2 as PZipCode, pcity_name as PTown, \r\n"
						+ "pstate as PState, CONCAT(taddress1, ' ' , taddress2 ,' ' , taddress3, ' ', taddress4) as TAddress, \r\n"
						+ "tcity_name as TCity, tcountry as TCountry, taddress2 as TZipCode, tcity_name as TTown, tstate as TState , \r\n"
						+ "occupation, (case when (select git.Value from entprod.GOAML_IDENTIFIER_TYPE git \r\n"
						+ "where trim(identification_doc_type)=trim(git.Description)) is not null then (select git.Value from entprod.GOAML_IDENTIFIER_TYPE git \r\n"
						+ "where trim(identification_doc_type)=trim(git.Description)) else 'Z' end) as identification_doc_type, identification_doc_number, \r\n"
						+ "identification_doc_issued_by as idenification_doc_issued_by, convert(varchar,identification_doc_issued_date,120) as issued_date,\r\n"
						+ "convert(varchar,identification_doc_expiry_date,126) as expiry_date, \r\n"
						+ "identification_doc_issue_country, grand_father_name as tax_reg_number, \r\n"
						+ "Title, prefix, Spouse_Name as alias, (select cc.COUNTRY_ALPHA2  \r\n"
						+ "FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = api.nationality2) as nationality2, \r\n"
						+ "(select cc.COUNTRY_ALPHA2  FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = api.nationality3) as nationality3, \r\n"
						+ "email_id, (case upper(deceased) when 'Y' then 1 else null end) as deceased, convert(varchar,deceased_date,120) as deceased_date, \r\n"
						+ "convert(varchar,pan_issue_date,126) as tax_number, source_income, comments, commercial_name, website as URL, \r\n"
						+ "business_closed, convert(varchar,business_closed_date,126) as business_closed_date, PAN_NUMBER as tax_number_tentity, \r\n"
						+ "convert(varchar,pan_issue_date,126) as tax_reg_number_tentity, employer_name, \r\n"
						+ "(CASE WHEN cbs_party_role_type = 'BOD' THEN 'A' END) AS ROLE,api.identification_doc_comments \r\n"
						+ "FROM ENTPROD.ACCOUNT_PERSONS_INFO api where cbs_party_role_type = 'BOD' AND \r\n"
						+ "account_id in $ACCOUNT_ID "
						+ "order by api.Id,api.First_Name,api.Middle_Name,api.last_name";
			} else if (accountPersonInfo.equalsIgnoreCase("signatory") && custType.equalsIgnoreCase("Individual")) {
				query = "SELECT CASE WHEN LOWER(cp.SEX)= 'male' THEN 'M' WHEN LOWER(cp.SEX)= 'female' THEN 'F' ELSE 'T' END AS GENDER ,	\r\n"
						+ "cp.First_Name,	cp.Middle_Name,	cp.last_name, CONVERT(VARCHAR,cp.date_of_birth ,120) as birthdate,\r\n"
						+ "cp.FATHERS_NAME  as birth_place, cp.MOTHERS_NAME  as mother_name, cp.SOCIAL_SECURITY_NO as ssn, \r\n"
						+ "(select cc.COUNTRY_ALPHA2  FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = cp.nationality) as nationality , \r\n"
						+ "a.PCOUNTRY as residence, cp.MOBILE_NUMBER as mobile_Number,TELEPHONE_NUMBER, \r\n"
						+ "CONCAT(a.PADDRESS1 , ' ', a.PADDRESS2 , ' ', a.PADDRESS3 , ' ' , a.PADDRESS4) AS PAddress, \r\n"
						+ "a.PADDRESS4 as PCity, a.PCOUNTRY  as PCountry,a.PADDRESS2 as PZipCode, a.pcity_name as PTown, \r\n"
						+ "a.pstate as PState, CONCAT(a.ADDRESS1 , ' ', a.ADDRESS2 , ' ', a.ADDRESS3 , ' ' , a.ADDRESS4)  as TAddress, \r\n"
						+ "a.ADDRESS4 as TCity, a.COUNTRY  as TCountry,a.ADDRESS2 as TZipCode, a.city_name as TTown, \r\n"
						+ "a.state as TState,cp.JOB_TYPE_DESCRIPTION as occupation,\r\n"
						+ "(case when (select git.Value from entprod.GOAML_IDENTIFIER_TYPE git \r\n"
						+ "where trim(identification_doc_type)=trim(git.Description)) is not null \r\n"
						+ "then (select git.Value from entprod.GOAML_IDENTIFIER_TYPE git \r\n"
						+ "where trim(identification_doc_type)=trim(git.Description)) else 'Z' end) \r\n"
						+ "AS id_type,cp.identification_doc_number as id_number,identification_doc_issued_by as Issued_by, \r\n"
						+ "convert(varchar,identification_doc_issued_date,126) as issued_date, \r\n"
						+ "convert(varchar,identification_doc_expiry_date,126) as expiry_date, identification_doc_issue_country as Issued_Country , \r\n"
						+ "Title, prefix, Spouse_Name as alias, PASSPORT_NO, passport_country, \r\n"
						+ "(select cc.COUNTRY_ALPHA2  FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = cp.nationality2) as nationality2, \r\n"
						+ "(select cc.COUNTRY_ALPHA2  FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = cp.nationality3) as nationality3, \r\n"
						+ "email_id, (case upper(deceased) when 'Y' then 1 else null end) as deceased, \r\n"
						+ "convert(varchar,deceased_date,120) as deceased_date, convert(varchar,pan_issue_date,126) as tax_number, \r\n"
						+ "GRANDFATHER_NAME as tax_reg_number, source_income, comments, commercial_name, website as URL, business_closed, \r\n"
						+ "convert(varchar,business_closed_date,120) as business_closed_date, PAN_NUMBER as tax_number_tentity, \r\n"
						+ "convert(varchar,pan_issue_date,126) as tax_reg_number_tentity, employer_name , emp_mobile_no, \r\n"
						+ "EMP_CONTACT_NO, CONCAT(a.EMPADDRESS1 , ' ', a.EMPADDRESS2 , ' ', a.EMPADDRESS3 , ' ' , a.EMPADDRESS4) AS EMPAddress, \r\n"
						+ "a.EMPADDRESS4 as EMPCity, a.EMPCOUNTRY  as EMPCountry,a.EMPADDRESS2 as EMPZipCode, a.EMPCITY_NAME as EMPTown, \r\n"
						+ "a.EMPSTATE as EMPState, 'A' AS ROLE, cp.source_wealth,cp.identification_doc_comments FROM ENTPROD.CUSTOMER_PROFILE cp,	\r\n"
						+ "ENTPROD.ADDRESS a WHERE cp.CUSTOMER_ID =a.ADDRESS_ID and cp.CUSTOMER_ID = '" + customerId+ "'";
			} else {
				query = "SELECT CASE WHEN LOWER(GENDER)='male' THEN 'M' WHEN LOWER(GENDER)='female' THEN 'F' ELSE 'T' END AS GENDER ,\r\n"
						+ "First_Name,Middle_Name,last_name,CONVERT(VARCHAR(10),date_of_birth ,120) as birthdate,\r\n"
						+ "Father_Name as birth_place,mother_name,ssn_citizenship as ssn,(select cc.COUNTRY_ALPHA2  \r\n"
						+ "FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = api.nationality) as nationality ,pcountry as residence,\r\n"
						+ "mobile_Number,Telephone_Number AS TELEPHONE_NUMBER,CONCAT(PADDRESS1 , ' ', PADDRESS2 , ' ', PADDRESS3 , ' ' , PADDRESS4) as PAddress,\r\n"
						+ "PADDRESS4 as PCity,pcountry as PCountry,Paddress2 as PZipCode, pcity_name as PTown, pstate as PState, \r\n"
						+ "CONCAT(taddress1,' ',taddress2,' ',taddress3,' ',taddress4) as TAddress,taddress4 as TCity,tcountry as TCountry,taddress2 as TZipCode, \r\n"
						+ "tcity_name as TTown, tstate as TState,occupation, \r\n"
						+ "(case when (select git.Value from entprod.GOAML_IDENTIFIER_TYPE git where \r\n"
						+ "trim(identification_doc_type)=trim(git.Description)) is not null then \r\n"
						+ "(select git.Value from entprod.GOAML_IDENTIFIER_TYPE git where trim(identification_doc_type)=trim(git.Description)) else 'Z' end) \r\n"
						+ " AS id_type,identification_doc_number AS id_number,identification_doc_issued_by as Issued_by, \r\n"
						+ " convert(varchar,identification_doc_issued_date,126) as issued_date, \r\n"
						+ " convert(varchar,identification_doc_expiry_date,126) as expiry_date, \r\n"
						+ " identification_doc_issue_country as Issued_Country , Title, prefix, Spouse_Name as alias, \r\n"
						+ " PASSPORT_NO, passport_country, (select cc.COUNTRY_ALPHA2  FROM ENTPROD.COUNTRY_CODE cc \r\n"
						+ " WHERE cc.NATIONALITY = api.nationality2) as nationality2, (select cc.COUNTRY_ALPHA2  \r\n"
						+ " FROM ENTPROD.COUNTRY_CODE cc WHERE cc.NATIONALITY = api.nationality3) as nationality3, email_id, \r\n"
						+ " (case upper(deceased) when 'Y' then 1 else null end) as deceased, convert(varchar(10),deceased_date,120) as deceased_date,\r\n"
						+ " convert(varchar,pan_issue_date,126) as tax_number, grand_father_name as tax_reg_number, source_income, comments, commercial_name,\r\n"
						+ " website as URL, business_closed, convert(varchar(10),business_closed_date,120) as business_closed_date, \r\n"
						+ " PAN_NUMBER as tax_number_tentity, convert(varchar,pan_issue_date,126) as tax_reg_number_tentity, \r\n"
						+ " CASE WHEN cbs_party_role_type = 'Signatory' THEN 'A' END AS ROLE, api.identification_doc_comments \r\n"
						+ " FROM ENTPROD.ACCOUNT_PERSONS_INFO api where cbs_party_role_type = 'Signatory' AND account_id in $ACCOUNT_ID \r\n"
						+ " order by api.Id,api.First_Name,api.Middle_Name,api.last_name";
			}
			if (accountId != null && accountId.trim().length()!=0) {
				query = query.replace("$ACCOUNT_ID", "('" + accountId + "')");
			} else {
				query = query.replace("$ACCOUNT_ID",
						"(Select DISTINCT  ACCOUNT_ID  from ENTPROD.ACCOUNT_PERSONS_INFO cp where CUSTOMER_ID = '"
								+ customerId + "')");
			}

			List<Map<String, Object>> rsData = jdbcTemplate.queryForList(query);
			for (Map<String, Object> map : rsData) {
				HashMap<String, Object> accData = new HashMap<>();
				if (accountPersonInfo.equalsIgnoreCase("Director")) {
					accData.put("gender", map.get("GENDER"));
					accData.put("title", map.get("Title"));
					accData.put("first_name", map.get("FIRST_NAME"));
					accData.put("middle_name", map.get("MIDDLE_NAME"));
					accData.put("last_name", map.get("LAST_NAME"));
					accData.put("date_of_birth", map.get("date_of_birth"));
					accData.put("mother_name", map.get("mother_name"));
					accData.put("alias", map.get("alias"));
					accData.put("ssn_citizenship", map.get("ssn_citizenship"));
					accData.put("passport_no", map.get("PASSPORT_NO"));
					accData.put("passport_country", map.get("passport_country"));
					accData.put("id", map.get("Id"));
					accData.put("nationality", map.get("nationality"));
					accData.put("residence", map.get("RESIDENCE"));
					accData.put("phone_number", map.get("phone_number"));
					accData.put("telephone_number", map.get("Telephone_Number"));
					accData.put("pAddress", map.get("PAddress"));
					accData.put("pCity", map.get("PCity"));
					accData.put("pCountry", map.get("PCountry"));
					accData.put("pZipCode", map.get("PZipCode"));
					accData.put("pTown", map.get("PTown"));
					accData.put("pState", map.get("PState"));
					accData.put("tAddress", map.get("TAddress"));
					accData.put("tCity", map.get("TCity"));
					accData.put("tCountry", map.get("TCountry"));
					accData.put("tZipCode", map.get("TZipCode"));
					accData.put("tTown", map.get("TTown"));
					accData.put("tState", map.get("TState"));
					accData.put("email_id", map.get("email_id"));
					accData.put("occupation", map.get("occupation"));
					accData.put("identification_doc_type", map.get("identification_doc_type"));
					accData.put("identification_doc_number", map.get("identification_doc_number"));
					accData.put("idenification_doc_issued_by", map.get("idenification_doc_issued_by"));
					accData.put("issued_date", map.get("issued_date"));
					accData.put("expiry_date", map.get("expiry_date"));
					accData.put("identification_doc_issue_country", map.get("identification_doc_issue_country"));
					accData.put("tax_reg_number", map.get("tax_reg_number"));
					accData.put("id_number", map.get("id_number"));
					accData.put("employer_name", map.get("employer_name"));
					accData.put("title", map.get("Title"));
					accData.put("prefix", map.get("prefix"));
					accData.put("alias", map.get("alias"));
					accData.put("passport_country", map.get("passport_country"));
					accData.put("nationality2", map.get("nationality2"));
					accData.put("nationality3", map.get("nationality3"));
					accData.put("email_id", map.get("email_id"));
					accData.put("deceased", map.get("deceased"));
					accData.put("deceased_date", map.get("deceased_date"));
					accData.put("pan_number", map.get("tax_number"));
					accData.put("tax_number", map.get("tax_number_tentity"));
					accData.put("grand_father_name", map.get("tax_reg_number"));
					accData.put("source_income", map.get("source_income"));
					accData.put("comments", map.get("comments"));
					accData.put("tax_reg_number", map.get("tax_reg_number_tentity"));
					accData.put("birth_place", map.get("birth_place"));
					accData.put("role", map.get("ROLE"));
					accData.put("identification_doc_comments", map.get("identification_doc_comments"));

				} else if (accountPersonInfo.equalsIgnoreCase("Signatory")) {
					accData.put("gender", map.get("GENDER"));
					accData.put("first_name", map.get("FIRST_NAME"));
					accData.put("middle_name", map.get("MIDDLE_NAME"));
					accData.put("last_name", map.get("LAST_NAME"));
					accData.put("birthdate", map.get("birthdate"));
					accData.put("birth_place", map.get("birth_place"));
					accData.put("mother_name", map.get("mother_name"));
					accData.put("ssn_citizenship", map.get("ssn"));
					accData.put("passport_no", map.get("PASSPORT_NO"));
					accData.put("nationality", map.get("nationality"));
					accData.put("residence", map.get("residence"));
					accData.put("mobile_Number", map.get("mobile_Number"));
					accData.put("telephone_no", map.get("TELEPHONE_NUMBER"));
					accData.put("pAddress", map.get("PAddress"));
					accData.put("pCity", map.get("PCity"));
					accData.put("pCountry", map.get("PCountry"));
					accData.put("pZipCode", map.get("PZipCode"));
					accData.put("pTown", map.get("PTown"));
					accData.put("pState", map.get("PState"));
					accData.put("tAddress", map.get("TAddress"));
					accData.put("tCity", map.get("TCity"));
					accData.put("tCountry", map.get("TCountry"));
					accData.put("tZipCode", map.get("TZipCode"));
					accData.put("tTown", map.get("TTown"));
					accData.put("tState", map.get("TState"));
					accData.put("occupation", map.get("occupation"));
					accData.put("identification_doc_type", map.get("id_type"));
					accData.put("identification_doc_number", map.get("id_number"));
					accData.put("idenification_doc_issued_by", map.get("Issued_by"));
					accData.put("issued_date", map.get("issued_date"));
					accData.put("identification_doc_issue_country", map.get("Issued_Country"));
					accData.put("expiry_date", map.get("expiry_date"));
					accData.put("role", map.get("ROLE"));
					accData.put("title", map.get("Title"));
					accData.put("prefix", map.get("prefix"));
					accData.put("alias", map.get("alias"));
					accData.put("passport_country", map.get("passport_country"));
					accData.put("nationality2", map.get("nationality2"));
					accData.put("nationality3", map.get("nationality3"));
					accData.put("email_id", map.get("email_id"));
					accData.put("deceased", map.get("deceased"));
					accData.put("deceased_date", map.get("deceased_date"));
					accData.put("pan_number", map.get("tax_number"));
					accData.put("tax_number", map.get("tax_number_tentity"));
					accData.put("grand_father_name", map.get("tax_reg_number"));
					accData.put("source_income", map.get("source_income"));
					accData.put("comments", map.get("comments"));
					accData.put("tax_reg_number", map.get("tax_reg_number_tentity"));
					try {
						accData.put("source_wealth", map.get("source_wealth"));
					} catch (Exception e) {
						accData.put("source_wealth", null);
					}
					accData.put("identification_doc_comments", map.get("identification_doc_comments"));
					if (custType.equalsIgnoreCase("Individual")) {
						accData.put("employer_name", map.get("employer_name"));
						accData.put("emp_mobile_no", map.get("emp_mobile_no"));
						accData.put("emp_telephone_no", map.get("EMP_CONTACT_NO"));
						accData.put("emp_address", map.get("EMPAddress"));
						accData.put("emp_city", map.get("EMPCity"));
						accData.put("emp_country", map.get("EMPCountry"));
						accData.put("emp_zip_code", map.get("EMPZipCode"));
						accData.put("emp_town", map.get("EMPTown"));
						accData.put("emp_state", map.get("EMPState"));
					}

				}

				returnData.add(accData);
			}

		} catch (Exception e) {
		}
		return returnData;
	}

	@Override
	public Map<String, Object> getEntityData(String customerId, String accountId) {
		String query="	select top 1 cp.ACCOUNT_NAME as name, commercial_name, LEGAL_FORM_TYPE as legal_form , INCORPORATION_NUMBER as incorp_no,\r\n"
				+ "	JOB_TYPE_DESCRIPTION as busniess, EMAIL_ID as email_id,	website as url,	cp.INCORPORATION_ISSUED_BY as incor_state,\r\n"
				+ "	INCORPORATION_ISSUED_COUNTRY as incorp_country_code,	TAX_ID as tax_no,	CONVERT(VARCHAR(10),DATE_OF_BIRTH,120) as incor_date,\r\n"
				+ "	business_closed ,	 CONVERT(VARCHAR(10),business_closed_date,120) as business_closed_date,	"
				+ "	CONVERT(VARCHAR(10),cp.pan_issue_date,120) as tax_reg_no,	COMMENTS as comments,\r\n"
				+ "	MOBILE_NUMBER as mobile_no,	TELEPHONE_NUMBER as landline, "
				+ "	CONCAT(ad.ADDRESS1 , ' ' , ad.ADDRESS2 , ' ', ad.ADDRESS3 , ' ' , ad.ADDRESS4) as c_address , \r\n"
				+ "	ad.ADDRESS4 as c_city, ad.STATE as c_state,	ad.CITY_NAME as c_town, ad.ZIPCODE as c_zip_code, ad.COUNTRY as c_country,\r\n"
				+ "	CONCAT(ad.PADDRESS1 , ' ' , ad.PADDRESS2 , ' ', ad.PADDRESS3 , ' ' , ad.PADDRESS4) as p_address , \r\n"
				+ "	ad.PADDRESS4 as p_city, ad.PSTATE as p_state,	ad.PCITY_NAME as p_town, ad.PZIPCODE as p_zip_code, ad.PCOUNTRY as p_country \r\n"
				+ "	from ENTPROD.customer_profile cp inner join ENTPROD.ADDRESS ad on cp.CUSTOMER_ID = ad.ADDRESS_ID\r\n"
				+ "	and cp.CUSTOMER_ID = '"+customerId+"' $accid" ;
		if (accountId != null && accountId.trim().length()!=0) {
			query = query.replace("$accid", " and cp.ACCOUNT_ID='"+accountId+"'");
		} else {
			query =  query.replace("$accid", "");
		}
		
		return jdbcTemplate.queryForMap(query);
	}

	@Override
	public Map<String, Object> getAccountDetails(String customerId, String accountId) {
		String query="SELECT top 1 gc.INSTITUTION_NAME as institution_name,gc.INSTITUTION_CODE  as institution_code,\r\n"
				+ "cp.non_banking_inst, cp.BRANCH_ID as branch_id,cp.ACCOUNT_ID as account_id, cp.CURRENCY_TYPE as currency_type,\r\n"
				+ "cp.ACCOUNT_NAME as account_name , cp.IBAN as iban , cp.CLIENT_NUMBER as client_no, cp.ACCOUNT_TYPE as account_type,\r\n"
				+ "CONVERT(VARCHAR(10),cp.PROFILE_CREATIONDATE,120) as acc_opened ,f.CURRENTBALANCE as acc_balance, CONVERT(VARCHAR(10),f.TRANSACTION_DATE_TIME,120) as date_balance,\r\n"
				+ "cp.ACCOUNT_STATUS_TYPE as acc_status, cp.beneficiary , cp.beneficiary_comment ,cp.COMMENTS  as comments "
				+ "from GOAML_CONFIGURATION gc,\r\n"
				+ "ENTPROD.CUSTOMER_PROFILE cp left join (select top 1 * from ENTPROD.FINANCIAL_TRANSACTION ft where ft.TRANSACTION_DATE_TIME  <= GETDATE() ORDER BY ft.TRANSACTION_DATE_TIME  desc) f on f.ACCOUNT_ID  = cp.ACCOUNT_ID \r\n"
				+ "where cp.ACCOUNT_ID ='"+accountId+"' and cp.CUSTOMER_ID='"+customerId+"'";
	
		
		return jdbcTemplate.queryForMap(query);
	}
	
	@Override
	public Map<String, Object> GoAmlConfigurationDetails() {
		String query="SELECT top 1 * from GOAML_CONFIGURATION gc";	
		return jdbcTemplate.queryForMap(query);
	}

	@Override
	public List<Map<String, Object>> getReportIndicatorsList() {
		String query="SELECT  * from VIZPROD.REPORT_INDICATORS";	
		return jdbcTemplate.queryForList(query);
	}
	

}
