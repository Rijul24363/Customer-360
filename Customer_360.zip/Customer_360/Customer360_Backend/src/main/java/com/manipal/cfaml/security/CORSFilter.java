package com.manipal.cfaml.security;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CORSFilter implements WebMvcConfigurer {
	  @Autowired
	  private TokenInterceptor tokenInterceptor;
	  
		@Value("${corsUrls}")
		private ArrayList<String> corsUrls;
	  
	@Override
	public void addCorsMappings(CorsRegistry registry) {
	    registry.addMapping("/**").allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS");
	    corsConfigurer();
	}
	@Bean
	public WebMvcConfigurer corsConfigurer()
	{
	   String[] allowDomains=new String[corsUrls.size()];
	   for (int i = 0; i < corsUrls.size(); i++) {
		   allowDomains[i]=corsUrls.get(i);
		   System.out.println("CORS configuration...."+corsUrls.get(i));
	   }

	   return new WebMvcConfigurer() {
	      @Override
	      public void addCorsMappings(CorsRegistry registry) {
	         registry.addMapping("/**").allowedOrigins(allowDomains);
	      }
	   };
	}


	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(tokenInterceptor).addPathPatterns("/**");
	}
}