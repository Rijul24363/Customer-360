package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.manipal.cfaml.entity.SanctionsListSummary;

public interface SanctionsListSummaryRepository extends JpaRepository<SanctionsListSummary, String> {
	
	@Query(nativeQuery = true, value = "SELECT TOP 1 s.SD_CUSTOMER_ID, s.SD_SCORE "
	        + "FROM vizprod.SANCTIONSLISTSUMMARY s "
	        + "WHERE s.SD_CUSTOMER_ID = :custId "
	        + "ORDER BY s.CREATEDDATE ")	        
	Map<String, Object> getSanctionScoreForCustomerDetails(String custId);
	
	@Query(nativeQuery=true, value="SELECT\r\n"
	        + "    s.SD_LIST_NAME AS listName,(s.SD_SCORE*100)/1.4 as sdScore,\r\n"
	        + "    COUNT(*) AS count\r\n"
	        + "FROM\r\n"
	        + "    VIZPROD.SANCTIONSLISTSUMMARY s\r\n"
	        + "WHERE\r\n"
	        + "    SD_SCORE >= 1.4\r\n"
	        + "    AND SD_CUSTOMER_ID = :custId\r\n"
	        + "    AND s.CREATEDDATE BETWEEN :startDate AND :endDate\r\n"
	        + "GROUP BY\r\n"
	        + "    s.SD_LIST_NAME,\r\n"
	        + "    s.CREATEDDATE,s.SD_SCORE;")
	List<Map<String, Object>> getSanctionListDetails(@Param("custId") String custId, @Param("startDate") String startDate, @Param("endDate") String endDate);

}
