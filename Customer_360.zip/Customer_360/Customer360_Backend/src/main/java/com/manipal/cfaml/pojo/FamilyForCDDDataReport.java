package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class FamilyForCDDDataReport {
	private String motherName;
	private String fatherName;
	private String grandMotherName;
	private String grandFatherName;
	private String spouseName;
	private String daughterFullName;
	private String sonFullName;
	private String daughterFullName2;
	private String sonFullName2;
}
