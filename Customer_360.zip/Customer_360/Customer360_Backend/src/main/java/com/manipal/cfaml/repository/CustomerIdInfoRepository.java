package com.manipal.cfaml.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.manipal.cfaml.entity.CustomerIdInfo;

public interface CustomerIdInfoRepository extends JpaRepository<CustomerIdInfo, Long> {
	
	@Query(nativeQuery = true, value = "SELECT c.ID_NUMBER, c.ID_ISSUED_BY, c.ID, c.PRIMARY_ID, c.ID_TYPE, c.ID_EXPIRY_DATE, c.ID_ISSUE_DATE, c.ID_ISSUE_COUNTRY, c.CUSTOMER_ID FROM customer_id_info c WHERE c.CUSTOMER_ID = :custId")
	List<Map<String, Object>> getByCustomerId(@Param("custId") String custId);

	Optional<CustomerIdInfo> findById(Long id);	
	
	@Query(nativeQuery=true, value="Select TOP 1 krr.ID FROM customer_id_info krr ORDER BY ID DESC")
	BigInteger latestCount();
	
}
