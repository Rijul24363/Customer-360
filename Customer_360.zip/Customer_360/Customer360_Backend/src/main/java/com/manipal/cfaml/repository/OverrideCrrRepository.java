package com.manipal.cfaml.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.OverrideCrr;

public interface OverrideCrrRepository  extends JpaRepository<OverrideCrr,String>{

	@Query(nativeQuery=true, value="select Top 1 * from VIZPROD.OVERRIDE_CRR c where CUSTOMER_ID = :custId")
	OverrideCrr getOverrideCrrListDetails(String custId);
	
	OverrideCrr findFirstByCustomerIdOrderByOverrideDateDesc(String customerId);

}
