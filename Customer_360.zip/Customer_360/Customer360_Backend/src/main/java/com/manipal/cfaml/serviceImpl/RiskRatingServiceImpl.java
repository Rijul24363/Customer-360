package com.manipal.cfaml.serviceImpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.entity.RiskIndicator;
import com.manipal.cfaml.repository.CrrComputationInfoRepository;
import com.manipal.cfaml.repository.RiskIndicatorRepository;
import com.manipal.cfaml.service.RiskRatingService;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Service
public class RiskRatingServiceImpl implements RiskRatingService {
	
	@Autowired
	CrrComputationInfoRepository crrComputationInfoRepo;
	
	@Autowired
	RiskIndicatorRepository riskIndicatorRepo;

	@Override
	public List<Map<String,Object>>  getComputationInfo(String custID, String accId, String startDate, String endDate) {
		startDate=startDate;
		endDate=endDate+" 23:59:59.000";
		return crrComputationInfoRepo.fetchDataByCustomerIdAndAccountIdAndDateRange(custID, accId,startDate,endDate); 
	}

	@Override
	public List<RiskIndicator> getRiskIndicatorData() {
		return riskIndicatorRepo.findByStatus("A");
	}

}
