package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class RevenueForCDDDataReport {
	private String nameOfTheEmployer;
	private String designation;
	private String employerLineOfBusiness;
	private String workExperience;
	private String department;
	private String regularSourceOfIncome;
	private String sourceOfWealth;
	private String netWorth;
	private String panNumber;
	private String employersContactNumber;
	private String city;
	private String country;
	private String state;
	private String nameOfBusiness;
	private String typeOfBusiness;
	private String lineOfBusiness;
	private String contactNumber;
	private String nameOfProvider;
	private String sourceOfIncomeOfTheProvider;
	private String status;
	private String parmanentLandlineNumber;
	private String parmanentCountry;
	private String parmanentProvince;
	private String parmanentHouseNumber;
	private String parmanentzipCode;
	private String parmanentDistrict;
	private String parmanentGooglePlusCode;
	private String parmanentMobileNumber;
	private String parmanentTole;
	private String parmanentState;
	private String parmanentEmailAddress;
	private String parmanentmnVdcCity;
	private String parmanentCountryCode;
}
