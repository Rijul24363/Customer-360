package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface CustomerRepositoryCustom {
	public List<Map<String, Object>> findForSearchPanel(String query); 
	
	public int getTTRCount(String customerID, String accountiD, String frmDate, String toDate);
		
	public Map<String, Integer> cddCountQuery(Map<String, Set<String>> ob);

	Map<String,Object> getCDDDataStatus(Map<String, Set<String>> tableColumns, String startFrom, String dtInputFields);

	Map<String,Object> getCRRData(String crr,Integer startFrom,String dtInputFields);

	List<Map<String, Object>> getTransModeFundType(String custId, String startDate, String endDate);

	List<Map<String, Object>> getTransModeFundType(String custId, String accountId, String startDate, String endDate);

	public Map<String, Object> getCustomerTopData(String custID, String accountId);
}
