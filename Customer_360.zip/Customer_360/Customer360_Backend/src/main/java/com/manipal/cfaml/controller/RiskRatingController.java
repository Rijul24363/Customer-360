package com.manipal.cfaml.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.entity.RiskIndicator;
import com.manipal.cfaml.service.RiskRatingService;

/**
 * @author Rahul Rathod
 *
 * 
 */
@RequestMapping("riskrating")
@RestController
public class RiskRatingController {

	@Autowired 
	private RiskRatingService riskRatingService;
	
	
	@GetMapping("/getRiskIndicatorData")
	public List<RiskIndicator> getRiskIndicatorData() {
		return riskRatingService.getRiskIndicatorData();
	}
	
	@GetMapping("/getComputationInfo")
	public List<Map<String,Object>>  getComputationInfo(@RequestParam(required = false, name="customerId")String custID,
			@RequestParam(required = false, name="accountId")String accId,
			@RequestParam(required = false, name="startDate") String startDate, 
			@RequestParam(required = false, name="endDate")String endDate) {
		return riskRatingService.getComputationInfo(custID,accId,startDate,endDate);
	}
}
