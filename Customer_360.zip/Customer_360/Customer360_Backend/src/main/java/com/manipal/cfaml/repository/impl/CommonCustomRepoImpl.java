package com.manipal.cfaml.repository.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.manipal.cfaml.repository.CommonRepo;

@Component
public class CommonCustomRepoImpl implements CommonRepo {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Map<String, Object>> getAllAccountTypeList() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.ACCOUNT_TYPE";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("value", (String) record[0]);
			data.put("description", (String) record[1]);
			object.add(data);
		});
		return object;
	}

	@Override
	public List<Map<String, Object>> getNatureOfBusiness() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.SECTOR_MASTER";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("code", (String) record[0]);
			data.put("description", (String) record[1]);
			object.add(data);
		});
		return object;
	}

	@Override
	public List<Map<String, Object>> getEducationList() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.EDUCATION_QUALIFICATION_MASTER";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("code", (String) record[0]);
			data.put("name", (String) record[1]);
			object.add(data);
		});
		return object;
	}

	@Override
	public List<Map<String, Object>> getIdentificationType() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.GOAML_IDENTIFIER_TYPE";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("code", (String) record[0]);
			data.put("name", (String) record[1]);
			object.add(data);
		});
		return object;
	}
	
	@Override
	public List<Map<String, Object>> getCurrency() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT CRCD,DESCR FROM ENTPROD.CURRENCY_CODE";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("code", (String) record[0]);
			data.put("name", (String) record[1]);
			object.add(data);
		});
		return object;
	}
	
	@Override
	public List<Map<String, Object>> maritalStatus() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.MARITAL_STATUS";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("code", (String) record[0]);
			data.put("name", (String) record[1]);
			object.add(data);
		});
		return object;
	}

	@Override
	public List<Map<String, Object>> accountStatus() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.ACCOUNT_STATUS";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("code", (String) record[0].toString());
			data.put("name", (String) record[1]);
			object.add(data);
		});
		return object;
	}
	
	@Override
	public List<Map<String, Object>> accountStatusType() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "SELECT * FROM ENTPROD.GOAML_ACCT_STATUS_TYPE";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("value", (String) record[0].toString());
			data.put("description", (String) record[1]);
			object.add(data);
		});
		return object;
	}

	@Override
	public List<Map<String, Object>> getBranchList() {
		List<Map<String, Object>> object = new ArrayList<>();
		String query = "Select BRANCH_ID as id, BRANCH_NAME as name from ENTPROD.BRANCH_LIST bl";
		Query nativeQuery = entityManager.createNativeQuery(query);
		List<Object[]> query2 = nativeQuery.getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("id", (String) record[0].toString());
			data.put("name", (String) record[1]);
			object.add(data);
		});
		return object;
	}
}
