package com.manipal.cfaml.serviceImpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.repository.KycReviewRequestRepositoy;
import com.manipal.cfaml.service.HistoryViewService;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Service
public class HistoryViewServiceImpl implements HistoryViewService {

	@Autowired
	KycReviewRequestRepositoy kycReviewRequestRepo;

	@Override
	public List<Map<String, Object>> getHistoryViewInfo(String custID, String accId, String startDate, String endDate) {
		startDate = startDate + " 00:00:00.000";
		endDate = endDate + " 23:59:59.000";
		return kycReviewRequestRepo.getKycReviewRequestByCustIdAndAccId(custID);
	}

}
