package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "RISKINDICATOR")
public class RiskIndicator {

	@Id
	@Column(name = "RISKINDICATOR_ID")
	private String riskIndicatorId;

	@Column(name = "RISK_INDICATOR_NAME")
	private String riskIndicatorName;

	@Column(name = "WEIGHTAGE")
	private String weightage;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "RISK_INDICATOR_REQUIREMENT")
	private String riskIndicatorRequirement;

	@Column(name = "WEIGHTAGE_CORPORATE")
	private String weightageCorporate;

	@Column(name = "WEIGHTAGE_LEGAL")
	private String weightageLegal;

	@Column(name = "STATIC_DYNAMIC")
	private String staticDynamic;
}
