package com.manipal.cfaml.serviceImpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.repository.SanctionsListSummaryRepository;
import com.manipal.cfaml.service.SanctionService;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Service
public class SanctionServiceImpl implements SanctionService {
	
	@Autowired
	SanctionsListSummaryRepository sanctionsListSummaryRepo;

	@Override
	public List<Map<String, Object>> getSanctionListInfo(String custID, String accId, String startDate, String endDate) {
//		startDate=startDate+" 00:00:00.000";
//		endDate=endDate+" 23:59:59.000";
		return sanctionsListSummaryRepo.getSanctionListDetails(custID,startDate,endDate);
	}

}
