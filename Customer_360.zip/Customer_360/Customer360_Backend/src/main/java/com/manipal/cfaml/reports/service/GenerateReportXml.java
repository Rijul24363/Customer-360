package com.manipal.cfaml.reports.service;

import java.io.ByteArrayOutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

public interface GenerateReportXml {

	ByteArrayOutputStream generateSARXml(HttpServletResponse response, Map<String, Object> data);
}
