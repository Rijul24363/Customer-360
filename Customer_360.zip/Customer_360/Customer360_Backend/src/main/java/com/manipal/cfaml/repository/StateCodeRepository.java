package com.manipal.cfaml.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.manipal.cfaml.entity.StateCode;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface StateCodeRepository extends JpaRepository<StateCode, String>{
	
	List<StateCode>findAll();
	
//	@Modifying
//	@Query("update StateCode c set c.cityHQCD = :cityCode where c.pinCode =:pinCode and c.district =:district and c.cityHQCD is null and c.officeType  <> 'HO'")
//	int updateData(Integer cityCode, String pinCode, String district);

}
