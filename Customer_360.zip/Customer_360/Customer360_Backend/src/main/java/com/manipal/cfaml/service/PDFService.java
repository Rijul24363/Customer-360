package com.manipal.cfaml.service;

import java.io.ByteArrayOutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

public interface PDFService {

	ByteArrayOutputStream cddDataReportPdfDownload(String custID,HttpServletResponse response, Map<String, Object> configFile, String e);

}
