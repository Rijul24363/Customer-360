package com.manipal.cfaml.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.service.CustomerService;
import com.manipal.cfaml.service.FinancialTransactionService;

@RequestMapping("customer")
@RestController
public class CustomerController {

	
	@Autowired 
	private CustomerService custService;
	
	@Autowired
	FinancialTransactionService financialTransactionService;

	@GetMapping("/getRiskDisrtibution")
	public Map<String,Object> getRiskDisrtibution(@RequestParam(required = false, name="custID")String custID) {
		return custService.getRiskDisrtibution();
	}
	
	@GetMapping("/customerSearch")
	public List<Map<String,Object>> searchCustomer(@RequestParam(required = false, name="custID")String custID,
			@RequestParam(required = false, name="custType")String custType,
			@RequestParam(required = false, name="custName")String custName,
			@RequestParam(required = false, name="panNo")String panNo) {
		return custService.searchCustomer(custID,custType,custName,panNo);
	}
	
	
	@GetMapping("/getCustomerDetailsForView")
	public Map<String,Object> getCustomerDetails(@RequestParam(required = false, name="custID")String custID) {
		return custService.getCustomerDetails(custID);
	}
	
	@GetMapping(value = "/getCustomerDetailsForCDD")
	public Map<String, Object> getCustomerDetailsForCDD(@RequestParam(name="custID")String custID) {
		return custService.getCustomerDetailsForCDD(custID);
	}
	
	@GetMapping(value = "/getAccountListByCustomerId")
	public List<String> getAccountListByCustomerId(@RequestParam String customerId) {
		return custService.getAccountListByCustomerId(customerId);
	}
	

	@GetMapping(value="/transactionDetails")
	public Map<String, Object> getTransactionDetailsBasedOnChannels(@RequestParam(name="startDate")String startDate,
			@RequestParam(name="endDate")String endDate,
			@RequestParam(name="custId")String customerId,
			@RequestParam(name="accountId")String accountId) throws ParseException {
		return financialTransactionService.getTransactionDetailsBasedOnChannels(customerId,startDate,endDate,accountId);
	}
	
	@GetMapping(value="/getAccountDetailsByCustIdAndAddId")
	public Map<String, Object> getAccountDetailsByCustIdAndAddId(@RequestParam String customerId,@RequestParam String accountId) {
		return custService.getAccountDetailsByCustIdAndAddId(customerId,accountId);
	}
	
	@GetMapping(value="/getCddDataBasedOnAccountId")
	public Map<String, Object> getCddDataBasedOnAccountId(@RequestParam String customerId,@RequestParam String accountId) {
		return custService.getCddDataBasedOnAccountId(customerId,accountId);
	}

	@PostMapping(value = "/updateCustomerData")
	public String saveSubmit(@RequestBody ArrayList<Map<String, String>> resData) throws ParseException, JSONException {

		for (Map<String, String> map : resData) {
			try {
				custService.saveSubmit(map);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return "Success";

	}

	@GetMapping(value="/getCRRData")
	public Map<String,Object> getCRRData(@RequestParam String crr, @RequestParam Integer startFrom,
			@RequestParam(required = false) String dtInputFields) {
		return custService.getCRRData(crr,startFrom,dtInputFields);
	}
	
	@GetMapping("/getCDDataCount")
	public Map<String,Integer> getCDDataCount() {
		return custService.getCDDataCount();
	}
	
	
	@GetMapping("/getCDDDataStatus")
	public Map<String,Object> getCDDDataStatus(@RequestParam String startFrom, @RequestParam(required = false, name="dtInputFields") String dtInputFields) {
		return custService.getCDDDataStatus(startFrom,dtInputFields);
	}
	
	@GetMapping("/customer_details")
	public Map<String,Object> getCustomerTopData(@RequestParam(required = false, name="customerId")String customerId,
			@RequestParam(required = false, name="accountId")String accountId) {
		return custService.getCustomerTopData(customerId,accountId);
	}
}
