package com.manipal.cfaml.reports.serviceImpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.itextpdf.io.source.ByteArrayOutputStream;
import com.manipal.cfaml.reports.repository.SARReportRepository;
import com.manipal.cfaml.reports.service.GenerateReportXml;

@Service
public class SARReportXmlImpl  implements GenerateReportXml{
	
	@Autowired
	SARReportRepository sarRepo;

	static SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    static SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd/MM/yyyy");

	@Override
	public ByteArrayOutputStream generateSARXml(HttpServletResponse response, Map<String, Object> data) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Map<String, Object> goamlDetails=  sarRepo.GoAmlConfigurationDetails();
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			doc.setXmlStandalone(true);
			doc.setXmlVersion("1.0");
			Element rootElement = doc.createElement("report");
			doc.appendChild(rootElement);

			goamlDetails.put("reportCode", "SAR");
			generateHeaders(doc, rootElement, goamlDetails);
			generateReportingPerson(doc, goamlDetails, rootElement, "SAR");
			List<Map<String, Object>> getPartyList=(List<Map<String, Object>>) data.get("partyList");
			Element activity =doc.createElement("activity"); 
			Element report_parties =doc.createElement("report_parties"); 
			for (int i = 0; i < getPartyList.size(); i++) {
				Map<String, Object> obData=getPartyList.get(i);
				Map<String, Object> mainData=(Map<String, Object>) obData.get("mainData");
				generateSARElements(doc,report_parties,obData,mainData.get("partyType").toString());
			}
			Map<String, Object> personRetrive=(Map<String, Object>) data.get("footerForm");
			Element reason = doc.createElement("reason");
			if(personRetrive.get("reason") !=null && personRetrive.get("reason").toString().trim().length()!=0) {	
				reason.appendChild(doc.createTextNode(personRetrive.get("reason").toString()));
				rootElement.appendChild(reason);
			}
			Element action = doc.createElement("action");
			if(personRetrive.get("action") !=null && personRetrive.get("action").toString().trim().length()!=0) {	
				action.appendChild(doc.createTextNode(personRetrive.get("action").toString()));
				rootElement.appendChild(action);
			}
			generateReportIndicators(doc, rootElement, (List<String>)personRetrive.get("reportIndicator"));
			activity.appendChild(report_parties);
			rootElement.appendChild(activity);
			doc.normalize();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	        DOMSource source = new DOMSource(doc);
	        StreamResult result = new StreamResult(baos);
	        transformer.transform(source, result);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return baos;
	}	
	

	static Document generateHeaders(Document doc,Element rootElement,Map<String, Object> headerData) throws DOMException, JSONException {
		
		Element rentity_id = doc.createElement("entity_id");
		rentity_id.appendChild(doc.createTextNode(headerData.get("INSTITUTION_CODE").toString()));
		rootElement.appendChild(rentity_id);
		Element rentity_branch = doc.createElement("entity_branch");
		rentity_branch.appendChild(doc.createTextNode(headerData.get("entity_branch").toString()));
		rootElement.appendChild(rentity_branch);
		Element submission_code = doc.createElement("submission_code");
		submission_code.appendChild(doc.createTextNode("E"));
		rootElement.appendChild(submission_code);
		Element report_code = doc.createElement("report_code");
		report_code.appendChild(doc.createTextNode(headerData.get("reportCode").toString()));
		rootElement.appendChild(report_code);
		Element entity_reference = doc.createElement("entity_reference");
		TimeZone timeZone = TimeZone.getTimeZone("GMT");
		DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		
		// Yash Start
		
		if(headerData.get("fiu_ref_number")!=null && headerData.get("fiu_ref_number").toString().trim()!="") {
			Element fiu_ref_number = doc.createElement("fiu_ref_number");
			fiu_ref_number.appendChild(doc.createTextNode(headerData.get("fiu_ref_number").toString()));
			rootElement.appendChild(fiu_ref_number);
		}
				
		date.setTimeZone(timeZone);
		String formattedDate = date.format(new Date());	
		entity_reference.appendChild(doc.createTextNode("GOAML_"+headerData.get("reportCode")+"_"+formattedDate));
		
		
		rootElement.appendChild(entity_reference);
		Element submission_date = doc.createElement("submission_date");
		TimeZone tz = TimeZone.getTimeZone("GMT");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		df.setTimeZone(tz);
		String nowAsISO = df.format(new Date());
		submission_date.appendChild(doc.createTextNode(nowAsISO));
		rootElement.appendChild(submission_date);
		Element currency_code_local = doc.createElement("currency_code_local");
		currency_code_local.appendChild(doc.createTextNode(headerData.get("reporting_currency").toString()));
		rootElement.appendChild(currency_code_local);
		return doc;
	}
	
	static Document generateReportingPerson(Document doc, Map<String, Object> jsonData,Element rootElement, String reportType) {
		try {
			Element reporting_person = doc.createElement("reporting_person");
			
			if(jsonData.get("Gender")!=null && !jsonData.get("Gender").toString().trim().equalsIgnoreCase("")) {
				Element gender = doc.createElement("gender");
				gender.appendChild(doc.createTextNode(jsonData.get("Gender").toString()));
				reporting_person.appendChild(gender);
			}
			
			if(jsonData.get("Title")!=null && !jsonData.get("Title").toString().trim().equalsIgnoreCase("")) {
				Element title = doc.createElement("title");
				title.appendChild(doc.createTextNode(jsonData.get("Title").toString()));
				reporting_person.appendChild(title);
			}
			
			Element first_name = doc.createElement("first_name");
			first_name.appendChild(doc.createTextNode(jsonData.get("FirstName").toString()));
			reporting_person.appendChild(first_name);
			
			if(jsonData.get("MiddleName")!=null && !jsonData.get("MiddleName").toString().trim().equalsIgnoreCase("")) {
				Element middle_name = doc.createElement("middle_name");
				middle_name.appendChild(doc.createTextNode(jsonData.get("MiddleName").toString()));
				reporting_person.appendChild(middle_name);
			}
			
			Element last_name = doc.createElement("last_name");
			last_name.appendChild(doc.createTextNode(jsonData.get("LastName").toString()));
			reporting_person.appendChild(last_name);
			
			if(jsonData.get("BIRTHDATE")!=null && !jsonData.get("BIRTHDATE").toString().trim().equalsIgnoreCase("")) {
				Element birthdate = doc.createElement("birthdate");
				Date date = inputDateFormat.parse(jsonData.get("BIRTHDATE").toString());
				birthdate.appendChild(doc.createTextNode(outputDateFormat.format(date)));
				reporting_person.appendChild(birthdate);
			}
			
			if(jsonData.get("BIRTH_PLACE")!=null && !jsonData.get("BIRTH_PLACE").toString().trim().equalsIgnoreCase("")) {
				Element birth_place = doc.createElement("birth_place");
				birth_place.appendChild(doc.createTextNode(jsonData.get("BIRTH_PLACE").toString()));
				reporting_person.appendChild(birth_place);
			}
			
			if(jsonData.get("MOTHERS_NAME")!=null && !jsonData.get("MOTHERS_NAME").toString().trim().equalsIgnoreCase("")) {
				Element mothers_name = doc.createElement("mothers_name");
				mothers_name.appendChild(doc.createTextNode(jsonData.get("MOTHERS_NAME").toString()));
				reporting_person.appendChild(mothers_name);
			}
			
			if(jsonData.get("ALIAS")!=null && !jsonData.get("ALIAS").toString().trim().equalsIgnoreCase("")) {
				Element alias = doc.createElement("alias");
				alias.appendChild(doc.createTextNode(jsonData.get("ALIAS").toString()));
				reporting_person.appendChild(alias);
			}
			//Bharat 14/8/2023 - if ssn is available and passport_country is not available then do not show passport and passport_country tag should not be shown
			if(jsonData.get("SSN")!=null && !jsonData.get("SSN").toString().trim().equalsIgnoreCase("")) {
				Element ssn = doc.createElement("ssn");
				ssn.appendChild(doc.createTextNode(jsonData.get("SSN").toString()));
				reporting_person.appendChild(ssn);
				if(jsonData.get("PassportNumber")!=null && !jsonData.get("PassportNumber").toString().trim().equalsIgnoreCase("")
					&& jsonData.get("PassportCountry")!=null && !jsonData.get("PassportCountry").toString().trim().equalsIgnoreCase("")) {
					Element passport_number = doc.createElement("passport_number");
					passport_number.appendChild(doc.createTextNode(jsonData.get("PassportNumber").toString()));
					reporting_person.appendChild(passport_number);
					Element passport_country = doc.createElement("passport_country");
					passport_country.appendChild(doc.createTextNode(jsonData.get("PassportCountry").toString()));
					reporting_person.appendChild(passport_country);
				}
			} else {
				Element ssn = doc.createElement("ssn");
				ssn.appendChild(doc.createTextNode("Not Available"));
				reporting_person.appendChild(ssn);
				
				if(jsonData.get("PassportNumber")!=null && !jsonData.get("PassportNumber").toString().trim().equalsIgnoreCase("")) {
					Element passport_number = doc.createElement("passport_number");
					passport_number.appendChild(doc.createTextNode(jsonData.get("PassportNumber").toString()));
					reporting_person.appendChild(passport_number);
					
					if(jsonData.get("PassportCountry")!=null && !jsonData.get("PassportCountry").toString().trim().equalsIgnoreCase("")) {
						Element passport_country = doc.createElement("passport_country");
						passport_country.appendChild(doc.createTextNode(jsonData.get("PassportCountry").toString()));
						reporting_person.appendChild(passport_country);
					} else {
						Element passport_country = doc.createElement("passport_country");
						passport_country.appendChild(doc.createTextNode("Not Available"));
						reporting_person.appendChild(passport_country);
					}
				}
			}
			
			
			if(jsonData.get("Nationality")!=null && !jsonData.get("Nationality").toString().trim().equalsIgnoreCase("")) {
				Element nationality1 = doc.createElement("nationality1");
				nationality1.appendChild(doc.createTextNode(jsonData.get("Nationality").toString()));
				reporting_person.appendChild(nationality1);
			}
			
			if(jsonData.get("RESIDENCE")!=null && !jsonData.get("RESIDENCE").toString().trim().equalsIgnoreCase("")) {
				Element residence = doc.createElement("residence");
				residence.appendChild(doc.createTextNode(jsonData.get("RESIDENCE").toString()));
				reporting_person.appendChild(residence);
			}
			
			Element phones = doc.createElement("phones");
			JSONArray jsonObjectPhones=null;
			if(jsonData.get("PHONES")!=null && jsonData.get("PHONES").toString().trim()!="") {
				jsonObjectPhones = new JSONArray(new JSONObject(jsonData.get("PHONES").toString()).get("phones").toString());
			}else {
				String nullJSON="[ {\"tph_contact_type\": \"5\",\"tph_communication_type\": \"M\",\"tph_country_prefix\": \"+977\",\"tph_number\": \"0\" }]";
				jsonObjectPhones = new JSONArray(nullJSON);
			}					
			
			for (int i = 0; i < jsonObjectPhones.length(); i++) {
				Element phone = doc.createElement("phone");
				JSONObject phoneOb=new JSONObject(jsonObjectPhones.get(i).toString());
				Element tph_contact_type = doc.createElement("tph_contact_type");
				String tph_contact_typeStr=phoneOb.get("tph_contact_type").toString();
				tph_contact_typeStr=tph_contact_typeStr.replaceAll("\"", "");
				tph_contact_type.appendChild(doc.createTextNode(tph_contact_typeStr));
				phone.appendChild(tph_contact_type);
				
				Element tph_communication_type = doc.createElement("tph_communication_type");
				String tph_communication_typeStr=phoneOb.get("tph_communication_type").toString();
				tph_communication_typeStr=tph_communication_typeStr.replaceAll("\"", "");
				tph_communication_type.appendChild(doc.createTextNode(tph_communication_typeStr));
				phone.appendChild(tph_communication_type);
				
				Element tph_country_prefix = doc.createElement("tph_country_prefix");
				String tph_country_prefixStr=phoneOb.get("tph_country_prefix").toString();
				tph_country_prefixStr=tph_country_prefixStr.replaceAll("\"", "");
				tph_country_prefix.appendChild(doc.createTextNode(tph_country_prefixStr));
				phone.appendChild(tph_country_prefix);
				
				if(phoneOb.get("tph_number")!=null && !phoneOb.get("tph_number").toString().trim().equalsIgnoreCase("")) {
					Element tph_number = doc.createElement("tph_number");
					String tph_numberStr=phoneOb.get("tph_number").toString();
					tph_numberStr=tph_numberStr.replaceAll("\"", "");
					if(tph_numberStr!=null && !tph_numberStr.trim().equalsIgnoreCase("") && !tph_numberStr.trim().equalsIgnoreCase("Not Available")) {
						tph_number.appendChild(doc.createTextNode(tph_numberStr));
					}else {
						tph_number.appendChild(doc.createTextNode("0"));
					}
					phone.appendChild(tph_number);
				}else {
					Element tph_number = doc.createElement("tph_number");
					tph_number.appendChild(doc.createTextNode("0"));
					phone.appendChild(tph_number);
				}
				phones.appendChild(phone);
			}
								
			reporting_person.appendChild(phones);
			
			Element addresses = doc.createElement("addresses");
			JSONArray jsonObjectAddresses =null;
			if(jsonData.get("address")!=null && jsonData.get("address")!="") {
				jsonObjectAddresses = new JSONArray(new JSONObject(jsonData.get("address").toString()).get("addresses").toString());
			}else {
				String nullJSON="[ {\"address_type\": \"4\",\"address\": \"Not Available\",\"town\": \"Not Available\",\"city\": \"Not Available\",\"zip\": \"Not Available\",\"country_code\": \"Not Available\",\"state\": \"Not Available\" }]";
				jsonObjectAddresses = new JSONArray(nullJSON);
			}
						
		
			for (int i = 0; i < jsonObjectAddresses.length(); i++) {
				Element address = doc.createElement("address");
				JSONObject addressOb=new JSONObject(jsonObjectAddresses.get(i).toString());
				
				Element address_type = doc.createElement("address_type");
				String address_typeStr=addressOb.get("address_type").toString();
				address_typeStr=address_typeStr.replaceAll("\"", "");
				address_type.appendChild(doc.createTextNode(address_typeStr));
				address.appendChild(address_type);
				
				Element addressData = doc.createElement("address");
				if(addressOb.get("address").toString().trim().length() == 0 || addressOb.get("address") == null) {
					addressData.appendChild(doc.createTextNode("Not Available"));
				}else {
					String addressDataStr=addressOb.get("address").toString();
					addressDataStr=addressDataStr.replaceAll("\"", "");
					addressData.appendChild(doc.createTextNode(addressDataStr));
				}
				address.appendChild(addressData);
				
				Element town = doc.createElement("town");
				String townStr=addressOb.get("town").toString();
				townStr=townStr.replaceAll("\"", "");
				town.appendChild(doc.createTextNode(townStr));
				address.appendChild(town);
				
				Element city = doc.createElement("city");
				String cityStr=addressOb.get("city").toString();
				cityStr=cityStr.replaceAll("\"", "");
				city.appendChild(doc.createTextNode(cityStr));
				address.appendChild(city);
								
				Element zip = doc.createElement("zip");
				String zipStr=addressOb.get("zip").toString();
				zipStr=zipStr.replaceAll("\"", "");
				if(zipStr!=null && !zipStr.trim().equalsIgnoreCase("") && !zipStr.trim().equalsIgnoreCase("Not Available")) {
					zip.appendChild(doc.createTextNode(zipStr));
				}else {
					zip.appendChild(doc.createTextNode("0"));
				}
				address.appendChild(zip);
				
				Element country_code = doc.createElement("country_code");
				String country_codeStr=addressOb.get("country_code").toString();
				country_codeStr=country_codeStr.replaceAll("\"", "");
				country_code.appendChild(doc.createTextNode(country_codeStr));
				address.appendChild(country_code);
				
				Element state = doc.createElement("state");
				String stateStr=addressOb.get("state").toString();
				stateStr=stateStr.replaceAll("\"", "");
				state.appendChild(doc.createTextNode(stateStr));
				address.appendChild(state);
				
				addresses.appendChild(address);
			}			
			
			reporting_person.appendChild(addresses);
			
			if(jsonData.get("email")!=null && !jsonData.get("email").toString().trim().equalsIgnoreCase("")) {
				Element email = doc.createElement("email");
				email.appendChild(doc.createTextNode(jsonData.get("email").toString()));
				reporting_person.appendChild(email);
			}
			
			if(jsonData.get("OCCUPATION")!=null && !jsonData.get("OCCUPATION").toString().trim().equalsIgnoreCase("")) {
				Element occupation = doc.createElement("occupation");
				occupation.appendChild(doc.createTextNode(jsonData.get("OCCUPATION").toString()));
				reporting_person.appendChild(occupation);
			}
			
			JSONArray jsonObjectIdentification = null;
			if(jsonData.get("IDENTIFICATION")!=null && jsonData.get("IDENTIFICATION")!="") {
				jsonObjectIdentification = new JSONArray(new JSONObject(jsonData.get("IDENTIFICATION").toString()).get("identification").toString());
			} else {
				String nullJSON="[ {\"type\": \"A\",\"number\": \"Not Available\",\"issue_date\": \"Not Available\",\"expiry_date\": \"Not Available\",\"issued_by\": \"Not Available\",\"issue_country\": \"Not Available\",\"comments\": \"Not Available\" }]";
				jsonObjectAddresses = new JSONArray(nullJSON);
			}

			for (int i=0; i<jsonObjectIdentification.length();i++ ) {
				Element identification = doc.createElement("identification");
				JSONObject identificationOb=new JSONObject(jsonObjectIdentification.get(i).toString());					
				Element type = doc.createElement("type");
				String typeStr=identificationOb.get("type").toString();
				typeStr=typeStr.replaceAll("\"", "");
				type.appendChild(doc.createTextNode(typeStr));
				identification.appendChild(type);
				
				Element number = doc.createElement("number");
				String numberStr=identificationOb.get("number").toString();
				numberStr=numberStr.replaceAll("\"", "");
				number.appendChild(doc.createTextNode(numberStr));
				identification.appendChild(number);
				
				Element issue_date = doc.createElement("issue_date");
				String issue_dateStr=identificationOb.get("issue_date").toString();
				issue_dateStr=issue_dateStr.replaceAll("\"", "");
				issue_date.appendChild(doc.createTextNode(issue_dateStr+"T00:00:00"));
				identification.appendChild(issue_date);
				
				Element expiry_date = doc.createElement("expiry_date");
				String expiry_dateStr=identificationOb.get("expiry_date").toString();
				expiry_dateStr=expiry_dateStr.replaceAll("\"", "");
				expiry_date.appendChild(doc.createTextNode(expiry_dateStr+"T00:00:00"));
				identification.appendChild(expiry_date);
				
				Element issued_by = doc.createElement("issued_by");
				String issued_byStr=identificationOb.get("issued_by").toString();
				issued_byStr=issued_byStr.replaceAll("\"", "");
				issued_by.appendChild(doc.createTextNode(issued_byStr));
				identification.appendChild(issued_by);
				
				Element issue_country = doc.createElement("issue_country");
				String issue_countryStr=identificationOb.get("issue_country").toString();
				issue_countryStr=issue_countryStr.replaceAll("\"", "");
				issue_country.appendChild(doc.createTextNode(issue_countryStr));
				identification.appendChild(issue_country);
				
				Element comments = doc.createElement("comments");
				String commentsStr=identificationOb.get("comments").toString();
				commentsStr=commentsStr.replaceAll("\"", "");
				comments.appendChild(doc.createTextNode(commentsStr));
				identification.appendChild(comments);
				
				reporting_person.appendChild(identification);
			}
			
			
			if(jsonData.get("TAX_NUMBER")!=null && !jsonData.get("TAX_NUMBER").toString().trim().equalsIgnoreCase("")) {
				Element TAX_NUMBER = doc.createElement("tax_number");
				TAX_NUMBER.appendChild(doc.createTextNode(jsonData.get("TAX_NUMBER").toString()));
				reporting_person.appendChild(TAX_NUMBER);
			}
			
			if(jsonData.get("TAX_REG_NUMBER")!=null && !jsonData.get("TAX_REG_NUMBER").toString().trim().equalsIgnoreCase("")) {
				Element TAX_REG_NUMBER = doc.createElement("tax_reg_number");
				TAX_REG_NUMBER.appendChild(doc.createTextNode(jsonData.get("TAX_REG_NUMBER").toString()));
				reporting_person.appendChild(TAX_REG_NUMBER);
			}
			
			if(jsonData.get("SOURCE_OF_WEALTH")!=null && !jsonData.get("SOURCE_OF_WEALTH").toString().trim().equalsIgnoreCase("")) {
				Element SOURCE_OF_WEALTH = doc.createElement("source_of_wealth");
				SOURCE_OF_WEALTH.appendChild(doc.createTextNode(jsonData.get("SOURCE_OF_WEALTH").toString()));
				reporting_person.appendChild(SOURCE_OF_WEALTH);
			}
			
			if(jsonData.get("COMMENTS")!=null && !jsonData.get("COMMENTS").toString().trim().equalsIgnoreCase("")) {
				Element COMMENTS = doc.createElement("comments");
				COMMENTS.appendChild(doc.createTextNode(jsonData.get("COMMENTS").toString()));
				reporting_person.appendChild(COMMENTS);
			}
						
			rootElement.appendChild(reporting_person);
			
//			if(reportType.equalsIgnoreCase("SAR")) {
//				Element Ereason = doc.createElement("reason");
//				Ereason.appendChild(doc.createTextNode(jsonData.get("reason").toString()));
//				rootElement.appendChild(Ereason);
//			}
//			
//			if(reportType.equalsIgnoreCase("SAR") && jsonData.get("action")!=null) {
//				Element Eaction = doc.createElement("action");
//				Eaction.appendChild(doc.createTextNode(jsonData.get("action").toString()));
//				rootElement.appendChild(Eaction);
//			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return doc;
	}

	
	static Document generateSARElements(Document doc, Element rootElement, Map<String, Object> obData, String partyType) {
		try {
			if(partyType.equalsIgnoreCase("person")) {
				Map<String, Object> personRetrive=(Map<String, Object>) obData.get("person");
				List<Map<String,Object>> arrayOfPerson=(List<Map<String, Object>>) personRetrive.get("dirSection");
				for (Map<String, Object> personData : arrayOfPerson) {
					Element report_party =doc.createElement("report_party"); 
					generateDirectorElement(doc,report_party,personData,partyType);
					rootElement.appendChild(report_party);
				}
			}else if(partyType.equalsIgnoreCase("account")) {
				Element report_party =doc.createElement("report_party"); 				
				Map<String, Object> personRetrive=(Map<String, Object>) obData.get("account");
				generateAccountElement(doc,report_party,personRetrive);
				rootElement.appendChild(report_party);
			}else if(partyType.equalsIgnoreCase("entity")) {
				Element report_party =doc.createElement("report_party"); 	
				Map<String, Object> personRetrive=(Map<String, Object>) obData.get("entity");
				generateEntityElement(doc,report_party,personRetrive);
				rootElement.appendChild(report_party);
			}
			
		}catch (Exception e) {		
			e.printStackTrace();
		}
		return doc;
	}


	private static void generateEntityElement(Document doc, Element rootElement, Map<String, Object> entityData) {
		try {			
			Element t_entity = doc.createElement("t_entity");
			
			if(entityData.get("entityCommercialName")!=null) {
				Element name = doc.createElement("name");
				name.appendChild(doc.createTextNode(entityData.get("entityName").toString()));
				t_entity.appendChild(name);
			}
			
			
			if(entityData.get("entityCommercialName")!=null) {
				Element commercialName_tentity = doc.createElement("commercial_name");
				commercialName_tentity.appendChild(doc.createTextNode(entityData.get("entityCommercialName").toString()));
				t_entity.appendChild(commercialName_tentity);
			}
						
			Element incorporation_legal_form = doc.createElement("incorporation_legal_form");
			if (entityData.get("entityIncorporationLegalForm") ==null) {
				incorporation_legal_form.appendChild(doc.createTextNode("A"));
			}else{
				incorporation_legal_form.appendChild(doc.createTextNode(entityData.get("entityIncorporationLegalForm").toString()));
			}
			t_entity.appendChild(incorporation_legal_form);

			if (entityData.get("entityIncorporationNumber") !=null) {
				Element incorporation_number = doc.createElement("incorporation_number");
				incorporation_number.appendChild(doc.createTextNode(entityData.get("entityIncorporationNumber").toString()));
				t_entity.appendChild(incorporation_number);
			}

			if (entityData.get("entityBusiness") !=null) {
				Element business = doc.createElement("business");
				business.appendChild(doc.createTextNode(entityData.get("entityBusiness").toString()));
				t_entity.appendChild(business);
			}
			
			
			Element phonesDirectory = doc.createElement("phones");
			if(entityData.get("mobileNo")!=null) {
				Element phoneDirectory = doc.createElement("phone");
				
				Element phone_typeDirectory = doc.createElement("tph_contact_type");
				phone_typeDirectory.appendChild(doc.createTextNode("5"));
				phoneDirectory.appendChild(phone_typeDirectory);
				
				Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
				tph_communication_typeDirectory.appendChild(doc.createTextNode("M"));
				phoneDirectory.appendChild(tph_communication_typeDirectory);
				
				Element tph_numberDirectory = doc.createElement("tph_number");
				tph_numberDirectory.appendChild(doc.createTextNode(entityData.get("mobileNo").toString()));
				phoneDirectory.appendChild(tph_numberDirectory);
				
				phonesDirectory.appendChild(phoneDirectory);
			}
			
			if(entityData.get("landlineNo")!=null) {
				Element phoneDirectory = doc.createElement("phone");
				
				Element phone_typeDirectory = doc.createElement("tph_contact_type");
				phone_typeDirectory.appendChild(doc.createTextNode("3"));
				phoneDirectory.appendChild(phone_typeDirectory);
				
				Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
				tph_communication_typeDirectory.appendChild(doc.createTextNode("L"));
				phoneDirectory.appendChild(tph_communication_typeDirectory);
				
				Element tph_numberDirectory = doc.createElement("tph_number");
				tph_numberDirectory.appendChild(doc.createTextNode(entityData.get("landlineNo").toString()));
				phoneDirectory.appendChild(tph_numberDirectory);
				
				phonesDirectory.appendChild(phoneDirectory);
			}
			
			if(entityData.get("mobileNo")==null && entityData.get("landlineNo")==null) {
				Element phoneDirectory = doc.createElement("phone");
				
				Element phone_typeDirectory = doc.createElement("tph_contact_type");
				phone_typeDirectory.appendChild(doc.createTextNode("5"));
				phoneDirectory.appendChild(phone_typeDirectory);
				
				Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
				tph_communication_typeDirectory.appendChild(doc.createTextNode("M"));
				phoneDirectory.appendChild(tph_communication_typeDirectory);
				
				Element tph_numberDirectory = doc.createElement("tph_number");
				tph_numberDirectory.appendChild(doc.createTextNode("0"));
				phoneDirectory.appendChild(tph_numberDirectory);
				
				phonesDirectory.appendChild(phoneDirectory);
			}
			t_entity.appendChild(phonesDirectory);
			
			generateAddressElement(doc,t_entity,(Map<String, Object>)entityData.get("address"));

			
			if (entityData.get("entityEmail") != null) {
				Element email_tentity = doc.createElement("email");
				email_tentity.appendChild(doc.createTextNode(entityData.get("entityEmail").toString()));
				t_entity.appendChild(email_tentity);
			}
			
			if (entityData.get("entityURL") != null) {
				Element URL_tentity = doc.createElement("url");
				URL_tentity.appendChild(doc.createTextNode(entityData.get("entityURL").toString()));
				t_entity.appendChild(URL_tentity);
			}			
			
			if (entityData.get("entityIncorporationState")!=null) {
				Element incorporation_state = doc.createElement("incorporation_state");
				incorporation_state.appendChild(doc.createTextNode(entityData.get("entityIncorporationState").toString()));
				t_entity.appendChild(incorporation_state);
			}

			if (entityData.get("entityIncorporationCountryCode")!=null) {
				Element incorporation_country_code = doc.createElement("incorporation_country_code");			
				incorporation_country_code.appendChild(doc.createTextNode(entityData.get("entityIncorporationCountryCode").toString()));			
				t_entity.appendChild(incorporation_country_code);
			}

			if (entityData.get("director")!=null) {
				Map<String, Object> directorRetrive=(Map<String, Object>) entityData.get("director");
				List<Map<String,Object>> arrayOfDirector=(List<Map<String, Object>>) directorRetrive.get("dirSection");
				for (Map<String, Object> directorData : arrayOfDirector) {
					generateDirectorElement(doc,t_entity,directorData,null);
				}
			}
						
			Element incorporation_date = doc.createElement("incorporation_date");
			if (entityData.get("entityIncorporationDate")==null) {
				incorporation_date.appendChild(doc.createTextNode("1900-01-01T00:00:00"));
			} else {
				Date date = inputDateFormat.parse(entityData.get("entityIncorporationDate").toString()+" 00:00:00");
				incorporation_date.appendChild(doc.createTextNode(outputDateFormat.format(date)));
			}
			t_entity.appendChild(incorporation_date);
			
			
			if (entityData.get("entityBusinessClosed") != null) {
				Element business_closed_tentity = doc.createElement("business_closed");
				business_closed_tentity.appendChild(doc.createTextNode(entityData.get("entityBusinessClosed").toString()));
				t_entity.appendChild(business_closed_tentity);
			}
			
			if (entityData.get("entityDateBusinessClosed") != null) {
				Element business_closed_date_tentity = doc.createElement("date_business_closed");
				Date date = inputDateFormat.parse(entityData.get("entityDateBusinessClosed").toString()+" 00:00:00");
				business_closed_date_tentity.appendChild(doc.createTextNode(outputDateFormat.format(date)));
				t_entity.appendChild(business_closed_date_tentity);
			}			

			if (entityData.get("entityTaxNumber") != null) {
				Element tax_number_tentity = doc.createElement("tax_number");
				tax_number_tentity.appendChild(doc.createTextNode(entityData.get("entityTaxNumber").toString()));
				t_entity.appendChild(tax_number_tentity);
			}
		
			
			if (entityData.get("entityTaxRegNumber") != null) {
				Element tax_reg_number_tentity = doc.createElement("tax_reg_number");
				tax_reg_number_tentity.appendChild(doc.createTextNode(entityData.get("entityTaxRegNumber").toString()));
				t_entity.appendChild(tax_reg_number_tentity);
			}

			if (entityData.get("entityComments") != null) {
				Element comments_t_to_to_account = doc.createElement("comments");
				comments_t_to_to_account.appendChild(doc.createTextNode(entityData.get("entityComments").toString()));
				t_entity.appendChild(comments_t_to_to_account);
			}
			
			rootElement.appendChild(t_entity);
			

		
		}catch (Exception e) {
			e.printStackTrace();
		}	
		
	}


	private static void generateAccountElement(Document doc, Element rootElement, Map<String, Object> accountData) {
		try {
			Element account = doc.createElement("to_account");

		    if (accountData.get("institutionName") !=null && accountData.get("institutionName").toString().trim().length() !=0) {
					Element institution_name = doc.createElement("institution_name");
					institution_name.appendChild(doc.createTextNode(accountData.get("institutionName").toString()));
					account.appendChild(institution_name);
				}
			if (accountData.get("institutionCode") !=null && accountData.get("institutionCode").toString().trim().length() !=0) {
					Element institution_code = doc.createElement("institution_code");
					institution_code.appendChild(doc.createTextNode(accountData.get("institutionCode").toString()));
					account.appendChild(institution_code);
				}
			if (accountData.get("nonBankInstitution") !=null && accountData.get("nonBankInstitution").toString().trim().length() !=0) {
					Element non_bank_institution = doc.createElement("non_bank_institution");
					non_bank_institution.appendChild(doc.createTextNode(accountData.get("nonBankInstitution").toString()));
					account.appendChild(non_bank_institution);
				}
			if (accountData.get("branch") !=null && accountData.get("branch").toString().trim().length() !=0) {
					Element branch = doc.createElement("branch");
					branch.appendChild(doc.createTextNode(accountData.get("branch").toString()));
					account.appendChild(branch);
				}
			if (accountData.get("account") !=null && accountData.get("account").toString().trim().length() !=0) {
					Element account_id = doc.createElement("account");
					account_id.appendChild(doc.createTextNode(accountData.get("account").toString()));
					account.appendChild(account_id);
				}
			if (accountData.get("currencyCode") !=null && accountData.get("currencyCode").toString().trim().length() !=0) {
					Element currency_code = doc.createElement("currency_code");
					currency_code.appendChild(doc.createTextNode(accountData.get("currencyCode").toString()));
					account.appendChild(currency_code);
				}
			if (accountData.get("accountName") !=null && accountData.get("accountName").toString().trim().length() !=0) {
					Element account_name = doc.createElement("account_name");
					account_name.appendChild(doc.createTextNode(accountData.get("accountName").toString()));
					account.appendChild(account_name);
				}
			if (accountData.get("iban") !=null && accountData.get("iban").toString().trim().length() !=0) {
					Element iban = doc.createElement("iban");
					iban.appendChild(doc.createTextNode(accountData.get("iban").toString()));
					account.appendChild(iban);
				}
			if (accountData.get("clientNumber") !=null && accountData.get("clientNumber").toString().trim().length() !=0) {
					Element client_number = doc.createElement("client_number");
					client_number.appendChild(doc.createTextNode(accountData.get("clientNumber").toString()));
					account.appendChild(client_number);
				}
			if (accountData.get("personalAcctType") !=null && accountData.get("personalAcctType").toString().trim().length() !=0) {
					Element personal_account_type = doc.createElement("personal_account_type");
					personal_account_type.appendChild(doc.createTextNode(accountData.get("personalAcctType").toString()));
					account.appendChild(personal_account_type);
				}

		    Map<String, Object> entity=(Map<String, Object>) accountData.get("entity");
			generateEntityElement(doc,account,entity);

			if (accountData.get("opened") !=null && accountData.get("opened").toString().trim().length() !=0) {
					Element opened = doc.createElement("opened");
					Date date = inputDateFormat.parse(accountData.get("opened").toString()+" 00:00:00");
					opened.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					account.appendChild(opened);
				}
			if (accountData.get("balance") !=null && accountData.get("balance").toString().trim().length() !=0) {
					Element balance = doc.createElement("balance");
					balance.appendChild(doc.createTextNode(accountData.get("balance").toString()));
					account.appendChild(balance);
				}
			if (accountData.get("dateBalance") !=null && accountData.get("dateBalance").toString().trim().length() !=0) {
					Element date_balance = doc.createElement("date_balance");
					Date date = inputDateFormat.parse(accountData.get("dateBalance").toString()+" 00:00:00");
					date_balance.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					account.appendChild(date_balance);
				}
			if (accountData.get("statusCode") !=null && accountData.get("statusCode").toString().trim().length() !=0) {
					Element status_code = doc.createElement("status_code");
					status_code.appendChild(doc.createTextNode(accountData.get("statusCode").toString()));
					account.appendChild(status_code);
				}
			if (accountData.get("beneficiary") !=null && accountData.get("beneficiary").toString().trim().length() !=0) {
					Element beneficiary = doc.createElement("beneficiary");
					beneficiary.appendChild(doc.createTextNode(accountData.get("beneficiary").toString()));
					account.appendChild(beneficiary);
				}
			if (accountData.get("beneficiaryComment") !=null && accountData.get("beneficiaryComment").toString().trim().length() !=0) {
					Element beneficiary_comment = doc.createElement("beneficiary_comment");
					beneficiary_comment.appendChild(doc.createTextNode(accountData.get("beneficiaryComment").toString()));
					account.appendChild(beneficiary_comment);
				}
			if (accountData.get("comment") !=null && accountData.get("comment").toString().trim().length() !=0) {
					Element comment = doc.createElement("comment");
					comment.appendChild(doc.createTextNode(accountData.get("comment").toString()));
					account.appendChild(comment);
				}

		        Map<String, Object> signatoryMap=(Map<String, Object>) accountData.get("signatory");
				List<Map<String,Object>> arrayOfSignatory=(List<Map<String, Object>>) signatoryMap.get("signatorySection");
				int j=0;
				for (Map<String, Object> signatoryData : arrayOfSignatory) {
					generateSignatoryElement(doc,account,signatoryData,j);
					j++;
				}

		        rootElement.appendChild(account);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void generateSignatoryElement(Document doc, Element rootElement, Map<String, Object> signatoryData, int j) {
		try {
				Element signatory = doc.createElement("signatory");
			 	Element is_primary = doc.createElement("is_primary");
			 	if(j ==0 )
			 		is_primary.appendChild(doc.createTextNode("1"));
			 	else
			 		is_primary.appendChild(doc.createTextNode("0"));
			    signatory.appendChild(is_primary);
				Element t_person = doc.createElement("t_person");
		        if (signatoryData.get("signatory_Gender") !=null && signatoryData.get("signatory_Gender").toString().trim().length() !=0) {
					Element signatory_Gender = doc.createElement("gender");
					signatory_Gender.appendChild(doc.createTextNode(signatoryData.get("signatory_Gender").toString()));
					t_person.appendChild(signatory_Gender);
				}
		        if (signatoryData.get("signatoryTitle") !=null && signatoryData.get("signatoryTitle").toString().trim().length() !=0) {
					Element signatoryTitle = doc.createElement("title");
					signatoryTitle.appendChild(doc.createTextNode(signatoryData.get("signatoryTitle").toString()));
					t_person.appendChild(signatoryTitle);
				}
		        if (signatoryData.get("signatoryFirstName") !=null && signatoryData.get("signatoryFirstName").toString().trim().length() !=0) {
					Element signatoryFirstName = doc.createElement("first_name");
					signatoryFirstName.appendChild(doc.createTextNode(signatoryData.get("signatoryFirstName").toString()));
					t_person.appendChild(signatoryFirstName);
				}
		        if (signatoryData.get("signatoryMiddleName") !=null && signatoryData.get("signatoryMiddleName").toString().trim().length() !=0) {
					Element signatoryMiddleName = doc.createElement("middle_name");
					signatoryMiddleName.appendChild(doc.createTextNode(signatoryData.get("signatoryMiddleName").toString()));
					t_person.appendChild(signatoryMiddleName);
				}
		        if (signatoryData.get("signatoryPrefix") !=null && signatoryData.get("signatoryPrefix").toString().trim().length() !=0) {
					Element signatoryPrefix = doc.createElement("prefix");
					signatoryPrefix.appendChild(doc.createTextNode(signatoryData.get("signatoryPrefix").toString()));
					t_person.appendChild(signatoryPrefix);
				}
		        if (signatoryData.get("signatoryLastName") !=null && signatoryData.get("signatoryLastName").toString().trim().length() !=0) {
					Element signatoryLastName = doc.createElement("last_name");
					signatoryLastName.appendChild(doc.createTextNode(signatoryData.get("signatoryLastName").toString()));
					t_person.appendChild(signatoryLastName);
				}
		        if (signatoryData.get("signatoryBirthdate") !=null && signatoryData.get("signatoryBirthdate").toString().trim().length() !=0) {
					Element signatoryBirthdate = doc.createElement("birthdate");
					Date date = inputDateFormat.parse(signatoryData.get("signatoryBirthdate").toString()+" 00:00:00");
					signatoryBirthdate.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					t_person.appendChild(signatoryBirthdate);
				}
		        if (signatoryData.get("signatoryBirthPlace") !=null && signatoryData.get("signatoryBirthPlace").toString().trim().length() !=0) {
					Element signatoryBirthPlace = doc.createElement("birth_place");
					signatoryBirthPlace.appendChild(doc.createTextNode(signatoryData.get("signatoryBirthPlace").toString()));
					t_person.appendChild(signatoryBirthPlace);
				}
		        if (signatoryData.get("signatoryMothersName") !=null && signatoryData.get("signatoryMothersName").toString().trim().length() !=0) {
					Element signatoryMothersName = doc.createElement("mothers_name");
					signatoryMothersName.appendChild(doc.createTextNode(signatoryData.get("signatoryMothersName").toString()));
					t_person.appendChild(signatoryMothersName);
				}
		        if (signatoryData.get("signatoryAlias") !=null && signatoryData.get("signatoryAlias").toString().trim().length() !=0) {
					Element signatoryAlias = doc.createElement("alias");
					signatoryAlias.appendChild(doc.createTextNode(signatoryData.get("signatoryAlias").toString()));
					t_person.appendChild(signatoryAlias);
				}
		        if (signatoryData.get("signatorySSN")!=null) {
						Element ssn_citizenship = doc.createElement("ssn");
						ssn_citizenship.appendChild(doc.createTextNode(signatoryData.get("signatorySSN").toString()));
						t_person.appendChild(ssn_citizenship);
						if (signatoryData.get("signatoryPassportNumber")!=null && signatoryData.get("signatoryPassportNumber")!=null ) {
							Element PASSPORT_NO = doc.createElement("passport_number");
							PASSPORT_NO.appendChild(doc.createTextNode(signatoryData.get("signatoryPassportNumber").toString()));
							t_person.appendChild(PASSPORT_NO);
							Element passport_country = doc.createElement("passport_country");
							passport_country.appendChild(doc.createTextNode(signatoryData.get("signatoryPassportCountry").toString()));
							t_person.appendChild(passport_country);
						}
					} else {
						//Bharat 14/8/2023 - if ssn is not available and passport_country is not available then show passport and passport_country tag should not be shown as not available	
						Element ssn_citizenship = doc.createElement("ssn");
						ssn_citizenship.appendChild(doc.createTextNode("Not Available"));
						t_person.appendChild(ssn_citizenship);
						if (signatoryData.get("signatoryPassportNumber")!=null ) {
							Element PASSPORT_NO = doc.createElement("passport_number");
							PASSPORT_NO.appendChild(doc.createTextNode(signatoryData.get("signatoryPassportNumber").toString()));
							t_person.appendChild(PASSPORT_NO);
							if (signatoryData.get("signatoryPassportCountry")!=null) {
								Element passport_country = doc.createElement("passport_country");
								passport_country.appendChild(doc.createTextNode(signatoryData.get("signatoryPassportCountry").toString()));
								t_person.appendChild(passport_country);
							} else {
								Element passport_country = doc.createElement("passport_country");
								passport_country.appendChild(doc.createTextNode("Not Available"));
								t_person.appendChild(passport_country);
							}
						}
					}				
		       
		        if (signatoryData.get("signatoryID_Number") !=null && signatoryData.get("signatoryID_Number").toString().trim().length() !=0) {
					Element signatoryID_Number = doc.createElement("id_number");
					signatoryID_Number.appendChild(doc.createTextNode(signatoryData.get("signatoryID_Number").toString()));
					t_person.appendChild(signatoryID_Number);
				}
		        if (signatoryData.get("signatoryNationality1") !=null && signatoryData.get("signatoryNationality1").toString().trim().length() !=0) {
					Element signatoryNationality1 = doc.createElement("nationality1");
					signatoryNationality1.appendChild(doc.createTextNode(signatoryData.get("signatoryNationality1").toString()));
					t_person.appendChild(signatoryNationality1);
				}
		        if (signatoryData.get("signatoryNationality2") !=null && signatoryData.get("signatoryNationality2").toString().trim().length() !=0) {
					Element signatoryNationality2 = doc.createElement("nationality2");
					signatoryNationality2.appendChild(doc.createTextNode(signatoryData.get("signatoryNationality2").toString()));
					t_person.appendChild(signatoryNationality2);
				}
		        if (signatoryData.get("signatoryNationality3") !=null && signatoryData.get("signatoryNationality3").toString().trim().length() !=0) {
					Element signatoryNationality3 = doc.createElement("nationality3");
					signatoryNationality3.appendChild(doc.createTextNode(signatoryData.get("signatoryNationality3").toString()));
					t_person.appendChild(signatoryNationality3);
				}
		        if (signatoryData.get("signatoryResidence") !=null && signatoryData.get("signatoryResidence").toString().trim().length() !=0) {
					Element signatoryResidence = doc.createElement("residence");
					signatoryResidence.appendChild(doc.createTextNode(signatoryData.get("signatoryResidence").toString()));
					t_person.appendChild(signatoryResidence);
				}

		            Element phonesSignatory = doc.createElement("phones");
					if(signatoryData.get("mobileNo")!=null && !signatoryData.get("mobileNo").toString().trim().equalsIgnoreCase("") && !signatoryData.get("mobileNo").toString().equalsIgnoreCase("Not Available")) {
						Element phoneDirectory = doc.createElement("phone");
						
						Element phone_typeDirectory = doc.createElement("tph_contact_type");
						phone_typeDirectory.appendChild(doc.createTextNode("5"));
						phoneDirectory.appendChild(phone_typeDirectory);
						
						Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
						tph_communication_typeDirectory.appendChild(doc.createTextNode("M"));
						phoneDirectory.appendChild(tph_communication_typeDirectory);
						
						Element tph_numberDirectory = doc.createElement("tph_number");
						tph_numberDirectory.appendChild(doc.createTextNode(signatoryData.get("mobileNo").toString()));
						phoneDirectory.appendChild(tph_numberDirectory);
						
						phonesSignatory.appendChild(phoneDirectory);
					}
					
					if(signatoryData.get("landlineNo")!=null && !signatoryData.get("landlineNo").toString().trim().equalsIgnoreCase("") && !signatoryData.get("landlineNo").toString().equalsIgnoreCase("Not Available")) {
						Element phoneDirectory = doc.createElement("phone");
						
						Element phone_typeDirectory = doc.createElement("tph_contact_type");
						phone_typeDirectory.appendChild(doc.createTextNode("3"));
						phoneDirectory.appendChild(phone_typeDirectory);
						
						Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
						tph_communication_typeDirectory.appendChild(doc.createTextNode("L"));
						phoneDirectory.appendChild(tph_communication_typeDirectory);
						
						Element tph_numberDirectory = doc.createElement("tph_number");
						tph_numberDirectory.appendChild(doc.createTextNode(signatoryData.get("landlineNo").toString()));
						phoneDirectory.appendChild(tph_numberDirectory);
						
						phonesSignatory.appendChild(phoneDirectory);
					}
					
					if(!(signatoryData.get("mobileNo")!=null && !signatoryData.get("mobileNo").toString().trim().equalsIgnoreCase("") && !signatoryData.get("mobileNo").toString().equalsIgnoreCase("Not Available")) && !(signatoryData.get("landlineNo")!=null && !signatoryData.get("landlineNo").toString().trim().equalsIgnoreCase("") && !signatoryData.get("landlineNo").toString().equalsIgnoreCase("Not Available"))) {
						Element phoneDirectory = doc.createElement("phone");
						
						Element phone_typeDirectory = doc.createElement("tph_contact_type");
						phone_typeDirectory.appendChild(doc.createTextNode("5"));
						phoneDirectory.appendChild(phone_typeDirectory);
						
						Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
						tph_communication_typeDirectory.appendChild(doc.createTextNode("M"));
						phoneDirectory.appendChild(tph_communication_typeDirectory);
						
						Element tph_numberDirectory = doc.createElement("tph_number");
						tph_numberDirectory.appendChild(doc.createTextNode("0"));
						phoneDirectory.appendChild(tph_numberDirectory);
						
						phonesSignatory.appendChild(phoneDirectory);
					}
					t_person.appendChild(phonesSignatory);
					
					generateAddressElement(doc,t_person,(Map<String, Object>) signatoryData.get("address")); 



		        if (signatoryData.get("signatoryEmail") !=null && signatoryData.get("signatoryEmail").toString().trim().length() !=0) {
					Element signatoryEmail = doc.createElement("email");
					signatoryEmail.appendChild(doc.createTextNode(signatoryData.get("signatoryEmail").toString()));
					t_person.appendChild(signatoryEmail);
				}
		        if (signatoryData.get("signatoryDeceased") !=null && signatoryData.get("signatoryDeceased").toString().trim().length() !=0) {
					Element signatoryDeceased = doc.createElement("deceased");
					signatoryDeceased.appendChild(doc.createTextNode(signatoryData.get("signatoryDeceased").toString()));
					t_person.appendChild(signatoryDeceased);
				}
		        if (signatoryData.get("signatoryDeceasedDate") !=null && signatoryData.get("signatoryDeceasedDate").toString().trim().length() !=0) {
					Element signatoryDeceasedDate = doc.createElement("date_deceased");
					Date date = inputDateFormat.parse(signatoryData.get("signatoryDeceasedDate").toString()+" 00:00:00");
					signatoryDeceasedDate.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					t_person.appendChild(signatoryDeceasedDate);
				}
		        if (signatoryData.get("signatoryTaxNumber") !=null && signatoryData.get("signatoryTaxNumber").toString().trim().length() !=0) {
					Element signatoryTaxNumber = doc.createElement("tax_number");
					signatoryTaxNumber.appendChild(doc.createTextNode(signatoryData.get("signatoryTaxNumber").toString()));
					t_person.appendChild(signatoryTaxNumber);
				}
		        if (signatoryData.get("signatoryTaxRegNumber") !=null && signatoryData.get("signatoryTaxRegNumber").toString().trim().length() !=0) {
					Element signatoryTaxRegNumber = doc.createElement("tax_reg_number");
					Date date = inputDateFormat.parse(signatoryData.get("signatoryTaxRegNumber").toString()+" 00:00:00");
					signatoryTaxRegNumber.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					t_person.appendChild(signatoryTaxRegNumber);
				}
		        if (signatoryData.get("signatorySourceOfWealth") !=null && signatoryData.get("signatorySourceOfWealth").toString().trim().length() !=0) {
					Element signatorySourceOfWealth = doc.createElement("source_of_wealth");
					signatorySourceOfWealth.appendChild(doc.createTextNode(signatoryData.get("signatorySourceOfWealth").toString()));
					t_person.appendChild(signatorySourceOfWealth);
				}
		        if (signatoryData.get("signatoryComments") !=null && signatoryData.get("signatoryComments").toString().trim().length() !=0) {
					Element signatoryComments = doc.createElement("comments");
					signatoryComments.appendChild(doc.createTextNode(signatoryData.get("signatoryComments").toString()));
					t_person.appendChild(signatoryComments);
				}
		        if (signatoryData.get("signatoryOccupation") !=null && signatoryData.get("signatoryOccupation").toString().trim().length() !=0) {
					Element signatoryOccupation = doc.createElement("occupation");
					signatoryOccupation.appendChild(doc.createTextNode(signatoryData.get("signatoryOccupation").toString()));
					t_person.appendChild(signatoryOccupation);
				}
		  
		        if (signatoryData.get("signatoryRole") !=null && signatoryData.get("signatoryRole").toString().trim().length() !=0) {
					Element signatoryRole = doc.createElement("role");
					signatoryRole.appendChild(doc.createTextNode(signatoryData.get("signatoryRole").toString()));
					t_person.appendChild(signatoryRole);
				}    

		    
		        Element signatory_empaddresses = doc.createElement("employer_address_id");
		        if(signatoryData.get("emp_details")!=null && signatoryData.get("emp_details").toString().trim().length() !=0) {
		            Map<String, Object> emp_details =  (Map<String, Object>) signatoryData.get("emp_details");
		            if (emp_details.get("emp_name") !=null && emp_details.get("emp_name").toString().trim().length() !=0) {
						Element signatoryEmployerName = doc.createElement("employer_name");
						signatoryEmployerName.appendChild(doc.createTextNode(emp_details.get("emp_name").toString()));
						t_person.appendChild(signatoryEmployerName);
					}

			        Element signatory_empphones = doc.createElement("employer_phone_id");
			        if(emp_details.get("mobileNo")!=null && !emp_details.get("mobileNo").toString().trim().equalsIgnoreCase("")) {
			            Element signatory_phone = doc.createElement("phone");
			            
			            Element phone_type = doc.createElement("tph_contact_type");
			            phone_type.appendChild(doc.createTextNode("5"));
			            signatory_phone.appendChild(phone_type);
			            
			            Element tph_communication_type = doc.createElement("tph_communication_type");
			            tph_communication_type.appendChild(doc.createTextNode("M"));
			            signatory_phone.appendChild(tph_communication_type);
			            
			            Element tph_number = doc.createElement("tph_number");
			            tph_number.appendChild(doc.createTextNode(emp_details.get("mobileNo").toString()));
			            signatory_phone.appendChild(tph_number);
			            
			            signatory_empphones.appendChild(signatory_phone);
			        }
			        
			        if(emp_details.get("landlineNo")!=null && !emp_details.get("landlineNo").toString().trim().equalsIgnoreCase("")) {
			            Element signatory_phone = doc.createElement("phone");
			            
			            Element phone_type = doc.createElement("tph_contact_type");
			            phone_type.appendChild(doc.createTextNode("3"));
			            signatory_phone.appendChild(phone_type);
			            
			            Element tph_communication_type = doc.createElement("tph_communication_type");
			            tph_communication_type.appendChild(doc.createTextNode("L"));
			            signatory_phone.appendChild(tph_communication_type);
			            
			            Element tph_number = doc.createElement("tph_number");
			            tph_number.appendChild(doc.createTextNode(emp_details.get("landlineNo").toString()));
			            signatory_phone.appendChild(tph_number);
			            
			            signatory_empphones.appendChild(signatory_phone);
			        }
			        
			        if(!(emp_details.get("mobileNo")!=null && !emp_details.get("mobileNo").toString().trim().equalsIgnoreCase("")) && !(emp_details.get("landlineNo")!=null && !emp_details.get("landlineNo").toString().trim().equalsIgnoreCase(""))) {
			            Element phone2 = doc.createElement("phone");
			            
			            Element phone_type = doc.createElement("tph_contact_type");
			            phone_type.appendChild(doc.createTextNode("5"));
			            phone2.appendChild(phone_type);
			            
			            Element tph_communication_type = doc.createElement("tph_communication_type");
			            tph_communication_type.appendChild(doc.createTextNode("M"));
			            phone2.appendChild(tph_communication_type);
			            
			            Element tph_number = doc.createElement("tph_number");
			            tph_number.appendChild(doc.createTextNode("0"));
			            phone2.appendChild(tph_number);
			            
			            signatory_empphones.appendChild(phone2);
			        }
			        t_person.appendChild(signatory_empphones);
			        
		            Element emp_detailsaddress = doc.createElement("address");

		            Element address_typeDirectory = doc.createElement("address_type");							
		            address_typeDirectory.appendChild(doc.createTextNode(emp_details.get("addressType").toString()));
		            emp_detailsaddress.appendChild(address_typeDirectory);
		            
		            if(emp_details.get("address")!= null && emp_details.get("address").toString().trim().length() !=0){
		                Element addressActualDirectory = doc.createElement("address");							
		                addressActualDirectory.appendChild(doc.createTextNode(emp_details.get("address").toString()));							
		                emp_detailsaddress.appendChild(addressActualDirectory);
		            }
		            
		            if(emp_details.get("addressTown")!= null && emp_details.get("addressTown").toString().trim().length() !=0){
		                Element cityDirectory = doc.createElement("towm");
		                cityDirectory.appendChild(doc.createTextNode(emp_details.get("addressTown").toString()));
		                emp_detailsaddress.appendChild(cityDirectory);
		            }	

		            if(emp_details.get("addressCity")!= null && emp_details.get("addressCity").toString().trim().length() !=0){
		                Element cityDirectory = doc.createElement("city");
		                cityDirectory.appendChild(doc.createTextNode(emp_details.get("addressCity").toString()));
		                emp_detailsaddress.appendChild(cityDirectory);
		            }
		            if(emp_details.get("addressZip")!= null && emp_details.get("addressZip").toString().trim().length() !=0){
		                Element cityDirectory = doc.createElement("zip");
		                cityDirectory.appendChild(doc.createTextNode(emp_details.get("addressZip").toString()));
		                emp_detailsaddress.appendChild(cityDirectory);
		            }
		            if(emp_details.get("addressCountryCode")!= null && emp_details.get("addressCountryCode").toString().trim().length() !=0){
		                Element country_codeDirectory = doc.createElement("country_code");						
		                country_codeDirectory.appendChild(doc.createTextNode(emp_details.get("addressCountryCode").toString()));							
		                emp_detailsaddress.appendChild(country_codeDirectory);
		            }
		            if(emp_details.get("addressState")!= null && emp_details.get("addressState").toString().trim().length() !=0){
		                Element country_codeDirectory = doc.createElement("state");						
		                country_codeDirectory.appendChild(doc.createTextNode(emp_details.get("addressState").toString()));							
		                emp_detailsaddress.appendChild(country_codeDirectory);
		            }							
		            signatory_empaddresses.appendChild(emp_detailsaddress);
		        }		
		        t_person.appendChild(signatory_empaddresses);
		        
				generateIdentificationElement(doc,t_person,(Map<String, Object>) signatoryData.get("identification"));
				signatory.appendChild(t_person);
				rootElement.appendChild(signatory);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	private static void generateDirectorElement(Document doc, Element rootElement, Map<String, Object> obData,String partyType) {
		try {
			Element director_id=null;
			if(partyType !=null && partyType.equals("person"))
				director_id = doc.createElement("person");
			else
				director_id = doc.createElement("director_id");
			Element gender = doc.createElement("gender");
			if (obData.get("directorGender") ==null) {
				gender.appendChild(doc.createTextNode("M"));
			} else {
				gender.appendChild(doc.createTextNode(obData.get("directorGender").toString()));
			}
			director_id.appendChild(gender);						
			
			
			if (obData.get("directorTitle")!=null) {
				Element title = doc.createElement("title");
				title.appendChild(doc.createTextNode(obData.get("directorTitle").toString()));
				director_id.appendChild(title);
			}
		
		    if(obData.get("directorFirstName")!=null){
				Element first_name = doc.createElement("first_name");
				first_name.appendChild(doc.createTextNode(obData.get("directorFirstName").toString()));
				director_id.appendChild(first_name);
			}

			if (obData.get("directorMiddleName")!=null) {
				Element middle_name = doc.createElement("middle_name");
				middle_name.appendChild(
						doc.createTextNode(obData.get("directorMiddleName").toString()));
				director_id.appendChild(middle_name);
			}
			
			if (obData.get("directorPrefix")!=null) {
				Element prefix = doc.createElement("prefix");
				prefix.appendChild(doc.createTextNode(obData.get("directorPrefix").toString()));
				director_id.appendChild(prefix);
			}

          if(obData.get("directorLastName")!=null){
			Element last_name = doc.createElement("last_name");
			last_name.appendChild(doc.createTextNode(obData.get("directorLastName").toString()));
			director_id.appendChild(last_name);
		  }
	
			if (obData.get("directorBirthdate")!=null) {
				Element date_of_birth = doc.createElement("birthdate");
	            Date date = inputDateFormat.parse(obData.get("directorBirthdate").toString()+" 00:00:00");
				date_of_birth.appendChild(doc.createTextNode(outputDateFormat.format(date)));
				director_id.appendChild(date_of_birth);
			} 
			if (obData.get("directorBirthPlace")!=null) {
				Element birth_place = doc.createElement("birth_place");
				birth_place.appendChild(doc.createTextNode(obData.get("directorBirthPlace").toString()));
				director_id.appendChild(birth_place);
			}
			
			if (obData.get("directorMothersName")!=null) {
				Element mothers_name = doc.createElement("mothers_name");
				mothers_name.appendChild(doc.createTextNode(obData.get("directorMothersName").toString()));
				director_id.appendChild(mothers_name);
			}
			
			if (obData.get("directorAliasName")!=null) {
				Element alias = doc.createElement("alias");
				alias.appendChild(doc.createTextNode(obData.get("directorAliasName").toString()));
				director_id.appendChild(alias);
			}
			

			//Bharat 14/8/2023 - if ssn is available and passport_country is not available then do not show passport and passport_country tag should not be shown
			if (obData.get("directorSSN")!=null) {
				Element ssn_citizenship = doc.createElement("ssn");
				ssn_citizenship.appendChild(doc.createTextNode(obData.get("directorSSN").toString()));
				director_id.appendChild(ssn_citizenship);
				if (obData.get("directorPassportNumber")!=null && obData.get("directorPassportNumber").toString().trim().length() !=0
						&& obData.get("directorPassportNumber")!=null && obData.get("directorPassportNumber").toString().trim().length() !=0 ) {
					Element PASSPORT_NO = doc.createElement("passport_number");
					PASSPORT_NO.appendChild(doc.createTextNode(obData.get("directorPassportNumber").toString()));
					director_id.appendChild(PASSPORT_NO);
					Element passport_country = doc.createElement("passport_country");
					passport_country.appendChild(doc.createTextNode(obData.get("directorPassportCountry").toString()));
					director_id.appendChild(passport_country);
				}
			} else {
				//Bharat 14/8/2023 - if ssn is not available and passport_country is not available then show passport and passport_country tag should not be shown as not available	
				Element ssn_citizenship = doc.createElement("ssn");
				ssn_citizenship.appendChild(doc.createTextNode("Not Available"));
				director_id.appendChild(ssn_citizenship);
				if (obData.get("directorPassportNumber")!=null && obData.get("directorPassportNumber").toString().trim().length() !=0) {
					Element PASSPORT_NO = doc.createElement("passport_number");
					PASSPORT_NO.appendChild(doc.createTextNode(obData.get("directorPassportNumber").toString()));
					director_id.appendChild(PASSPORT_NO);
					if (obData.get("directorPassportCountry")!=null && obData.get("directorPassportCountry").toString().trim().length() !=0) {
						Element passport_country = doc.createElement("passport_country");
						passport_country.appendChild(doc.createTextNode(obData.get("directorPassportCountry").toString()));
						director_id.appendChild(passport_country);
					} else {
						Element passport_country = doc.createElement("passport_country");
						passport_country.appendChild(doc.createTextNode("Not Available"));
						director_id.appendChild(passport_country);
					}
				}
			}
									
			if (obData.get("directorID_Number")!=null && !obData.get("directorID_Number").toString().trim().equalsIgnoreCase("") && !obData.get("directorID_Number").toString().equalsIgnoreCase("Not Available") &&
					!(obData.get("directorPassportNumber")!=null && !obData.get("directorPassportNumber").toString().trim().equalsIgnoreCase("") && !obData.get("directorPassportNumber").toString().equalsIgnoreCase("Not Available")) &&
					!(obData.get("directorSSN")!=null && !obData.get("directorSSN").toString().trim().equalsIgnoreCase("") && !obData.get("directorSSN").toString().equalsIgnoreCase("Not Available"))) {
				Element Id = doc.createElement("id_number");
				Id.appendChild(doc.createTextNode(obData.get("directorID_Number").toString().trim()));
				director_id.appendChild(Id);
			}
			
			if (obData.get("directorNationality")!=null && !obData.get("directorNationality").toString().trim().equalsIgnoreCase("") && !obData.get("directorNationality").toString().equalsIgnoreCase("Not Available")) {
				Element nationality = doc.createElement("nationality1");
				nationality.appendChild(doc.createTextNode(obData.get("directorNationality").toString().trim()));
				director_id.appendChild(nationality);
			}
			
			if (obData.get("directorResidence")!=null && !obData.get("directorResidence").toString().trim().equalsIgnoreCase("") && !obData.get("directorResidence").toString().equalsIgnoreCase("Not Available")) {
				Element RESIDENCE = doc.createElement("residence");
				RESIDENCE.appendChild(doc.createTextNode(obData.get("directorResidence").toString().trim()));
				director_id.appendChild(RESIDENCE);
			}
			
			Element phonesDirectory = doc.createElement("phones");
			if(obData.get("mobileNo")!=null && !obData.get("mobileNo").toString().trim().equalsIgnoreCase("") && !obData.get("mobileNo").toString().equalsIgnoreCase("Not Available")) {
				Element phoneDirectory = doc.createElement("phone");
				
				Element phone_typeDirectory = doc.createElement("tph_contact_type");
				phone_typeDirectory.appendChild(doc.createTextNode("5"));
				phoneDirectory.appendChild(phone_typeDirectory);
				
				Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
				tph_communication_typeDirectory.appendChild(doc.createTextNode("M"));
				phoneDirectory.appendChild(tph_communication_typeDirectory);
				
				Element tph_numberDirectory = doc.createElement("tph_number");
				tph_numberDirectory.appendChild(doc.createTextNode(obData.get("mobileNo").toString()));
				phoneDirectory.appendChild(tph_numberDirectory);
				
				phonesDirectory.appendChild(phoneDirectory);
			}
			
			if(obData.get("landlineNo")!=null && !obData.get("landlineNo").toString().trim().equalsIgnoreCase("") && !obData.get("landlineNo").toString().equalsIgnoreCase("Not Available")) {
				Element phoneDirectory = doc.createElement("phone");
				
				Element phone_typeDirectory = doc.createElement("tph_contact_type");
				phone_typeDirectory.appendChild(doc.createTextNode("3"));
				phoneDirectory.appendChild(phone_typeDirectory);
				
				Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
				tph_communication_typeDirectory.appendChild(doc.createTextNode("L"));
				phoneDirectory.appendChild(tph_communication_typeDirectory);
				
				Element tph_numberDirectory = doc.createElement("tph_number");
				tph_numberDirectory.appendChild(doc.createTextNode(obData.get("landlineNo").toString()));
				phoneDirectory.appendChild(tph_numberDirectory);
				
				phonesDirectory.appendChild(phoneDirectory);
			}
			
			if(!(obData.get("mobileNo")!=null && !obData.get("mobileNo").toString().trim().equalsIgnoreCase("") && !obData.get("mobileNo").toString().equalsIgnoreCase("Not Available")) && !(obData.get("landlineNo")!=null && !obData.get("landlineNo").toString().trim().equalsIgnoreCase("") && !obData.get("landlineNo").toString().equalsIgnoreCase("Not Available"))) {
				Element phoneDirectory = doc.createElement("phone");
				
				Element phone_typeDirectory = doc.createElement("tph_contact_type");
				phone_typeDirectory.appendChild(doc.createTextNode("5"));
				phoneDirectory.appendChild(phone_typeDirectory);
				
				Element tph_communication_typeDirectory = doc.createElement("tph_communication_type");
				tph_communication_typeDirectory.appendChild(doc.createTextNode("M"));
				phoneDirectory.appendChild(tph_communication_typeDirectory);
				
				Element tph_numberDirectory = doc.createElement("tph_number");
				tph_numberDirectory.appendChild(doc.createTextNode("0"));
				phoneDirectory.appendChild(tph_numberDirectory);
				
				phonesDirectory.appendChild(phoneDirectory);
			}
			director_id.appendChild(phonesDirectory);
			
			generateAddressElement(doc,director_id,(Map<String, Object>)obData.get("address"));

			
			if (obData.get("directorEmailID")!=null && !obData.get("directorEmailID").toString().trim().equalsIgnoreCase("") && !obData.get("directorEmailID").toString().equalsIgnoreCase("Not Available")) {
				Element email_id = doc.createElement("email");
				email_id.appendChild(doc.createTextNode(obData.get("directorEmailID").toString().trim()));
				director_id.appendChild(email_id);
			}
			
			if (obData.get("directorOccupation")!=null && !obData.get("directorOccupation").toString().trim().equalsIgnoreCase("") && !obData.get("directorOccupation").toString().equalsIgnoreCase("Not Available")) {
				Element occupation = doc.createElement("occupation");
				occupation.appendChild(doc.createTextNode(obData.get("directorOccupation").toString().trim()));
				director_id.appendChild(occupation);
			}
			
			if (obData.get("directorEmployerName")!=null && !obData.get("directorEmployerName").toString().trim().equalsIgnoreCase("") && !obData.get("directorEmployerName").toString().equalsIgnoreCase("Not Available")) {
				Element occupation = doc.createElement("employer_name");
				occupation.appendChild(doc.createTextNode(obData.get("directorEmployerName").toString().trim()));
				director_id.appendChild(occupation);
			}						
			generateIdentificationElement(doc,director_id,(Map<String, Object>) obData.get("identification"));
			
			if (obData.get("directorDeceased")!=null && !obData.get("directorDeceased").toString().trim().equalsIgnoreCase("") && !obData.get("directorDeceased").toString().equalsIgnoreCase("Not Available")) {
				Element deceased = doc.createElement("deceased");
				deceased.appendChild(doc.createTextNode(obData.get("directorDeceased").toString().trim()));
				director_id.appendChild(deceased);
			}
			
			if (obData.get("directorDeceasedDate")!=null && !obData.get("directorDeceasedDate").toString().trim().equalsIgnoreCase("") && !obData.get("directorDeceasedDate").toString().equalsIgnoreCase("Not Available")) {
				Element deceased_date = doc.createElement("date_deceased");
				deceased_date.appendChild(doc.createTextNode(obData.get("directorDeceasedDate").toString().trim()));
				director_id.appendChild(deceased_date);
			}
			
			if (obData.get("directorTaxNumber")!=null && !obData.get("directorTaxNumber").toString().trim().equalsIgnoreCase("") && !obData.get("directorTaxNumber").toString().equalsIgnoreCase("Not Available")) {
				Element tax_number_tentity = doc.createElement("tax_number");
				tax_number_tentity.appendChild(doc.createTextNode(obData.get("directorTaxNumber").toString()));
				director_id.appendChild(tax_number_tentity);
			}
			
			if (obData.get("directorTaxRegNumber")!=null && !obData.get("directorTaxRegNumber").toString().trim().equalsIgnoreCase("") && !obData.get("directorTaxRegNumber").toString().equalsIgnoreCase("Not Available")) {
				Element tax_reg_number = doc.createElement("tax_reg_number");
				tax_reg_number.appendChild(doc.createTextNode(obData.get("directorTaxRegNumber").toString().trim()));
				director_id.appendChild(tax_reg_number);
			}
			
			if (obData.get("directorSourceOfWealth")!=null && !obData.get("directorSourceOfWealth").toString().trim().equalsIgnoreCase("") && !obData.get("directorSourceOfWealth").toString().equalsIgnoreCase("Not Available")) {
				Element source_income = doc.createElement("source_of_wealth");
				source_income.appendChild(doc.createTextNode(obData.get("directorSourceOfWealth").toString().trim()));
				director_id.appendChild(source_income);
			}
									
			if(obData.get("directorRole") !=null) {
				Element role = doc.createElement("role");
				role.appendChild(doc.createTextNode(obData.get("directorRole").toString().trim()));
				director_id.appendChild(role);
			}
			rootElement.appendChild(director_id);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	private static void generateAddressElement(Document doc, Element rootElement, Map<String, Object> addressData) {
		try {
			Element addresses = doc.createElement("addresses");
			if(addressData.get("paddress")!=null && addressData.get("paddress").toString().trim().length() !=0) {
				Element address = doc.createElement("address");

				Element address_typeDirectory = doc.createElement("address_type");							
				address_typeDirectory.appendChild(doc.createTextNode(addressData.get("pAddressType").toString()));
				address.appendChild(address_typeDirectory);
				
				if(addressData.get("paddress")!= null && addressData.get("paddress").toString().trim().length() !=0){
					Element addressActualDirectory = doc.createElement("address");							
					addressActualDirectory.appendChild(doc.createTextNode(addressData.get("paddress").toString()));							
					address.appendChild(addressActualDirectory);
				}
				
				if(addressData.get("paddressTown")!= null && addressData.get("paddressTown").toString().trim().length() !=0){
					Element cityDirectory = doc.createElement("towm");
					cityDirectory.appendChild(doc.createTextNode(addressData.get("paddressTown").toString()));
					address.appendChild(cityDirectory);
				}	

				if(addressData.get("paddressCity")!= null && addressData.get("paddressCity").toString().trim().length() !=0){
					Element cityDirectory = doc.createElement("city");
					cityDirectory.appendChild(doc.createTextNode(addressData.get("paddressCity").toString()));
					address.appendChild(cityDirectory);
				}
				if(addressData.get("paddressZip")!= null && addressData.get("paddressZip").toString().trim().length() !=0){
					Element cityDirectory = doc.createElement("zip");
					cityDirectory.appendChild(doc.createTextNode(addressData.get("paddressZip").toString()));
					address.appendChild(cityDirectory);
				}
				if(addressData.get("paddressCountryCode")!= null && addressData.get("paddressCountryCode").toString().trim().length() !=0){
					Element country_codeDirectory = doc.createElement("country_code");						
					country_codeDirectory.appendChild(doc.createTextNode(addressData.get("paddressCountryCode").toString()));							
					address.appendChild(country_codeDirectory);
				}
				if(addressData.get("paddressState")!= null && addressData.get("paddressState").toString().trim().length() !=0){
					Element country_codeDirectory = doc.createElement("state");						
					country_codeDirectory.appendChild(doc.createTextNode(addressData.get("paddressState").toString()));							
					address.appendChild(country_codeDirectory);
				}							
				addresses.appendChild(address);
			}
			
			if(addressData.get("address")!=null && addressData.get("address").toString().trim().length() !=0) {
				Element address = doc.createElement("address");

				Element address_typeDirectory = doc.createElement("address_type");							
				address_typeDirectory.appendChild(doc.createTextNode(addressData.get("addressType").toString()));
				address.appendChild(address_typeDirectory);
				
				if(addressData.get("address")!= null && addressData.get("address").toString().trim().length() !=0){
					Element addressActualDirectory = doc.createElement("address");							
					addressActualDirectory.appendChild(doc.createTextNode(addressData.get("address").toString()));							
					address.appendChild(addressActualDirectory);
				}
				
				if(addressData.get("addressTown")!= null && addressData.get("addressTown").toString().trim().length() !=0){
					Element cityDirectory = doc.createElement("towm");
					cityDirectory.appendChild(doc.createTextNode(addressData.get("addressTown").toString()));
					address.appendChild(cityDirectory);
				}	

				if(addressData.get("addressCity")!= null && addressData.get("addressCity").toString().trim().length() !=0){
					Element cityDirectory = doc.createElement("city");
					cityDirectory.appendChild(doc.createTextNode(addressData.get("addressCity").toString()));
					address.appendChild(cityDirectory);
				}
				if(addressData.get("addressZip")!= null && addressData.get("addressZip").toString().trim().length() !=0){
					Element cityDirectory = doc.createElement("zip");
					cityDirectory.appendChild(doc.createTextNode(addressData.get("addressZip").toString()));
					address.appendChild(cityDirectory);
				}
				if(addressData.get("addressCountryCode")!= null && addressData.get("addressCountryCode").toString().trim().length() !=0){
					Element country_codeDirectory = doc.createElement("country_code");						
					country_codeDirectory.appendChild(doc.createTextNode(addressData.get("addressCountryCode").toString()));							
					address.appendChild(country_codeDirectory);
				}
				if(addressData.get("addressState")!= null && addressData.get("addressState").toString().trim().length() !=0){
					Element country_codeDirectory = doc.createElement("state");						
					country_codeDirectory.appendChild(doc.createTextNode(addressData.get("addressState").toString()));							
					address.appendChild(country_codeDirectory);
				}							
				addresses.appendChild(address);
			}						

			rootElement.appendChild(addresses);
		} catch (Exception e) {
			e.printStackTrace();
		}
}
	
	private static void generateIdentificationElement(Document doc, Element rootElement, Map<String, Object> identificationData) {
		try {
			if(identificationData.get("idNumber")!=null ) {
				Element identification = doc.createElement("identification");
				
				if(identificationData.get("idType")!=null ) {
					Element identification_type = doc.createElement("type");
					identification_type.appendChild(doc.createTextNode(identificationData.get("idType").toString()));
					identification.appendChild(identification_type);
				}

				if(identificationData.get("idNumber")!=null ) {
					Element identificationNumber = doc.createElement("number");
					identificationNumber.appendChild(doc.createTextNode(identificationData.get("idNumber").toString().toString()));
					identification.appendChild(identificationNumber);
				}

				if(identificationData.get("idIssueDate")!=null ) {
					Element identificationIssuedDate = doc.createElement("issue_date");
					Date date = inputDateFormat.parse(identificationData.get("idIssueDate").toString()+" 00:00:00");
					identificationIssuedDate.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					identification.appendChild(identificationIssuedDate);
				}

				if(identificationData.get("idExpiryDate")!=null ) {
					Element identificationExpiryDate = doc.createElement("expiry_date");
					Date date = inputDateFormat.parse(identificationData.get("idExpiryDate").toString()+" 00:00:00");
					identificationExpiryDate.appendChild(doc.createTextNode(outputDateFormat.format(date)));
					identification.appendChild(identificationExpiryDate);
				}
				
				if(identificationData.get("idIssuedBy")!=null ) {
					Element identificationIssuedBy = doc.createElement("issued_by");
					identificationIssuedBy.appendChild(doc.createTextNode(identificationData.get("idIssuedBy").toString()));
					identification.appendChild(identificationIssuedBy);
				}

				if(identificationData.get("idIssueCountry")!=null ) {
					Element identificationIssueCountry = doc.createElement("issue_country");
					identificationIssueCountry.appendChild(doc.createTextNode(identificationData.get("idIssueCountry").toString()));
					identification.appendChild(identificationIssueCountry);
				}

				// Element comments = doc.createElement("comments");
				
				// if(ConstantConfiguration.ClientName.equalsIgnoreCase("Laxmi Bank")) {
				// 	if(identificationData.get("identification_doc_comments") !=null && identificationData.get("identification_doc_type") !=null && identificationData.get("identification_doc_type").equalsIgnoreCase("Z")) {
				// 		comments.appendChild(doc.createTextNode(identificationData.get("identification_doc_comments")));
				// 	}else {
				// 		comments.appendChild(doc.createTextNode("Not Available"));
				// 	}
				// 	identification.appendChild(comments);
				// }
				
				rootElement.appendChild(identification);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void generateReportIndicators(Document doc,Element rootElement, List<String> reportIndicatorData) {
		Element report_indicators = doc.createElement("report_indicators");
		
		for(int i=0;i<reportIndicatorData.size();i++) {
			Element indicators = doc.createElement("indicator");
			indicators.appendChild(doc.createTextNode(reportIndicatorData.get(i)));
			report_indicators.appendChild(indicators);
		}
		rootElement.appendChild(report_indicators);
	}
}
