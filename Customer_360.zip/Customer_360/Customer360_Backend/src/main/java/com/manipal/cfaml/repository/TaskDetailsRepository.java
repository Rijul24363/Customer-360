package com.manipal.cfaml.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.TaskDetails;

public interface TaskDetailsRepository extends JpaRepository<TaskDetails, String>{

	@Query(nativeQuery=true, value="SELECT  count(*) from VIZPROD.TASK_DETAILS td \r\n"
			+ "inner join CUSTOMER_PROFILE cp on cp.ACCOUNT_ID =td.ACCOUNT_ID \r\n"
			+ "where cp.CUSTOMER_ID =:customerId and td.ACCOUNT_ID =:accountId ")
	BigDecimal getSystemGeneratedCount(String customerId,String accountId);

	@Query(nativeQuery=true, value="SELECT  count(*) from VIZPROD.TASK_DETAILS  td\r\n"
			+ "inner join CUSTOMER_PROFILE cp on cp.ACCOUNT_ID =td.ACCOUNT_ID \r\n"
			+ "where td.STATUS  = 'STR Reported' and cp.CUSTOMER_ID =:customerId and td.ACCOUNT_ID =:accountId ")
	BigDecimal getSTRCount(String customerId,String accountId);
	
	@Query(nativeQuery=true, value="SELECT  count(*) from VIZPROD.TASK_DETAILS td \r\n"
			+ "inner join CUSTOMER_PROFILE cp on cp.ACCOUNT_ID =td.ACCOUNT_ID \r\n"
			+ "where cp.CUSTOMER_ID =:customerId")
	BigDecimal getSystemGeneratedCount(String customerId);

	@Query(nativeQuery=true, value="SELECT  count(*) from VIZPROD.TASK_DETAILS  td\r\n"
			+ "inner join CUSTOMER_PROFILE cp on cp.ACCOUNT_ID =td.ACCOUNT_ID \r\n"
			+ "where td.STATUS  = 'STR Reported' and cp.CUSTOMER_ID =:customerId ")
	BigDecimal getSTRCount(String customerId);

}
