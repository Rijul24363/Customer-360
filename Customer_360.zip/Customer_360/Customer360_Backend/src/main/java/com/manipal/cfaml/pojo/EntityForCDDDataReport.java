package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class EntityForCDDDataReport {

	private String fullName;
	private String shortName;
	private String dateOfEstablismentAd;
	private String dateOfEstablismentBs;
	private String businessList;
	private String incorporationNumber;
	private String incorporationAuthority;
	private String incorporatingCountry;
	private String panNumber;
	private String panIssueDateAd;
	private String typeOfIndustry;
	private String panIssueDateBs;

}
