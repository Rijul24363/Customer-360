package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "customer_id_info")
public class CustomerIdInfo {

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "PRIMARY_ID")
	private String primary;

	@Column(name = "ID_TYPE")
	private String idType;

	@Column(name = "ID_NUMBER")
	private String idNumber;

	@Column(name = "ID_ISSUE_DATE")
	private Date idIssueDate;

	@Column(name = "ID_ISSUED_BY")
	private String idIssuedBy;

	@Column(name = "ID_ISSUE_COUNTRY")
	private String idIssueCountry;

	@Column(name = "ID_EXPIRY_DATE")
	private Date idExpiryDate;

}
