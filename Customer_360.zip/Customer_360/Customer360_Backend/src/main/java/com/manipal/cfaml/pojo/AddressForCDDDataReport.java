package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class AddressForCDDDataReport {
	private String currentCountry;
	private String currentProvince;
	private String currentHouseNumber;
	private String currentDistrict;
	private String landLineNumber;
	private String currentGooglePlusCode;
	private String currentWard;
	private String currentMumbaiNumber;
	private String currentTole;
	private String currentState;
	private String currentMnVdcCity;
	private String parmanentCountry;
	private String parmanentProvince;
	private String parmanentHouseNumber;
	private String parmanentzipCode;
	private String currentzipCode;
	private String parmanentDistrict;
	private String parmanentGooglePlusCode;
	private String parmanentWard;
	private String mobileNumber;
	private String parmanentTole;
	private String parmanentState;
	private String emailAddress;
	private String parmanentmnVdcCity;
	private String parmanentCountryCode;
	private String currentCountryCode;
	private String accountId;
	private String webSite;

}
