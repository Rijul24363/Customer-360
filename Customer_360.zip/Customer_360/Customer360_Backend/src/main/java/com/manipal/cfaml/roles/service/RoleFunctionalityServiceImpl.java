package com.manipal.cfaml.roles.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.entity.UserInfo;
import com.manipal.cfaml.roles.entity.FunctionalityList;
import com.manipal.cfaml.roles.repository.RoleFunctionalityRepository;
import com.manipal.cfaml.roles.repository.UserInfoRepository;

@Service
public class RoleFunctionalityServiceImpl implements RoleFunctionalityService{
	
	@Autowired
	RoleFunctionalityRepository roleRepo;

	@Autowired
	UserInfoRepository userInfo;
	
	@Override
	public List<FunctionalityList> getPagesForRolesOnUserId(String userId) {
		return roleRepo.getPagesForRolesOnUserId(userId);
	}

	@Override
	public UserInfo getUserDetails(String userName) {
		return userInfo.getByUserName(userName);
	}

	@Override
	public Map<String, Object> getUserDetails(String userId, String roleId) {
		return userInfo.getUserDetailsAndRoleDetails(userId,roleId);
	}


}
