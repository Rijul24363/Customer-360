package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "CRR_COMPUTATION_INFO", schema = "VIZPROD")
public class CrrComputationInfo {

	@Id
	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "ACCOUNT_ID")
	private String accountId;

	@Column(name = "COMPUTATION_INFO")
	private String computationInfo;

	@Column(name = "COMPUTED_DATE")
	private Date computedDate;

	@Column(name = "CRR_RATING")
	private String crrRating;
}
