package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="GOAML_TRANSMODE_FUNDS_CODE")
public class GoamlTransModeFundsCode {

	@Id
	@Column(name = "TRANSMODE_CODE")      
	private String transactionMode;
	
	@Column(name = "FUNDS_CODE")      
	private String fundsCode;
	
	@Column(name = "TRANS_FUNDS_CD")      
	private String transFundsCode;
	
	@Column(name = "DESCRIPTION")      
	private String description;
}
