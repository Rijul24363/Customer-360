package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.KycMasterData;

public interface KycMasterDataRepository extends JpaRepository<KycMasterData, String> {

	@Query(nativeQuery = true, value = "select FIELD_NAME,FULLY_CLASSIFIED_NAME,TITLE  from KYC_MASTER_DATA kmd WHERE AVAILABILITY ='m' AND POLICY ='Bank Policy'")
	List<Map<String, Object>> getKycMasterData();
	

}
