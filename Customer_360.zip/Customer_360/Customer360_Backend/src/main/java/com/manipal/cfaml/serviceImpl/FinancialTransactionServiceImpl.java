package com.manipal.cfaml.serviceImpl;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.repository.CustomerRepositoryCustom;
import com.manipal.cfaml.repository.FinancialTransactionRepository;
import com.manipal.cfaml.repository.ManualAlertRepository;
import com.manipal.cfaml.repository.TaskDetailsRepository;
import com.manipal.cfaml.service.FinancialTransactionService;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Service
public class FinancialTransactionServiceImpl implements FinancialTransactionService {
	
	@Autowired
	FinancialTransactionRepository financialTransactionRepo;
	
	@Autowired
	CustomerRepositoryCustom customerRepoCustomer;
	
	@Autowired
	TaskDetailsRepository taskDetailsRepo;
	
	@Autowired
	ManualAlertRepository manualAlertRepo;
	
	@Override
	public Map<String, Object> getTransactionDetailsBasedOnChannels(String custId,String startDate, String endDate,String accountId) throws ParseException {
		Map<String, Object> res= new HashMap<String,Object>();
		startDate=startDate+" 00:00:00.000";
		endDate=endDate+" 23:59:59.000";
		if(accountId.equalsIgnoreCase("ALL")) {
			res.put("getTxnCountAndChannel", financialTransactionRepo.getTxnAmtAndChannel(custId,startDate,endDate));
			res.put("getModeWiseTxnAmtAndCount", financialTransactionRepo.getModeWiseTxnAmtAndCount(custId,startDate,endDate));
			res.put("TTRCount", customerRepoCustomer.getTTRCount(custId,accountId, startDate, endDate));
			res.put("getSystemGeneratedCount", taskDetailsRepo.getSystemGeneratedCount(custId));
			res.put("getManualGeneratedCount", manualAlertRepo.getManualGeneratedCount(custId));
			res.put("STRCount", taskDetailsRepo.getSTRCount(custId));
			res.put("getTransModeFundType", customerRepoCustomer.getTransModeFundType(custId,startDate,endDate));

		}else {
			res.put("getTxnCountAndChannel", financialTransactionRepo.getTxnAmtAndChannel(custId,accountId,startDate,endDate));
			res.put("getModeWiseTxnAmtAndCount", financialTransactionRepo.getModeWiseTxnAmtAndCount(custId,accountId,startDate,endDate));
			res.put("TTRCount", customerRepoCustomer.getTTRCount(custId,accountId, startDate, endDate));
			res.put("getSystemGeneratedCount", taskDetailsRepo.getSystemGeneratedCount(custId,accountId));
			res.put("getManualGeneratedCount", manualAlertRepo.getManualGeneratedCount(custId,accountId));
			res.put("STRCount", taskDetailsRepo.getSTRCount(custId,accountId));
			res.put("getTransModeFundType", customerRepoCustomer.getTransModeFundType(custId,accountId,startDate,endDate));

		}
		return res;
	}

}
