package com.manipal.cfaml.roles.service;

import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.manipal.cfaml.pojo.AccountForCDDDataReport;
import com.manipal.cfaml.pojo.AccountPersonForCDDDatReportList;
import com.manipal.cfaml.pojo.AddressForCDDDataReport;
import com.manipal.cfaml.pojo.CDDReportFieldsConfig;
import com.manipal.cfaml.pojo.EntityForCDDDataReport;
import com.manipal.cfaml.pojo.FamilyForCDDDataReport;
import com.manipal.cfaml.pojo.IdentificationForCDDDataReport;
import com.manipal.cfaml.pojo.PersonForCDDDataReport;
import com.manipal.cfaml.pojo.RevenueForCDDDataReport;
import com.manipal.cfaml.roles.entity.FunctionalityList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleFunctionalityForCDD {
	
	private Boolean personal= false;
	private Boolean entity = false;
	private Boolean identification = false;
	private Boolean address = false;
	private Boolean account = false;
	private Boolean revenue = false;
	private Boolean family = false;
	private Boolean nominee = false;
	private Boolean beneficiary = false;
	private Boolean signatories = false;
	private Boolean directors = false;
	private Boolean other = false;
	
	public RoleFunctionalityForCDD getRoleWiseTabs(List<FunctionalityList> roleList){
		RoleFunctionalityForCDD roleSet=new RoleFunctionalityForCDD();
		for (FunctionalityList functionalityList : roleList) {
			  if(functionalityList.getFunctionalityName().equalsIgnoreCase("Personal")){
				  roleSet.setPersonal(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Entity")){
		        	roleSet.setEntity(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Identification")){
		        	roleSet.setIdentification(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Address")){
		        	roleSet.setAddress(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Account")){
		        	roleSet.setAccount(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Revenue")){
		        	roleSet.setRevenue(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Family")){
		        	roleSet.setFamily(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Nominee")){
		        	roleSet.setNominee(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Beneficiary")){
		        	roleSet.setBeneficiary(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Signatories")){
		        	roleSet.setSignatories(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Directors")){
		        	roleSet.setDirectors(true);
		        }
		        else if(functionalityList.getFunctionalityName().equalsIgnoreCase("Other")){
		        	roleSet.setOther(true);
		        }
		}
		return roleSet;
		
	}
	
	
	public CDDReportFieldsConfig hideFieldsDataConfig(Map<String, Object> configFile) {
		CDDReportFieldsConfig dataHide=CDDReportFieldsConfig.builder()
				.personalForm(personalFields((Map<String, Object>) configFile.get("personalForm")))
				.entityForm(entityForm((Map<String, Object>) configFile.get("entityForm")))
				.identificationForm(identificationForm((Map<String, Object>) configFile.get("identificationForm")))
				.addressForm(addressForm((Map<String, Object>) configFile.get("addressForm")))
				.accountForm(accountForm((Map<String, Object>) configFile.get("accountForm")))
				.revenueForm(revenueForm((Map<String, Object>) configFile.get("revenueForm")))
				.familyForm(familyForm((Map<String, Object>) configFile.get("familyForm")))
				.nomineeForm(nomineeForm((Map<String, Object>) configFile.get("nomineeForm")))
				.beneficiaryForm(beneficiaryForm((Map<String, Object>) configFile.get("beneficiaryForm")))
				.signatoriesForm(signatoriesForm((Map<String, Object>) configFile.get("signatoriesForm")))
				.directorsForm(directorsForm((Map<String, Object>) configFile.get("directorsForm")))
				.build();
		return dataHide;
	}
	
	public PersonForCDDDataReport personalFields(Map<String, Object> personalForm2){
		PersonForCDDDataReport personalForm=PersonForCDDDataReport.builder().
				salutation(convertObjectIntoBoolean(personalForm2.get("salutation").toString())).
				shortName(convertObjectIntoBoolean(personalForm2.get("shortName").toString())).
				age(convertObjectIntoBoolean(personalForm2.get("age").toString())).
				lastName(convertObjectIntoBoolean(personalForm2.get("lastName").toString())).
				dateOfBirthAd(convertObjectIntoBoolean(personalForm2.get("dateOfBirthAd").toString())).
				dateOfBirthBs(convertObjectIntoBoolean(personalForm2.get("dateOfBirthBs").toString())).
				firstName(convertObjectIntoBoolean(personalForm2.get("firstName").toString())).
				middleName(convertObjectIntoBoolean(personalForm2.get("middleName").toString())).
				gender(convertObjectIntoBoolean(personalForm2.get("gender").toString())).
				maritalStatus(convertObjectIntoBoolean(personalForm2.get("maritalStatus").toString())).
				educationLevel(convertObjectIntoBoolean(personalForm2.get("educationLevel").toString())).
				residence(convertObjectIntoBoolean(personalForm2.get("residence").toString())).
				nationality(convertObjectIntoBoolean(personalForm2.get("nationality").toString())).
				build();
		return personalForm;
	}
	
	public EntityForCDDDataReport entityForm(Map<String, Object> map){
		EntityForCDDDataReport entityForm=EntityForCDDDataReport.builder().
				 fullName(convertObjectIntoBoolean(map.get("fullName").toString()))
					.shortName(convertObjectIntoBoolean(map.get("shortName").toString()))
					.dateOfEstablismentAd(convertObjectIntoBoolean(map.get("dateOfEstablismentAd").toString()))
					.dateOfEstablismentBs(convertObjectIntoBoolean(map.get("dateOfEstablismentBs").toString()))
					.businessList(convertObjectIntoBoolean(map.get("businessList").toString()))
					.incorporationNumber(convertObjectIntoBoolean(map.get("incorporationNumber").toString()))
					.incorporationAuthority(convertObjectIntoBoolean(map.get("incorporatingBody").toString()))
					.incorporatingCountry(convertObjectIntoBoolean(map.get("incorporatingCountry").toString()))
					.panNumber(convertObjectIntoBoolean(map.get("panNumber").toString()))
					.panIssueDateAd(convertObjectIntoBoolean(map.get("panIssueDateAd").toString()))
					.panIssueDateBs(convertObjectIntoBoolean(map.get("panIssueDateBs").toString()))
					.typeOfIndustry(convertObjectIntoBoolean(map.get("typeOfIndustry").toString()))
				.build();
		return entityForm;
	}
	
	public IdentificationForCDDDataReport identificationForm(Map<String, Object> map) {
		IdentificationForCDDDataReport data=IdentificationForCDDDataReport.builder().
			identificationDocType(convertObjectIntoBoolean(map.get("identificationDocType").toString())).
			identificationDocNumber(convertObjectIntoBoolean(map.get("identificationDocNumber").toString())).
			identificationDocIssuedDateAd(convertObjectIntoBoolean(map.get("identificationDocIssuedDateAd").toString())).
			identificationDocIssuedDateBs(convertObjectIntoBoolean(map.get("identificationDocIssuedDateBs").toString())).
			idenificationDocIssuedBy(convertObjectIntoBoolean(map.get("idenificationDocIssuedBy").toString())).
			expiredDateAd(convertObjectIntoBoolean(map.get("expiredDateAd").toString())).
			expiredDateBs(convertObjectIntoBoolean(map.get("expiredDateBs").toString())).
			countryOfIssue(convertObjectIntoBoolean(map.get("countryOfIssue").toString())).
			build();
		return data;
	}
	
	public FamilyForCDDDataReport familyForm(Map<String, Object> map){
		FamilyForCDDDataReport data=FamilyForCDDDataReport.builder().
				fatherName(convertObjectIntoBoolean(map.get("fatherName").toString())).
				motherName(convertObjectIntoBoolean(map.get("motherName").toString())).
				spouseName(convertObjectIntoBoolean(map.get("spouseName").toString())).
				grandFatherName(convertObjectIntoBoolean(map.get("grandFatherName").toString())).
				grandMotherName(convertObjectIntoBoolean(map.get("grandMotherName").toString())).
				sonFullName(convertObjectIntoBoolean(map.get("sonFullName").toString())).
				daughterFullName(convertObjectIntoBoolean(map.get("daughterFullName").toString())).
				daughterFullName2(convertObjectIntoBoolean(map.get("daughterFullName2").toString())).
				sonFullName2(convertObjectIntoBoolean(map.get("sonFullName2").toString())).
				build();
		return data;

	}
	
	public RevenueForCDDDataReport revenueForm(Map<String, Object> map){			
			RevenueForCDDDataReport data=RevenueForCDDDataReport.builder().
					nameOfTheEmployer(convertObjectIntoBoolean(map.get("nameOfTheEmployer").toString())).
					designation(convertObjectIntoBoolean(map.get("designation").toString())).
					employerLineOfBusiness(convertObjectIntoBoolean(map.get("employerLineOfBusiness").toString())).
					workExperience(convertObjectIntoBoolean(map.get("workExperience").toString())).
					department(convertObjectIntoBoolean(map.get("department").toString())).
					regularSourceOfIncome(convertObjectIntoBoolean(map.get("regularSourceOfIncome").toString())).
					sourceOfWealth(convertObjectIntoBoolean(map.get("sourceOfWealth").toString())).
					netWorth(convertObjectIntoBoolean(map.get("netWorth").toString())).
					panNumber(convertObjectIntoBoolean(map.get("panNumber").toString())).
					employersContactNumber(convertObjectIntoBoolean(map.get("employersContactNumber").toString())).
					parmanentHouseNumber(convertObjectIntoBoolean(map.get("parmanentHouseNumber").toString())).
					parmanentTole(convertObjectIntoBoolean(map.get("parmanentTole").toString())).
					parmanentDistrict(convertObjectIntoBoolean(map.get("parmanentDistrict").toString())).
					parmanentmnVdcCity(convertObjectIntoBoolean(map.get("parmanentmnVdcCity").toString())).
					parmanentProvince(convertObjectIntoBoolean(map.get("parmanentProvince").toString())).
					parmanentCountry(convertObjectIntoBoolean(map.get("parmanentCountry").toString())).
					parmanentCountryCode(convertObjectIntoBoolean(map.get("parmanentCountryCode").toString())).
					parmanentGooglePlusCode(convertObjectIntoBoolean(map.get("parmanentGooglePlusCode").toString())).
					nameOfBusiness(convertObjectIntoBoolean(map.get("nameOfBusiness").toString())).
					typeOfBusiness(convertObjectIntoBoolean(map.get("typeOfBusiness").toString())).
					lineOfBusiness(convertObjectIntoBoolean(map.get("lineOfBusiness").toString())).
					contactNumber(convertObjectIntoBoolean(map.get("contactNumber").toString())).
					sourceOfIncomeOfTheProvider(convertObjectIntoBoolean(map.get("sourceOfIncomeOfTheProvider").toString())).
					parmanentzipCode(convertObjectIntoBoolean(map.get("parmanentzipCode").toString())).
				build();
		return data;
	}
	
	public AddressForCDDDataReport addressForm(Map<String, Object> map){	
		AddressForCDDDataReport data = AddressForCDDDataReport.builder().
				landLineNumber(convertObjectIntoBoolean(map.get("landLineNumber").toString())).
				mobileNumber(convertObjectIntoBoolean(map.get("mobileNumber").toString())).
				emailAddress(convertObjectIntoBoolean(map.get("emailAddress").toString())).
				currentHouseNumber(convertObjectIntoBoolean(map.get("currentHouseNumber").toString())).
				currentTole(convertObjectIntoBoolean(map.get("currentTole").toString())).
				currentWard(convertObjectIntoBoolean(map.get("currentWard").toString())).
				currentDistrict(convertObjectIntoBoolean(map.get("currentDistrict").toString())).
				currentCountry(convertObjectIntoBoolean(map.get("currentCountry").toString())).
				currentProvince(convertObjectIntoBoolean(map.get("currentProvince").toString())).
				currentCountryCode(convertObjectIntoBoolean(map.get("currentCountryCode").toString())).
				currentGooglePlusCode(convertObjectIntoBoolean(map.get("currentGooglePlusCode").toString())).
				currentMnVdcCity(convertObjectIntoBoolean(map.get("currentMnVdcCity").toString())).
				parmanentHouseNumber(convertObjectIntoBoolean(map.get("parmanentHouseNumber").toString())).
				parmanentTole(convertObjectIntoBoolean(map.get("parmanentTole").toString())).
				parmanentWard(convertObjectIntoBoolean(map.get("parmanentWard").toString())).
				parmanentDistrict(convertObjectIntoBoolean(map.get("parmanentDistrict").toString())).
				parmanentmnVdcCity(convertObjectIntoBoolean(map.get("parmanentmnVdcCity").toString())).
				parmanentProvince(convertObjectIntoBoolean(map.get("parmanentProvince").toString())).
				parmanentCountry(convertObjectIntoBoolean(map.get("parmanentCountry").toString())).
				parmanentCountryCode(convertObjectIntoBoolean(map.get("parmanentCountryCode").toString())).
				parmanentGooglePlusCode(convertObjectIntoBoolean(map.get("parmanentGooglePlusCode").toString())).
				parmanentzipCode(convertObjectIntoBoolean(map.get("parmanentzipCode").toString())).
				currentzipCode(convertObjectIntoBoolean(map.get("currentzipCode").toString())).
				webSite(convertObjectIntoBoolean(map.get("website").toString())).
					build();
			return data;
	}
	
	public AccountForCDDDataReport accountForm(Map<String, Object> map){
		AccountForCDDDataReport data =AccountForCDDDataReport.builder().
				estimatedMonthlyIncome(convertObjectIntoBoolean(map.get("estimatedMonthlyIncome").toString())).
				 estimatedAnnualIncome(convertObjectIntoBoolean(map.get("estimatedAnnualIncome").toString())).
				 estimatedAnnualTurnover(convertObjectIntoBoolean(map.get("estimatedAnnualTurnover").toString())).
				 accountCurrency(convertObjectIntoBoolean(map.get("accountCurrency").toString())).
				 accountOpeningDate(convertObjectIntoBoolean(map.get("accountOpeningDate").toString())).
				 accountAge(convertObjectIntoBoolean(map.get("accountAge").toString())).
				 accountBranch(convertObjectIntoBoolean(map.get("accountBranch").toString())).
				 accountType(convertObjectIntoBoolean(map.get("accountType").toString())).
				 accountName(convertObjectIntoBoolean(map.get("accountName").toString())).
				 accountNumber(convertObjectIntoBoolean(map.get("accountNumber").toString())).
				 purposeOfAccount(convertObjectIntoBoolean(map.get("purposeOfAccount").toString())).
				 upperLimitOnLoanAccounts(convertObjectIntoBoolean(map.get("upperLimitOnLoanAccounts").toString())).
				 relatedPersonalType(convertObjectIntoBoolean(map.get("relatedPersonalType").toString())).
				 accountStatusType(convertObjectIntoBoolean(map.get("accountStatusType").toString())).
							 build();
				return data;
	}
	
	public AccountPersonForCDDDatReportList nomineeForm(Map<String, Object> map){
		AccountPersonForCDDDatReportList data=AccountPersonForCDDDatReportList.builder().
				  fullName(convertObjectIntoBoolean(map.get("fullName").toString())).
		            relationship(convertObjectIntoBoolean(map.get("relationship").toString())).
		            contactNumber(convertObjectIntoBoolean(map.get("contactNumber").toString())).
		            dateOfBirthAd(convertObjectIntoBoolean(map.get("dateOfBirthAd").toString())).
		            pPrimaryIdType(convertObjectIntoBoolean(map.get("pPrimaryIdType").toString())).
		            pPrimaryIdNumber(convertObjectIntoBoolean(map.get("pPrimaryIdNumber").toString())).
		            pIssueDateAd(convertObjectIntoBoolean(map.get("pIssueDateAd").toString())).
		            pIssueDateBs(convertObjectIntoBoolean(map.get("pIssueDateBs").toString())).
		            tPrimaryIdType(convertObjectIntoBoolean(map.get("tPrimaryIdType").toString())).
		            tPrimaryIdNumber(convertObjectIntoBoolean(map.get("tPrimaryIdNumber").toString())).
		            tIssueDateAd(convertObjectIntoBoolean(map.get("tIssueDateAd").toString())).
		            tIssueDateBs(convertObjectIntoBoolean(map.get("tIssueDateBs").toString())).
		            pIssueAuthority(convertObjectIntoBoolean(map.get("pIssueAuthority").toString())).
		            tIssueAuthority(convertObjectIntoBoolean(map.get("tIssueAuthority").toString())).
		            pIssuseCountry(convertObjectIntoBoolean(map.get("pIssuseCountry").toString())).
		            tIssuseCountry(convertObjectIntoBoolean(map.get("tIssuseCountry").toString())).
		            dateOfBirthBs(convertObjectIntoBoolean(map.get("dateOfBirthBs").toString())).
		            currentWard(convertObjectIntoBoolean(map.get("currentWard").toString())).
		            currentDistrict(convertObjectIntoBoolean(map.get("currentDistrict").toString())).
		            currentmnVdcCity(convertObjectIntoBoolean(map.get("currentmnVdcCity").toString())).
		            currentProvince(convertObjectIntoBoolean(map.get("currentProvince").toString())).
		            currentCountry(convertObjectIntoBoolean(map.get("currentCountry").toString())).
		            currentCountryCode(convertObjectIntoBoolean(map.get("currentCountryCode").toString())).
		            currentGooglePlusCode(convertObjectIntoBoolean(map.get("currentGooglePlusCode").toString())).
		            parmanentHouseNumber(convertObjectIntoBoolean(map.get("parmanentHouseNumber").toString())).
		            parmanentTole(convertObjectIntoBoolean(map.get("parmanentTole").toString())).
		            parmanentDistrict(convertObjectIntoBoolean(map.get("parmanentDistrict").toString())).
		            parmanentmnVdcCity(convertObjectIntoBoolean(map.get("parmanentmnVdcCity").toString())).
		            parmanentProvince(convertObjectIntoBoolean(map.get("parmanentProvince").toString())).
		            parmanentCountry(convertObjectIntoBoolean(map.get("parmanentCountry").toString())).
		            parmanentCountryCode(convertObjectIntoBoolean(map.get("parmanentCountryCode").toString())).
		            parmanentGooglePlusCode(convertObjectIntoBoolean(map.get("parmanentGooglePlusCode").toString())).
		            parmanentzipCode(convertObjectIntoBoolean(map.get("parmanentzipCode").toString())).
		            currentzipCode(convertObjectIntoBoolean(map.get("currentzipCode").toString())).
		            pExpiryDateAd(convertObjectIntoBoolean(map.get("pExpiryDateAd").toString())).
		            pExpiryDateBs(convertObjectIntoBoolean(map.get("pExpiryDateBs").toString())).
		            tExpiryDateAd(convertObjectIntoBoolean(map.get("tExpiryDateAd").toString())).
		            tExpiryDateBs(convertObjectIntoBoolean(map.get("tExpiryDateBs").toString())).
		            currentHouseNumber(convertObjectIntoBoolean(map.get("currentHouseNumber").toString())).
		            currentTole(convertObjectIntoBoolean(map.get("currentTole").toString())).
		            parmanentWard(convertObjectIntoBoolean(map.get("parmanentWard").toString())).
			            build();
					return data;
	}

	public AccountPersonForCDDDatReportList beneficiaryForm(Map<String, Object> map){
		AccountPersonForCDDDatReportList data=AccountPersonForCDDDatReportList.builder().
				  fullName(convertObjectIntoBoolean(map.get("fullName").toString())).
		            relationship(convertObjectIntoBoolean(map.get("relationship").toString())).
		            contactNumber(convertObjectIntoBoolean(map.get("contactNumber").toString())).
		            dateOfBirthAd(convertObjectIntoBoolean(map.get("dateOfBirthAd").toString())).
		            pPrimaryIdType(convertObjectIntoBoolean(map.get("pPrimaryIdType").toString())).
		            pPrimaryIdNumber(convertObjectIntoBoolean(map.get("pPrimaryIdNumber").toString())).
		            pIssueDateAd(convertObjectIntoBoolean(map.get("pIssueDateAd").toString())).
		            pIssueDateBs(convertObjectIntoBoolean(map.get("pIssueDateBs").toString())).
		            tPrimaryIdType(convertObjectIntoBoolean(map.get("tPrimaryIdType").toString())).
		            tPrimaryIdNumber(convertObjectIntoBoolean(map.get("tPrimaryIdNumber").toString())).
		            tIssueDateAd(convertObjectIntoBoolean(map.get("tIssueDateAd").toString())).
		            tIssueDateBs(convertObjectIntoBoolean(map.get("tIssueDateBs").toString())).
		            pIssueAuthority(convertObjectIntoBoolean(map.get("pIssueAuthority").toString())).
		            tIssueAuthority(convertObjectIntoBoolean(map.get("tIssueAuthority").toString())).
		            pIssuseCountry(convertObjectIntoBoolean(map.get("pIssuseCountry").toString())).
		            tIssuseCountry(convertObjectIntoBoolean(map.get("tIssuseCountry").toString())).
		            dateOfBirthBs(convertObjectIntoBoolean(map.get("dateOfBirthBs").toString())).
		            currentWard(convertObjectIntoBoolean(map.get("currentWard").toString())).
		            currentDistrict(convertObjectIntoBoolean(map.get("currentDistrict").toString())).
		            currentmnVdcCity(convertObjectIntoBoolean(map.get("currentmnVdcCity").toString())).
		            currentProvince(convertObjectIntoBoolean(map.get("currentProvince").toString())).
		            currentCountry(convertObjectIntoBoolean(map.get("currentCountry").toString())).
		            currentCountryCode(convertObjectIntoBoolean(map.get("currentCountryCode").toString())).
		            currentGooglePlusCode(convertObjectIntoBoolean(map.get("currentGooglePlusCode").toString())).
		            parmanentHouseNumber(convertObjectIntoBoolean(map.get("parmanentHouseNumber").toString())).
		            parmanentTole(convertObjectIntoBoolean(map.get("parmanentTole").toString())).
		            parmanentDistrict(convertObjectIntoBoolean(map.get("parmanentDistrict").toString())).
		            parmanentmnVdcCity(convertObjectIntoBoolean(map.get("parmanentmnVdcCity").toString())).
		            parmanentProvince(convertObjectIntoBoolean(map.get("parmanentProvince").toString())).
		            parmanentCountry(convertObjectIntoBoolean(map.get("parmanentCountry").toString())).
		            parmanentCountryCode(convertObjectIntoBoolean(map.get("parmanentCountryCode").toString())).
		            parmanentGooglePlusCode(convertObjectIntoBoolean(map.get("parmanentGooglePlusCode").toString())).
		            parmanentzipCode(convertObjectIntoBoolean(map.get("parmanentzipCode").toString())).
		            currentzipCode(convertObjectIntoBoolean(map.get("currentzipCode").toString())).
		            pExpiryDateAd(convertObjectIntoBoolean(map.get("pExpiryDateAd").toString())).
		            pExpiryDateBs(convertObjectIntoBoolean(map.get("pExpiryDateBs").toString())).
		            tExpiryDateAd(convertObjectIntoBoolean(map.get("tExpiryDateAd").toString())).
		            tExpiryDateBs(convertObjectIntoBoolean(map.get("tExpiryDateBs").toString())).
		            currentHouseNumber(convertObjectIntoBoolean(map.get("currentHouseNumber").toString())).
		            currentTole(convertObjectIntoBoolean(map.get("currentTole").toString())).
		            parmanentWard(convertObjectIntoBoolean(map.get("parmanentWard").toString())).
			            build();
					return data;
	}

	public AccountPersonForCDDDatReportList signatoriesForm(Map<String, Object> map){
		AccountPersonForCDDDatReportList data=AccountPersonForCDDDatReportList.builder().
				  fullName(convertObjectIntoBoolean(map.get("fullName").toString())).
		            relationship(convertObjectIntoBoolean(map.get("relationship").toString())).
		            contactNumber(convertObjectIntoBoolean(map.get("contactNumber").toString())).
		            dateOfBirthAd(convertObjectIntoBoolean(map.get("dateOfBirthAd").toString())).
		            pPrimaryIdType(convertObjectIntoBoolean(map.get("pPrimaryIdType").toString())).
		            pPrimaryIdNumber(convertObjectIntoBoolean(map.get("pPrimaryIdNumber").toString())).
		            pIssueDateAd(convertObjectIntoBoolean(map.get("pIssueDateAd").toString())).
		            pIssueDateBs(convertObjectIntoBoolean(map.get("pIssueDateBs").toString())).
		            tPrimaryIdType(convertObjectIntoBoolean(map.get("tPrimaryIdType").toString())).
		            tPrimaryIdNumber(convertObjectIntoBoolean(map.get("tPrimaryIdNumber").toString())).
		            tIssueDateAd(convertObjectIntoBoolean(map.get("tIssueDateAd").toString())).
		            tIssueDateBs(convertObjectIntoBoolean(map.get("tIssueDateBs").toString())).
		            pIssueAuthority(convertObjectIntoBoolean(map.get("pIssueAuthority").toString())).
		            tIssueAuthority(convertObjectIntoBoolean(map.get("tIssueAuthority").toString())).
		            pIssuseCountry(convertObjectIntoBoolean(map.get("pIssuseCountry").toString())).
		            tIssuseCountry(convertObjectIntoBoolean(map.get("tIssuseCountry").toString())).
		            dateOfBirthBs(convertObjectIntoBoolean(map.get("dateOfBirthBs").toString())).
		            currentWard(convertObjectIntoBoolean(map.get("currentWard").toString())).
		            currentDistrict(convertObjectIntoBoolean(map.get("currentDistrict").toString())).
		            currentmnVdcCity(convertObjectIntoBoolean(map.get("currentmnVdcCity").toString())).
		            currentProvince(convertObjectIntoBoolean(map.get("currentProvince").toString())).
		            currentCountry(convertObjectIntoBoolean(map.get("currentCountry").toString())).
		            currentCountryCode(convertObjectIntoBoolean(map.get("currentCountryCode").toString())).
		            currentGooglePlusCode(convertObjectIntoBoolean(map.get("currentGooglePlusCode").toString())).
		            parmanentHouseNumber(convertObjectIntoBoolean(map.get("parmanentHouseNumber").toString())).
		            parmanentTole(convertObjectIntoBoolean(map.get("parmanentTole").toString())).
		            parmanentDistrict(convertObjectIntoBoolean(map.get("parmanentDistrict").toString())).
		            parmanentmnVdcCity(convertObjectIntoBoolean(map.get("parmanentmnVdcCity").toString())).
		            parmanentProvince(convertObjectIntoBoolean(map.get("parmanentProvince").toString())).
		            parmanentCountry(convertObjectIntoBoolean(map.get("parmanentCountry").toString())).
		            parmanentCountryCode(convertObjectIntoBoolean(map.get("parmanentCountryCode").toString())).
		            parmanentGooglePlusCode(convertObjectIntoBoolean(map.get("parmanentGooglePlusCode").toString())).
		            parmanentzipCode(convertObjectIntoBoolean(map.get("parmanentzipCode").toString())).
		            currentzipCode(convertObjectIntoBoolean(map.get("currentzipCode").toString())).
		            pExpiryDateAd(convertObjectIntoBoolean(map.get("pExpiryDateAd").toString())).
		            pExpiryDateBs(convertObjectIntoBoolean(map.get("pExpiryDateBs").toString())).
		            tExpiryDateAd(convertObjectIntoBoolean(map.get("tExpiryDateAd").toString())).
		            tExpiryDateBs(convertObjectIntoBoolean(map.get("tExpiryDateBs").toString())).
		            currentHouseNumber(convertObjectIntoBoolean(map.get("currentHouseNumber").toString())).
		            currentTole(convertObjectIntoBoolean(map.get("currentTole").toString())).
		            parmanentWard(convertObjectIntoBoolean(map.get("parmanentWard").toString())).
			            build();
					return data;
	}

	public AccountPersonForCDDDatReportList directorsForm(Map<String, Object> map){
		AccountPersonForCDDDatReportList data=AccountPersonForCDDDatReportList.builder().
				  fullName(convertObjectIntoBoolean(map.get("fullName").toString())).
		            relationship(convertObjectIntoBoolean(map.get("relationship").toString())).
		            contactNumber(convertObjectIntoBoolean(map.get("contactNumber").toString())).
		            dateOfBirthAd(convertObjectIntoBoolean(map.get("dateOfBirthAd").toString())).
		            pPrimaryIdType(convertObjectIntoBoolean(map.get("pPrimaryIdType").toString())).
		            pPrimaryIdNumber(convertObjectIntoBoolean(map.get("pPrimaryIdNumber").toString())).
		            pIssueDateAd(convertObjectIntoBoolean(map.get("pIssueDateAd").toString())).
		            pIssueDateBs(convertObjectIntoBoolean(map.get("pIssueDateBs").toString())).
		            tPrimaryIdType(convertObjectIntoBoolean(map.get("tPrimaryIdType").toString())).
		            tPrimaryIdNumber(convertObjectIntoBoolean(map.get("tPrimaryIdNumber").toString())).
		            tIssueDateAd(convertObjectIntoBoolean(map.get("tIssueDateAd").toString())).
		            tIssueDateBs(convertObjectIntoBoolean(map.get("tIssueDateBs").toString())).
		            pIssueAuthority(convertObjectIntoBoolean(map.get("pIssueAuthority").toString())).
		            tIssueAuthority(convertObjectIntoBoolean(map.get("tIssueAuthority").toString())).
		            pIssuseCountry(convertObjectIntoBoolean(map.get("pIssuseCountry").toString())).
		            tIssuseCountry(convertObjectIntoBoolean(map.get("tIssuseCountry").toString())).
		            dateOfBirthBs(convertObjectIntoBoolean(map.get("dateOfBirthBs").toString())).
		            currentWard(convertObjectIntoBoolean(map.get("currentWard").toString())).
		            currentDistrict(convertObjectIntoBoolean(map.get("currentDistrict").toString())).
		            currentmnVdcCity(convertObjectIntoBoolean(map.get("currentmnVdcCity").toString())).
		            currentProvince(convertObjectIntoBoolean(map.get("currentProvince").toString())).
		            currentCountry(convertObjectIntoBoolean(map.get("currentCountry").toString())).
		            currentCountryCode(convertObjectIntoBoolean(map.get("currentCountryCode").toString())).
		            currentGooglePlusCode(convertObjectIntoBoolean(map.get("currentGooglePlusCode").toString())).
		            parmanentHouseNumber(convertObjectIntoBoolean(map.get("parmanentHouseNumber").toString())).
		            parmanentTole(convertObjectIntoBoolean(map.get("parmanentTole").toString())).
		            parmanentDistrict(convertObjectIntoBoolean(map.get("parmanentDistrict").toString())).
		            parmanentmnVdcCity(convertObjectIntoBoolean(map.get("parmanentmnVdcCity").toString())).
		            parmanentProvince(convertObjectIntoBoolean(map.get("parmanentProvince").toString())).
		            parmanentCountry(convertObjectIntoBoolean(map.get("parmanentCountry").toString())).
		            parmanentCountryCode(convertObjectIntoBoolean(map.get("parmanentCountryCode").toString())).
		            parmanentGooglePlusCode(convertObjectIntoBoolean(map.get("parmanentGooglePlusCode").toString())).
		            parmanentzipCode(convertObjectIntoBoolean(map.get("parmanentzipCode").toString())).
		            currentzipCode(convertObjectIntoBoolean(map.get("currentzipCode").toString())).
		            pExpiryDateAd(convertObjectIntoBoolean(map.get("pExpiryDateAd").toString())).
		            pExpiryDateBs(convertObjectIntoBoolean(map.get("pExpiryDateBs").toString())).
		            tExpiryDateAd(convertObjectIntoBoolean(map.get("tExpiryDateAd").toString())).
		            tExpiryDateBs(convertObjectIntoBoolean(map.get("tExpiryDateBs").toString())).
		            currentHouseNumber(convertObjectIntoBoolean(map.get("currentHouseNumber").toString())).
		            currentTole(convertObjectIntoBoolean(map.get("currentTole").toString())).
		            parmanentWard(convertObjectIntoBoolean(map.get("parmanentWard").toString())).
			            build();
					return data;
	}
	
	String convertObjectIntoBoolean(String ob){
		JSONObject ob2 = null;
		try {
			ob2 = new JSONObject(ob);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String visible="false";
		try {
			visible= ob2.get("visible").toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return visible;
	}


}
