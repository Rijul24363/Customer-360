package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Builder
@Entity
@Table(name = "KYC_MASTER_DATA")
public class KycMasterData {

	@Id
	@Column(name = "FIELD_NAME")
	private String fieldName;

	@Column(name = "FILED_DATA_TYPE")
	private String filedDataType;
	
	@Column(name = "AVAILABILITY")
	private String availability;
	
	@Column(name = "FULLY_CLASSIFIED_NAME")
	private String fullyClassifiedName;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "POLICY")
	private String policy;

}
