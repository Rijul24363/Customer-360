package com.manipal.cfaml.repository;


import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.manipal.cfaml.entity.CrrComputationInfo;

@Repository
public interface CrrComputationInfoRepository extends JpaRepository<CrrComputationInfo, String> {
	
	@Query(nativeQuery = true, value = "SELECT TOP 1 c.COMPUTATION_INFO, cp.CRR as CRR_RATING,c.AUTO_OVERRIDE,cp.CRR_SYSTEM "
            + "FROM VIZPROD.CRR_COMPUTATION_INFO c "
            + "JOIN CUSTOMER_PROFILE cp ON c.CUSTOMER_ID = cp.CUSTOMER_ID "
            + "WHERE c.CUSTOMER_ID = :customerId "
            + "AND c.ACCOUNT_ID = :accountId "
            + "AND cp.UPDATED_DATE >= CONVERT(datetime, :startDate) "
            + "AND cp.UPDATED_DATE <= CONVERT(datetime, :endDate) "
            + "AND c.COMPUTED_DATE >= CONVERT(datetime, :startDate) "
            + "AND c.COMPUTED_DATE <= CONVERT(datetime, :endDate) "
            + "ORDER BY cp.PROFILE_CREATIONDATE DESC, c.COMPUTED_DATE DESC")
List<Map<String, Object>> fetchDataByCustomerIdAndAccountIdAndDateRange(
    @Param("customerId") String customerId,
    @Param("accountId") String accountId,
    @Param("startDate") String startDate,
    @Param("endDate") String endDate
);


	
	CrrComputationInfo findFirstByCustomerIdOrderByComputedDateDesc(String customerId);
		

}
