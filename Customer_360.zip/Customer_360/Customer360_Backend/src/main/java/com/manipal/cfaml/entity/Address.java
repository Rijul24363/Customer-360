package com.manipal.cfaml.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name="ADDRESS")
public class Address {

	@Id
	@Column(name = "ADDRESS_ID")
	private String addressId;

	@Column(name = "ADDRESS1")
	private String address1;
	
	@Column(name = "ADDRESS2")
	private String address2;
	
	@Column(name = "ADDRESS3")
	private String address3;
	
	@Column(name = "CITY_NAME")
	private String cityName;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "ZIPCODE")
	private String zipcode;
	
	@Column(name = "COUNTRY")
	private String country;
	
	@Column(name = "ADDRESS4")
	private String address4;
	
	@Column(name = "PADDRESS1")
	private String pAddress1;
	
	@Column(name = "PADDRESS2")
	private String pAddress2;
	
	@Column(name = "PADDRESS3")
	private String pAddress3;
	
	@Column(name = "PADDRESS4")
	private String pAddress4;
	
	@Column(name = "PCITY_NAME")
	private String pCityName;
	
	@Column(name = "PSTATE")
	private String pState;
	
	@Column(name = "PZIPCODE")
	private String pZipcode;
	
	@Column(name = "PCOUNTRY")
	private String pCountry;
	
	@Column(name = "P_GPLUS_CODE")
	private String pgPlusCode;
	
	@Column(name = "GPLUS_CODE")
	private String gPlusCode;
	
	@Column(name = "EMPADDRESS1")
	private String empAddress1;
	
	@Column(name = "EMPADDRESS2")
	private String empAddress2;
	
	@Column(name = "EMPADDRESS3")
	private String empAddress3;
	
	@Column(name = "EMPADDRESS4")
	private String empAddress4;
	
	@Column(name = "EMPCITY_NAME")
	private String empCityName;
	
	@Column(name = "EMPSTATE")
	private String empState;
	
	@Column(name = "EMPZIPCODE")
	private String empZipcode;
	
	@Column(name = "EMPGPLUS_CODE")
	private String empgPlusCode;
	
	@Column(name = "EMPCOUNTRY")
	private String empCountry;
	
	
}

