package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name="FINANCIAL_TRANSACTION")
public class FinancialTransaction {

	@Id
	@Column(name = "TRANSACTION_REFERENCE_NUMBER")      
	private String transactionReferenceNumber;
	
	@Column(name = "ACCOUNT_ID")
	private String accountId;

	@Column(name = "PRODUCT_GROUP")
	private String productGroup;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Column(name = "TRANSACTION_AMOUNT")
	private String transactionAmount;
	
	@Column(name = "Channel")
	private String channel;
	

}
