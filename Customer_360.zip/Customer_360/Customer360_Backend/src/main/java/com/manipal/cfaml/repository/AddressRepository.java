package com.manipal.cfaml.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.manipal.cfaml.entity.Address;

public interface AddressRepository extends JpaRepository<Address, String> {
	
	Address findByAddressId(String addressId);

}
