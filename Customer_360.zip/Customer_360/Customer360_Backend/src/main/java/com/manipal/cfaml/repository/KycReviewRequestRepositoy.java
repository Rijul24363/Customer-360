package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.KycReviewRequest;


public interface KycReviewRequestRepositoy extends JpaRepository<KycReviewRequest, Long>{
	
	@Query(nativeQuery=true, value="SELECT krr.FIELDS_UPDATED as feildUpdated, krr.REQUEST_ID as requestId, krr.STATUS as status, krr.SCREEN_NAME as screenName, FORMAT(krr.CREATED_DATE, 'yyyy-MM-dd') as createdDate FROM vizprod.KYC_REVIEW_REQUEST krr WHERE krr.CUSTOMER_ID = :custId")
	List<Map<String, Object>> getKycReviewRequestByCustIdAndAccId(String custId);

	@Query(nativeQuery=true, value="Select TOP 1 krr.REQUEST_ID \r\n"
			+ "FROM VIZPROD.KYC_REVIEW_REQUEST krr \r\n"
			+ "ORDER BY REQUEST_ID DESC")
	long latestCount();
		
    Optional<KycReviewRequest> findById(Long requestId);
	
}

