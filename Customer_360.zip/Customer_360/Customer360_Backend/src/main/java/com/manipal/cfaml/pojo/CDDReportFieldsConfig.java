package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CDDReportFieldsConfig {
	private PersonForCDDDataReport personalForm;
	private EntityForCDDDataReport entityForm;
	private IdentificationForCDDDataReport identificationForm;
	private AddressForCDDDataReport addressForm;
	private AccountForCDDDataReport accountForm;
	private RevenueForCDDDataReport revenueForm;
	private FamilyForCDDDataReport familyForm;
	private AccountPersonForCDDDatReportList nomineeForm;
	private AccountPersonForCDDDatReportList beneficiaryForm;
	private AccountPersonForCDDDatReportList signatoriesForm;
	private AccountPersonForCDDDatReportList directorsForm;

}
