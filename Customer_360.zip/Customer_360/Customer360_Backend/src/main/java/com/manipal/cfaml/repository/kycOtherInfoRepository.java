package com.manipal.cfaml.repository;

import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.KycOtherInfo;

public interface kycOtherInfoRepository extends JpaRepository<KycOtherInfo, String>{

    @Query(nativeQuery=true,value = "SELECT  TOP 1 * FROM KYC_OTHER_INFO kyc WHERE kyc.customer_id = :custId")
	Map<String, Object> getKycOtherOnCustId(String custId);
}
