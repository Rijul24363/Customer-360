package com.manipal.cfaml.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.entity.EmployeeDetails;
import com.manipal.cfaml.service.AddressService;
import com.manipal.cfaml.service.CommonService;

@RequestMapping("common")
@RestController
public class CommonController {

	@Autowired
	CommonService commonService;
	
	@Autowired 
	private AddressService addressService;
	
//	@GetMapping("/getAllAccountTypeList")
//	public List<Map<String,Object>> getAllAccountTypeList(){
//		return commonService.getAllAccountTypeList();
//	}
	
//	@GetMapping(value = "/getAddressDetails")
//	public Map<String, Object> getAddressDetails() {
//		return addressService.getAddressDetails();
//	}
	
	@GetMapping("/getEmployeeListExceptEmpId")
	public List<EmployeeDetails> getEmployeeListExceptEmpId(@RequestParam(required = false, name="userId")String userId) {
		return commonService.getEmployeeListExceptEmpId(userId);
	}
	
	@GetMapping("/getEnumData")
	public Map<String,Object> getEnum(){
		return commonService.getEnum();
	}
	
	@GetMapping("/getKycMasterData")
	public List<Map<String,Object>> getKycMasterData(){
		return commonService.getKycMasterData();
	}
	
	@GetMapping("/getBranchList")
	public List<Map<String,Object>> getBranchList(){
		return commonService.getBranchList();
	}
	
}
