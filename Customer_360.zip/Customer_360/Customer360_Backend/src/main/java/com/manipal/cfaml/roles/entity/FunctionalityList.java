package com.manipal.cfaml.roles.entity;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor(force = true, access = AccessLevel.PRIVATE)
@AllArgsConstructor
@Getter
@Setter
@Builder
@Entity
@Table(name = "FUNCTIONALITY_LIST", schema = "VIZPROD")
public class FunctionalityList {

	@Id
	@Column(name = "FUNCTION_ID")
	private BigInteger functionId;

	@Column(name = "MODULE")
	private String module;

	@Column(name = "FUNCTIONALITY_NAME")
	private String functionalityName;

	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "SUB_MODULE")
	private String subModule;

}
