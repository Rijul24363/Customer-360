package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name="EMPLOYEE_DETAILS")
public class EmployeeDetails {

	@Id
	@Column(name = "EMP_NO")
	private String empNo;

	@Column(name = "FIRST_NAME")
	private String firstName;
	
	@Column(name = "LAST_NAME")
	private String lastName;
	
	@Column(name = "EMAILID")
	private String emailId;

}
