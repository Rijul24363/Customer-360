package com.manipal.cfaml.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.manipal.cfaml.entity.ProductList;

public interface ProductListRepository extends JpaRepository<ProductList, String>{

}
