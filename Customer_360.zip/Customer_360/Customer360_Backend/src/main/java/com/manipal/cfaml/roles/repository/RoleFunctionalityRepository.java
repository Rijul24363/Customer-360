package com.manipal.cfaml.roles.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.roles.entity.FunctionalityList;

public interface RoleFunctionalityRepository extends JpaRepository<FunctionalityList, BigInteger>{

	@Query(value="Select fl.*  from VIZPROD.FUNCTIONALITY_LIST fl \r\n"
			+ "inner join VIZPROD.ROLE_FUNCTION_ACCESS_MAPPING rfam on rfam.FUNCTION_ID = fl.FUNCTION_ID \r\n"
			+ "inner join VIZPROD.USER_INFO ui on ui.ROLE_ID = rfam.ROLE_ID  \r\n"
			+ "where ui.USER_ID = :userId", nativeQuery = true)
	List<FunctionalityList> getPagesForRolesOnUserId(String userId);
}
