package com.manipal.cfaml.reports.controller;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.reports.service.GenerateReportXml;


@RequestMapping("reports/xml_generate")
@RestController
public class XmlGenerationController {

	@Autowired
	GenerateReportXml service;
	
	@PostMapping(value = "/generateSARXml", produces = MediaType.APPLICATION_XML_VALUE)
	public void generateSARXml(@RequestBody Map<String, Object> data, HttpServletResponse response) {
		try{
			ByteArrayOutputStream baos = service.generateSARXml(response,data);
			// setting the content type
			response.setContentType("text/xml");
			response.setContentLength(baos.size());
			OutputStream os = null;
			try {
				os = response.getOutputStream();
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
			try {
				baos.writeTo(os);
				os.flush();
			    os.close();
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		}catch (Exception e) {
		}
	}
}
