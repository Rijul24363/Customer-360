package com.manipal.cfaml.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.ManualAlerts;

public interface ManualAlertRepository  extends JpaRepository<ManualAlerts, String> {

	@Query(nativeQuery=true, value="SELECT COUNT(*) FROM ENTPROD.MANUAL_ALERTS ma WHERE ma.TRANSACTION_REFERENCE_NUMBER IN "
			+ "(SELECT td.TRANSACTION_REFERENCE_NUMBER FROM VIZPROD.TASK_DETAILS td\r\n"
			+ "inner join CUSTOMER_PROFILE cp on cp.ACCOUNT_ID =td.ACCOUNT_ID \r\n"
			+ "where cp.CUSTOMER_ID =:customerId and td.ACCOUNT_ID =:accountId )")
	BigDecimal getManualGeneratedCount(String customerId,String accountId);
	
	@Query(nativeQuery=true, value="SELECT COUNT(*) FROM ENTPROD.MANUAL_ALERTS ma WHERE ma.TRANSACTION_REFERENCE_NUMBER IN "
			+ "(SELECT td.TRANSACTION_REFERENCE_NUMBER FROM VIZPROD.TASK_DETAILS td\r\n"
			+ "inner join CUSTOMER_PROFILE cp on cp.ACCOUNT_ID =td.ACCOUNT_ID \r\n"
			+ "where cp.CUSTOMER_ID =:customerId )")
	BigDecimal getManualGeneratedCount(String customerId);
}
