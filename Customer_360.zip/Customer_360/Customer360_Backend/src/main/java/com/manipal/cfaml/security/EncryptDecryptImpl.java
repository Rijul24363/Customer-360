package com.manipal.cfaml.security;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class EncryptDecryptImpl extends AbstractHttpMessageConverter<Object> {
		
		@Value("${security.encryption_key}")
		private String ENCRYPTION_KEY;

        private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
        
        @Value("${security.data_encryption}")
        private String data_encryption;
        
        @Autowired
        private ObjectMapper objectMapper;

        public EncryptDecryptImpl() {
            super(MediaType.APPLICATION_JSON,
                    new MediaType("application", "*+json", DEFAULT_CHARSET));
        }

        @Override
        protected boolean supports(Class<?> clazz) {
            return true;
        }

        @Override
        protected Object readInternal(Class<? extends Object> clazz,
                                      HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
        	if(data_encryption.equals("true")) {
                return objectMapper.readValue(decrypt(inputMessage.getBody()), clazz);

        	}else {
                return objectMapper.readValue(decrypt(inputMessage.getBody()), clazz);
        	}
        }

		@Override
		protected void writeInternal(Object o, HttpOutputMessage outputMessage)
				throws IOException, HttpMessageNotWritableException {
			try {
				if (data_encryption.equalsIgnoreCase("true")) {
					outputMessage.getBody().write(encrypt(o));
				} else {
					Map<String, Object> hashMap = new HashMap<>();
					try {
						hashMap.put("data", new ObjectMapper().convertValue(o,o.getClass()));
					} catch (Exception e) {
						hashMap.put("data", o);
					}
					JSONObject jsob = new JSONObject(hashMap);
					outputMessage.getBody().write(jsob.toString().getBytes());
				}
			} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException | BadPaddingException
					| IllegalBlockSizeException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

        /**
         * requests params of any API
         *
         * @param inputStream inputStream
         * @return inputStream
         */
        private InputStream decrypt(InputStream inputStream) {
        	 return inputStream;
            //this is API request params
//            StringBuilder requestParamString = new StringBuilder();
//            try (Reader reader = new BufferedReader(new InputStreamReader
//                    (inputStream, Charset.forName(StandardCharsets.UTF_8.name())))) {
//                int c;
//                while ((c = reader.read()) != -1) {
//                    requestParamString.append((char) c);
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            try {
//                //replacing /n if available in request param json string
//
//                //reference request: {"data":"thisisencryptedstringwithexpirytime"}
//
//                JSONObject requestJsonObject = new
//                        JSONObject(requestParamString.toString().replace("\n", ""));
//
////                String decryptRequestString = EncryptDecrypt.decrypt(requestJsonObject.getString("data"),encKeyString.getBytes());
////                System.out.println("decryptRequestString: " + decryptRequestString);
//
////                if (decryptRequestString != null) {
////                	return new ByteArrayInputStream(decryptRequestString.getBytes(StandardCharsets.UTF_8));
////                } else {
////                    return inputStream;
////                }
//                return inputStream;
//            } catch (JSONException err) {               
//                return inputStream;
//            }
        }

        /**
         * response of API
         *
         * @param bytesToEncrypt byte array of response
         * @return byte array of response
         * @throws IllegalBlockSizeException 
         * @throws BadPaddingException 
         * @throws NoSuchAlgorithmException 
         * @throws NoSuchPaddingException 
         * @throws InvalidKeyException 
         */
        private byte[] encrypt(Object bytesToEncrypt) throws InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException {
        	String stringFromObject = null;
			try {
				stringFromObject = objectMapper.writeValueAsString(bytesToEncrypt);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			String encodedBase64Key = EncryptDecrypt.encodeKey(ENCRYPTION_KEY);
        	Object encryptedString = null;
			try {
				encryptedString = EncryptDecrypt.encryptData(stringFromObject,encodedBase64Key);
			} catch (Exception e) {
				e.printStackTrace();
			}
		
            if (encryptedString != null) {
                Map<String, Object> hashMap = new HashMap<>();
                hashMap.put("data", encryptedString);
                JSONObject jsob = new JSONObject(hashMap);
                return jsob.toString().getBytes();
            } else
                return bytesToEncrypt.toString().getBytes();
        }
    }