package com.manipal.cfaml.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class TokenInterceptor implements HandlerInterceptor {
	@Value("${security.jwt.token.secret-key}")
	private String jetToken;
	
	@Value("${security.encryption_key}")
	private String ENCRYPTION_KEY;
	
	@Value("${authenticationheader}")
	private boolean authenticationheader;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if(!authenticationheader) {
			return true;
		}else {
			String apiName = request.getRequestURI().substring(request.getRequestURI().lastIndexOf('/') + 1);
			if(apiName.equals("sessionFromJSP")) {
				return true;
			}else {
				String token = request.getHeader("Authorization"); // Extract the token from the request header
				String[] splitBearer=token.split(" ");
				String encodedBase64Key = EncryptDecrypt.encodeKey(ENCRYPTION_KEY);

				Object data=EncryptDecrypt.decryptData(splitBearer[1],encodedBase64Key);
				if (jetToken.equals(data)) {
					return true; // Allow the request to proceed to the controller
				} else {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid token");
					return false; // Stop further processing of the request
				}
			}
		}	
		
	}
}