package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.manipal.cfaml.entity.CustomerProfile;

@Repository
public interface CustomerProfileRepository extends JpaRepository<CustomerProfile, String> {
//	Customer Account Balance & Account Type
	
	@Query(nativeQuery = true, value = "SELECT cp.ACCOUNT_ID, cp.PRODUCT_GROUP, c.CURRENTBALANCE AS balance "
	        + "FROM CUSTOMER_PROFILE cp "
	        + "JOIN FINANCIAL_TRANSACTION c ON cp.ACCOUNT_ID = c.ACCOUNT_ID "
	        + "WHERE cp.CUSTOMER_ID = :custId "
	        + "AND c.TRANSACTION_DATE_TIME = ("
	        + "    SELECT MAX(ct.TRANSACTION_DATE_TIME) "
	        + "    FROM FINANCIAL_TRANSACTION ct "
	        + "    WHERE ct.ACCOUNT_ID = cp.ACCOUNT_ID"
	        + ")")
	List<Map<String, Object>> getAccountDetails(@Param("custId") String custId);

	List<CustomerProfile> findByCustomerId(String customerId);

	@Query(nativeQuery = true, value = "SELECT a.CUSTOMER_ID, COUNT(*) AS CNT "
	        + "FROM VIZPROD.OFFLINE_CASE_DETAILS a "
	        + "JOIN VIZPROD.OFFLINE_SCENARIO_POOL b ON a.SCENARIO_ID = b.ID "
	        + "WHERE a.CUSTOMER_ID = :custId "
	        + "AND b.CODE IN ('LQ 1.1') "
	        + "AND NOT (COMMENTS LIKE '%Financial Information Unit%' or COMMENTS LIKE '%Department of Money Laundering Investigation%')"
	        + "GROUP BY a.CUSTOMER_ID")
	Map<String, Object> getLeEnquiries(String custId);


//	Adverse media
	@Query(nativeQuery = true, value = "SELECT a.CUSTOMER_ID, COUNT(*) AS CNT "
	        + "FROM VIZPROD.OFFLINE_CASE_DETAILS a "
	        + "JOIN VIZPROD.OFFLINE_SCENARIO_POOL b ON a.SCENARIO_ID = b.ID "
	        + "WHERE a.CUSTOMER_ID = :custId "
	        + "AND b.CODE IN ('MR 1.1', 'MR 2.1') "
	        + "GROUP BY a.CUSTOMER_ID")
	Map<String, Object> getAdverseMedia(String custId);

//	FIU DMLI Enquiries
	@Query(nativeQuery = true, value = "SELECT a.CUSTOMER_ID, COUNT(*) AS CNT "
	        + "FROM VIZPROD.OFFLINE_CASE_DETAILS a "
	        + "JOIN VIZPROD.OFFLINE_SCENARIO_POOL b ON a.SCENARIO_ID = b.ID "
	        + "WHERE a.CUSTOMER_ID = :custId "
	        + "AND EXISTS (SELECT 1 FROM VIZPROD.OFFLINE_SCENARIO_POOL WHERE CODE IN ('LQ 1.1') AND ID = a.SCENARIO_ID) "
	        + "AND (COMMENTS LIKE '%Financial Information Unit%' or COMMENTS LIKE '%Department of Money Laundering Investigation%') "
	        + "GROUP BY a.CUSTOMER_ID")
	Map<String, Object> getFIUDMLIEnquiries(String custId);

	
//	FIU DMLI Freezes
	@Query(nativeQuery = true, value = "SELECT a.CUSTOMER_ID, COUNT(*) AS CNT "
	        + "FROM VIZPROD.OFFLINE_CASE_DETAILS a "
	        + "JOIN VIZPROD.OFFLINE_SCENARIO_POOL b ON a.SCENARIO_ID = b.ID "
	        + "WHERE a.CUSTOMER_ID = :custId "
	        + "AND b.CODE IN ('LQ 2.1') "
	        + "GROUP BY a.CUSTOMER_ID")
	Map<String, Object> getFIUDMLIFreezes(String custId);
	

	@Query("select c.accountId from CustomerProfile c where c.customerId = :customerId")
	List<String> findAccountIdByCustomerId(String customerId);

	@Query(nativeQuery = true, value = "select cp.CUSTOMER_ID as customerId , cp.ACCOUNT_ID as accountId, cp.ACCOUNT_STATUS as accountStatusCode,"
            + " cp.PROFILE_CREATIONDATE as accountOpenDate, cp.BRANCH_ID as branchId, cp.ACCOUNT_NAME as accountName, \r\n"
            + " cp.TURNOVER as turnover, cp.INCOME as income,CONVERT(DECIMAL(18, 4),cp.INCOME) / 12 AS monthlyIncome, cp.OVERDRAFT_LIMIT as overdraftLimit,"
            + " cp.CURRENCY_TYPE as currencyType, cp.ACC_PURPOSE as purpose, cp.ACCOUNT_TYPE as accountType, \r\n"
            + " DATEDIFF(hour,cp.PROFILE_CREATIONDATE,GETDATE())/8766 AS accountAge, bl.BRANCH_NAME  as branchName \r\n"
            + " from entprod.CUSTOMER_PROFILE cp "
            + " left outer join ENTPROD.BRANCH_LIST bl on bl.BRANCH_ID = cp.BRANCH_ID \r\n"
            + " left outer join ENTPROD.ACCOUNT_STATUS acs on acs.STATUS = cp.ACCOUNT_STATUS "
            + "where cp.CUSTOMER_ID = :customerId and cp.ACCOUNT_ID = :accountId")
	Map<String, Object> getAccountDetailsByCustIdAndAddId(String customerId, String accountId);
	
	CustomerProfile findByCustomerIdAndAccountId(String customerId, String accountId);

	@Query(nativeQuery = true, value = "Select count(case when CRR = 'L' then 1 else null END) AS \"Low\",    count(case when CRR = 'M' then 1 else null END) AS \"Medium\",    count(case when CRR = 'H' then 1 else null END) AS \"High\"     From ENTPROD.CUSTOMER_PROFILE")
	Map<String, Object> getRiskDisrtibution();
	
	
	
	@Query(nativeQuery = true, value = "select cp.CUSTOMER_ID as customerId , cp.ACCOUNT_ID as accountId, cp.ACCOUNT_STATUS as accountStatusCode,"
			+ " cp.PROFILE_CREATIONDATE as accountOpenDate, cp.BRANCH_ID as branchId, cp.ACCOUNT_NAME as accountName, \r\n"
			+ " cp.TURNOVER as turnover, cp.INCOME as income, cp.INCOME/12 as monthlyIncome, cp.OVERDRAFT_LIMIT as overdraftLimit,"
			+ " cp.CURRENCY_TYPE as currencyType, cp.ACC_PURPOSE as purpose, cp.ACCOUNT_TYPE as accountType, \r\n"
			+ " DATEDIFF(hour,cp.PROFILE_CREATIONDATE,GETDATE())/8766 AS accountAge, bl.BRANCH_NAME  as branchName \r\n"
			+ "	from entprod.CUSTOMER_PROFILE cp "
			+ "	left outer join ENTPROD.BRANCH_LIST bl on bl.BRANCH_ID = cp.BRANCH_ID \r\n"
			+ "	left outer join ENTPROD.ACCOUNT_STATUS acs on acs.STATUS = cp.ACCOUNT_STATUS "
			+ "where cp.CUSTOMER_ID = :customerId")
	List<Map<String, Object>> getAccountDetailsByCustId(String customerId);
}