package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */
@Getter
@Setter
@Entity
@Table(name = "ACCOUNT_RELATION")
public class AccountRelation {
	@Id
	@Column(name = "KEY1")
	private String key1;

	@Column(name = "GRP")
	private String grp;

	@Column(name = "DESCR")
	private String descr;
}
