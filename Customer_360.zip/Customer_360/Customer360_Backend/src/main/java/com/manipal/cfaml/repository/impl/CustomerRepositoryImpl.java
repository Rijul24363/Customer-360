package com.manipal.cfaml.repository.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manipal.cfaml.entity.CustomerProfile;
import com.manipal.cfaml.entity.KycMasterData;
import com.manipal.cfaml.repository.CustomerRepositoryCustom;
import com.manipal.cfaml.repository.KycMasterDataRepository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component
public class CustomerRepositoryImpl implements CustomerRepositoryCustom {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private KycMasterDataRepository kycMasterDataRepo;
	
//    private static final Logger logger = LoggerFactory.getLogger(CustomerRepositoryImpl.class);

	public List<Map<String, Object>> findForSearchPanel(String query) {
		StringBuilder sb = new StringBuilder();
		sb.append(
				"SELECT DISTINCT  c.CUSTOMER_ID, c.CUST_TYPE, c.PAN_NUMBER , c.FIRST_NAME, c.MIDDLE_NAME, c.LAST_NAME  FROM ENTPROD.CUSTOMER_PROFILE c WHERE ");
		if (query != null) {
			sb.append(query);
		}
		List<Map<String, Object>> objectData = new ArrayList<>();
		List<Object[]> query2 = entityManager.createNativeQuery(sb.toString()).getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("customerId", (String) record[0]);
			data.put("custType", (String) record[1]);
			data.put("panNo", (String) record[2]);
			data.put("firstName", (String) record[3]);
			data.put("middleName", (String) record[4]);
			data.put("lastName", (String) record[5]);
			objectData.add(data);
		});
//        logger.info("Data retrieved: {}", objectData);

		return objectData;
	}

	public int getTTRCount(String customerId, String accountId, String frmDate, String toDate) {
		int count = 0;
		count += getTTRData(customerId, accountId, frmDate, toDate);
		count += getTTRCData(customerId, accountId, frmDate, toDate);
		count += getFXTData(customerId, accountId, frmDate, toDate);
		count += getTCBData(customerId, accountId, frmDate, toDate);
		return count;
	}

	public int getTTRData(String customerId, String accountId, String frmDate, String toDate) {
		int count = 0;
		String TTRinQuery = "SELECT CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) as  CUSTOMER_ID FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  "
				+ "TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) AND CONVERT(DATETIME,'$3')  "
				+ "AND TRANSACTION_TYPE = 'Deposit'  AND CBS_TRAN_MODE = 'PRM' AND CUSTOMER_ID = '$1' "
				+ "GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 1000000 UNION   SELECT  CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) "
				+ "FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ "AND CONVERT(DATETIME,'$3')  AND TRANSACTION_TYPE = 'Withdrawal'  AND CBS_TRAN_MODE = 'PRM' AND CUSTOMER_ID = '$1'"
				+ " GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 1000000 ";
		TTRinQuery = TTRinQuery.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate);
		Query TTRquery2 = entityManager.createNativeQuery(TTRinQuery, ArrayList.class);

		String TTR = "SELECT COUNT(*)  from (select a.customer_id "
				+ "from ENTPROD.Financial_Transaction a, ENTPROD.customer_profile b  where a.TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ " AND CONVERT(DATETIME,'$3') and a.account_id = b.account_id  AND CBS_TRAN_MODE = 'PRM' "
				+ "AND b.CONSTITUTION_CODE <> '016' AND a.CUSTOMER_ID + CAST(a.TRANSACTION_DATE_TIME AS VARCHAR(10)) in($inQuery)  and a.CUSTOMER_ID='$1'  $ACCOUNT_ID)subquery1";
		String paramsForInQ = "";
		try {
			for (int i = 0; i < TTRquery2.getResultList().size(); i++) {
				if (i != 0)
					paramsForInQ += ",";
				paramsForInQ += "'" + TTRquery2.getResultList().get(i) + "'";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(accountId.equalsIgnoreCase("ALL")) {
			TTR= TTR.replace("$ACCOUNT_ID", "");
		}else {
			TTR= TTR.replace("$ACCOUNT_ID", "and a.ACCOUNT_ID ="+accountId);
		}
		TTR = TTR.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate)
				.replace("$inQuery", paramsForInQ);
		Query TTRquery = entityManager.createNativeQuery(TTR, ArrayList.class);
		try {
			count = (int) TTRquery.getSingleResult();
		} catch (Exception e) {
			count = 0;
		}
		return count;
	}

	public int getTTRCData(String customerId, String accountId, String frmDate, String toDate) {
		int count = 0;
		String TTRCinQuery = "SELECT CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) as  CUSTOMER_ID FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  "
				+ "TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) AND CONVERT(DATETIME,'$3')  "
				+ "AND TRANSACTION_TYPE = 'Deposit' AND CHANNEL <> 'POS' AND  (CBS_FUNDS_TYPE = 'K' OR COUNTER_PARTY_FUNDS_TYPE = 'K')  AND CBS_TRAN_MODE <>'G' AND CUSTOMER_ID = '$1' "
				+ "GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 1000000 UNION   SELECT  CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) "
				+ "FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ "AND CONVERT(DATETIME,'$3')  AND TRANSACTION_TYPE = 'Withdrawal' AND CHANNEL <> 'POS' AND (CBS_FUNDS_TYPE = 'K' OR COUNTER_PARTY_FUNDS_TYPE = 'K')"
				+ "  AND CBS_TRAN_MODE <>'G' AND CUSTOMER_ID = '$1' GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 1000000";
		TTRCinQuery = TTRCinQuery.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate);
		Query TTRCquery2 = entityManager.createNativeQuery(TTRCinQuery, ArrayList.class);

		String TTRC = "SELECT COUNT(*) from (select a.customer_id "
				+ "from ENTPROD.Financial_Transaction a, ENTPROD.customer_profile b  where a.TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ " AND CONVERT(DATETIME,'$3') and a.account_id = b.account_id AND CHANNEL <> 'POS' AND  (a.CBS_FUNDS_TYPE = 'K' OR a.COUNTER_PARTY_FUNDS_TYPE = 'K') AND a.CBS_TRAN_MODE <>'G'"
				+ "AND b.CONSTITUTION_CODE <> '016' AND a.CUSTOMER_ID + CAST(a.TRANSACTION_DATE_TIME AS VARCHAR(10)) in($inQuery)  and a.CUSTOMER_ID='$1' $ACCOUNT_ID)subquery1 ";
		String paramsForInQ = "";
		try {
			for (int i = 0; i < TTRCquery2.getResultList().size(); i++) {
				if (i != 0)
					paramsForInQ += ",";
				paramsForInQ += "'" + TTRCquery2.getResultList().get(i) + "'";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(accountId.equalsIgnoreCase("ALL")) {
			TTRC= TTRC.replace("$ACCOUNT_ID", "");
		}else {
			TTRC= TTRC.replace("$ACCOUNT_ID", "and a.ACCOUNT_ID ="+accountId);
		}
		TTRC = TTRC.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate)
				.replace("$inQuery", paramsForInQ);
		Query TTRCquery = entityManager.createNativeQuery(TTRC, ArrayList.class);
		try {
			count = (int) TTRCquery.getSingleResult();
		} catch (Exception e) {
			count = 0;
		}
		return count;
	}

	public int getFXTData(String customerId, String accountId, String frmDate, String toDate) {
		int count = 0;
		String FXTinQuery = "SELECT CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) as  CUSTOMER_ID FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  "
				+ "TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) AND CONVERT(DATETIME,'$3')  "
				+ "AND TRANSACTION_TYPE = 'Deposit'  AND CBS_TRAN_MODE = 'G'   AND CUSTOMER_ID = '$1' "
				+ "GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 500000 UNION   SELECT  CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) "
				+ "FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ "AND CONVERT(DATETIME,'$3')  AND TRANSACTION_TYPE = 'Withdrawal'  AND CBS_TRAN_MODE = 'G' AND CUSTOMER_ID = '$1' "
				+ "  GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 500000 ";
		FXTinQuery = FXTinQuery.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate);
		Query FXTquery2 = entityManager.createNativeQuery(FXTinQuery, ArrayList.class);

		String FXT = "SELECT COUNT(*)  from (select a.customer_id "
				+ "from ENTPROD.Financial_Transaction a, ENTPROD.customer_profile b  where a.TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ " AND CONVERT(DATETIME,'$3') and a.account_id = b.account_id  AND a.CBS_TRAN_MODE = 'G'  "
				+ "AND b.CONSTITUTION_CODE <> '016' AND a.CUSTOMER_ID + CAST(a.TRANSACTION_DATE_TIME AS VARCHAR(10)) in($inQuery) and a.CUSTOMER_ID='$1' $ACCOUNT_ID)subquery1 ";
		String paramsForInQ = "";
		try {
			for (int i = 0; i < FXTquery2.getResultList().size(); i++) {
				if (i != 0)
					paramsForInQ += ",";
				paramsForInQ += "'" + FXTquery2.getResultList().get(i) + "'";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(accountId.equalsIgnoreCase("ALL")) {
			FXT= FXT.replace("$ACCOUNT_ID", "");
		}else {
			FXT= FXT.replace("$ACCOUNT_ID", "and a.ACCOUNT_ID ="+accountId);
		}
		FXT = FXT.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate)
				.replace("$inQuery", paramsForInQ);
		Query FXTquery = entityManager.createNativeQuery(FXT, ArrayList.class);
		try {
			count = (int) FXTquery.getSingleResult();
		} catch (Exception e) {
			count = 0;
		}
		return count;
	}

	public int getTCBData(String customerId, String accountId, String frmDate, String toDate) {
		int count = 0;
		String TCBinQuery = "SELECT CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) as  CUSTOMER_ID FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  "
				+ "TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) AND CONVERT(DATETIME,'$3')  "
				+ "AND TRANSACTION_TYPE = 'Deposit'  AND CHANNEL ='INWARD' AND CUSTOMER_ID = '$1' "
				+ "GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 1000000 UNION   SELECT  CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) "
				+ "FROM  ENTPROD.FINANCIAL_TRANSACTION WHERE  TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ "AND CONVERT(DATETIME,'$3')  AND TRANSACTION_TYPE = 'Withdrawal'AND CHANNEL ='OUTWARD' AND CUSTOMER_ID = '$1'"
				+ " GROUP BY CUSTOMER_ID + CAST(TRANSACTION_DATE_TIME AS VARCHAR(10)) HAVING SUM(LCY_AMOUNT)>= 1000000 ";

		TCBinQuery = TCBinQuery.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate);
		Query TCBCquery2 = entityManager.createNativeQuery(TCBinQuery, ArrayList.class);

		String TCB = "SELECT COUNT(*)  from (select a.customer_id  "
				+ "from ENTPROD.Financial_Transaction a, ENTPROD.customer_profile b  where a.TRANSACTION_DATE_TIME BETWEEN CONVERT(DATETIME,'$2' ) "
				+ " AND CONVERT(DATETIME,'$3') and a.account_id = b.account_id AND (a.CHANNEL ='INWARD' OR a.CHANNEL ='OUTWARD') "
				+ "AND b.CONSTITUTION_CODE <> '016' AND a.CUSTOMER_ID + CAST(a.TRANSACTION_DATE_TIME AS VARCHAR(10)) in($inQuery) and a.CUSTOMER_ID='$1' $ACCOUNT_ID )subquery1";
		String paramsForInQ = "";
		try {
			for (int i = 0; i < TCBCquery2.getResultList().size(); i++) {
				if (i != 0)
					paramsForInQ += ",";
				paramsForInQ += "'" + TCBCquery2.getResultList().get(i) + "'";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(accountId.equalsIgnoreCase("ALL")) {
			TCB= TCB.replace("$ACCOUNT_ID", "");
		}else {
			TCB= TCB.replace("$ACCOUNT_ID", "and a.ACCOUNT_ID ="+accountId);
		}
		TCB = TCB.replace("$1", customerId).replace("$2", frmDate).replace("$3", toDate)
				.replace("$inQuery", paramsForInQ);
		Query TCBquery = entityManager.createNativeQuery(TCB, ArrayList.class);
		try {
			count = (int) TCBquery.getSingleResult();
		} catch (Exception e) {
			count = 0;
		}
		return count;
	}

	
	private String getTableNullCount(Set<String> columnList, String tableName) {
		StringBuilder queryBuilder= new StringBuilder();
		for (Iterator iterator = columnList.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			if(tableName.equals("ENTPROD.CUSTOMER_PROFILE")) {		
				queryBuilder.append("cp.").append(string).append(" IS NULL or ");
			}
			if(tableName.equals("ENTPROD.ADDRESS")) {	
				queryBuilder.append("a.").append(string).append(" IS NULL or ");
			}
		}
		return queryBuilder.toString();
	}
	
	
	@Override
	public Map<String, Integer> cddCountQuery(Map<String, Set<String>> ob) {
		StringBuilder queryBuilder = new StringBuilder();
		String addressNull = "", cpNull = "", customerInnerQ = "", addressInnerQ = "";
		queryBuilder.append(" SELECT " + "		count(*) as cnt ");
		for (Map.Entry<String, Set<String>> entry : ob.entrySet()) {
			String tableName = entry.getKey().toString();
			Set<String> columnList = entry.getValue();
			if (tableName.equals("ENTPROD.CUSTOMER_PROFILE")) {
				addressNull = " ,sum(cpNull) AS cpNull  ";
				customerInnerQ = " CASE WHEN (sum(CASE WHEN " + getTableNullCount(columnList, tableName);
				customerInnerQ = customerInnerQ.substring(0, customerInnerQ.lastIndexOf("or"));
				customerInnerQ = customerInnerQ + " THEN 1 ELSE 0 END) > 0) then 1 else 0 end AS cpNull,";
			}
			if (tableName.equals("ENTPROD.ADDRESS")) {
				cpNull = ", sum(addressNull) AS addressNull ";
				addressInnerQ = " CASE WHEN (sum(CASE WHEN " + getTableNullCount(columnList, tableName);
				addressInnerQ = addressInnerQ.substring(0, addressInnerQ.lastIndexOf("or"));
				addressInnerQ = addressInnerQ + " THEN 1 ELSE 0 END) > 0) then 1 else 0 end AS addressNull,";
			}
		}
		queryBuilder.append(addressNull).append(cpNull);
		queryBuilder.append(" from (Select cp.CUSTOMER_ID, ").append(customerInnerQ).append(addressInnerQ);
		String query = queryBuilder.toString();
		query = query.substring(0, queryBuilder.lastIndexOf(","));
		queryBuilder = new StringBuilder(query);
		queryBuilder.append(" FROM ENTPROD.CUSTOMER_PROFILE cp");
		for (Map.Entry<String, Set<String>> entry : ob.entrySet()) {
			String tableName = entry.getKey().toString();
			if (tableName.equals("ENTPROD.ADDRESS")) {
				queryBuilder.append(" left join ADDRESS a on a.ADDRESS_ID = cp.CUSTOMER_ID");
			}
		}
		queryBuilder.append(" where cp.CUSTOMER_ID IS NOT NULL" + " GROUP by cp.CUSTOMER_ID ) aa; ");
		Query nativeQuery = entityManager.createNativeQuery(queryBuilder.toString());
		Object resultList = nativeQuery.getSingleResult();
		Object[] row = (Object[]) resultList; // Assuming there is at least one row in the resultList
		Integer addressNullcount = 0, cpNullCount = 0, totalCount = 0, totalNullCount = 0, totalNotNullCount = 0;

		Object element1 = row[0];
		if (element1 instanceof Integer) {
			totalCount = (Integer) element1;
		}
		try {
			Object element2 = row[1];
			if (element2 instanceof Integer) {
				cpNullCount = (Integer) element2;
			}
		} catch (Exception e) {
			cpNullCount = 0;
		}

		try {
			Object element3 = row[2];
			if (element3 instanceof Integer) {
				addressNullcount = (Integer) element3;
			}
		} catch (Exception e) {
			addressNullcount = 0;
		}

		if (cpNullCount > addressNullcount) {
			totalNullCount = cpNullCount;
			totalNotNullCount = totalCount - totalNullCount;
		} else {
			totalNullCount = addressNullcount;
			totalNotNullCount = totalCount - addressNullcount;
		}
		Map<String, Integer> countMap = new HashMap<>();
		countMap.put("notNullCount", totalNotNullCount);
		countMap.put("nullCount", totalNullCount);
		return countMap;
	}

	@Override
	public Map<String,Object> getCDDDataStatus(Map<String, Set<String>> tableColumns,String startFrom,String dtInputFields) {
		StringBuilder queryBuilder = new StringBuilder();
		List<Map<String,Object>> innerList=new ArrayList<>();
		Map<String,Object> returnData =new HashMap<>();
		queryBuilder.append(" SELECT DISTINCT cp.CUSTOMER_ID, CONCAT(cp.FIRST_NAME, ' ', cp.LAST_NAME) AS fullname,  pl.DES, bl.BRANCH_NAME, ");
		for (Map.Entry<String, Set<String>> entry : tableColumns.entrySet()) {
			String tableName = entry.getKey().toString();
			Set<String> columnList = entry.getValue();
			queryBuilder.append(getTableNullCountForCDDStatus(columnList, tableName));
		}
		String query = queryBuilder.toString();
		query = query.substring(0, queryBuilder.lastIndexOf(","));
		queryBuilder = new StringBuilder(query);
		queryBuilder.append(" FROM ENTPROD.CUSTOMER_PROFILE cp ");
		for (Map.Entry<String, Set<String>> entry : tableColumns.entrySet()) {
			String tableName = entry.getKey().toString();
			if (tableName.equals("ENTPROD.ADDRESS")) {
				queryBuilder.append(" left join ADDRESS a on a.ADDRESS_ID = cp.CUSTOMER_ID");
			}
		}
		queryBuilder.append(" LEFT JOIN "
				+ "    PRODUCT_LIST pl ON pl.GRP2 = cp.PRODUCT_TYPE "
				+ "	LEFT JOIN "
				+ "    ENTPROD.BRANCH_LIST bl ON bl.BRANCH_ID = cp.BRANCH_ID "
				+ " WHERE ");
		for (Map.Entry<String, Set<String>> entry : tableColumns.entrySet()) {
			String tableName = entry.getKey().toString();
			Set<String> columnList = entry.getValue();
			queryBuilder.append(getTableNullCount(columnList, tableName));
		}
		query = queryBuilder.toString();
		query = query.substring(0, queryBuilder.lastIndexOf("or"));
		queryBuilder = new StringBuilder(query);
		if(dtInputFields !=null) {
			queryBuilder.append(" and (CONCAT(cp.FIRST_NAME, ' ', cp.LAST_NAME) like '%"+dtInputFields+"%' or cp.CUSTOMER_ID like '%"+dtInputFields+"%' "
					+ "or bl.BRANCH_NAME like '%"+dtInputFields+"%' or pl.DES like '%"+dtInputFields+"%') ");
			String countQuery ="Select count(*) as cnt from ("+queryBuilder.toString()+")pp;";
			Query countQu2 = entityManager.createNativeQuery(countQuery);
			Object countResult = countQu2.getSingleResult();	
			if (countResult instanceof Integer) {
				returnData.put("totalCount",countResult);
			}			
		}
		
		queryBuilder.append("   ORDER BY fullname ASC  "
				+ "  	OFFSET "+startFrom+" ROWS "
				+ "    FETCH NEXT 50 ROWS ONLY;");
		Query nativeQuery = entityManager.createNativeQuery(queryBuilder.toString());
		List<Object[]> resultList = nativeQuery.getResultList();	
		  for (Object[] row : resultList) {
			  Map<String,Object> mapData=new HashMap<>();
			  mapData.put("customerId",(String) row[0]);
			  mapData.put("fullName",(String) row[1]);
			  mapData.put("des",(String) row[2]);
			  mapData.put("branchName",(String) row[3]);		        
		        int columnIndex = 4;
		        for (Map.Entry<String, Set<String>> entry : tableColumns.entrySet()) {
		            String tableName = entry.getKey();
		            Set<String> columnList = entry.getValue();
		            
		            for (String column : columnList) {
		                String columnName = tableName+ "." + column;
		                Object columnValue = row[columnIndex++];
		                mapData.put(columnName, columnValue);
		            }
		        }
		        
		        innerList.add(mapData);
		    }
		  returnData.put("innerList", innerList);
		return returnData;
	}
	
	private String getTableNullCountForCDDStatus(Set<String> columnList, String tableName) {
		StringBuilder queryBuilder= new StringBuilder();
		for (Iterator iterator = columnList.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			if(tableName.equals("ENTPROD.CUSTOMER_PROFILE")) {		
				queryBuilder.append(" CASE WHEN  cp.").append(string).append(" IS NULL THEN 'YES' ELSE 'NO' END AS ").append(string).append("_NULL, ");
			}
			if(tableName.equals("ENTPROD.ADDRESS")) {	
				queryBuilder.append(" CASE WHEN a.").append(string).append(" IS NULL THEN 'YES' ELSE 'NO' END AS ").append(string).append("_NULL, ");
			}
		}
		return queryBuilder.toString();
	}
	
	@Override
	public Map<String,Object> getCRRData(String crr,Integer startFrom,String dtInputFields){
		Map<String,Object> returnData=new HashMap<>();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT c.CUSTOMER_ID AS customerId,\r\n"
				+ "			    c.ACCOUNT_ID AS accountId,\r\n"
				+ "			    bl.BRANCH_NAME AS branchName,\r\n"
				+ "			    c.FIRST_NAME AS firstName,\r\n"
				+ "			    c.MIDDLE_NAME AS middleName,\r\n"
				+ "			    c.LAST_NAME AS lastName,\r\n"
				+ "			    pl.DES AS productType,\r\n"
				+ "			    c.employer_business AS nameOfBusiness,\r\n"
				+ "			    c.CRR_SYSTEM AS systemRatingList,\r\n"
				+ "			    c.CRR AS manualRatingList\r\n"
				+ "FROM\r\n"
				+ "			    entprod.CUSTOMER_PROFILE c\r\n"
				+ "LEFT JOIN\r\n"
				+ "			    BRANCH_LIST bl ON\r\n"
				+ "	bl.BRANCH_ID = c.BRANCH_ID\r\n"
				+ "LEFT JOIN\r\n"
				+ "			    PRODUCT_LIST pl ON\r\n"
				+ "	pl.GRP2 = c.PRODUCT_TYPE\r\n"
				+ "WHERE\r\n"
				+ "    c.CRR = '"+crr+"'");
				
			if(dtInputFields !=null) {
				queryBuilder.append(" and c.CUSTOMER_ID like '%"+dtInputFields+"%' or c.ACCOUNT_ID like '%"+dtInputFields+"%' "
						+ "or bl.BRANCH_NAME like '%"+dtInputFields+"%' or c.employer_business like '%"+dtInputFields+"%' or "
								+ "(CONCAT(c.FIRST_NAME, ' ', c.MIDDLE_NAME, '',c.LAST_NAME) like '%"+dtInputFields+"%') ");
				String countQuery ="Select count(*) as cnt from ("+queryBuilder.toString()+")pp;";
				Query countQu2 = entityManager.createNativeQuery(countQuery);
				Object countResult = countQu2.getSingleResult();	
				if (countResult instanceof Integer) {
					returnData.put("totalCount",countResult);
				}			
			}
			queryBuilder.append(" ORDER BY c.ACCOUNT_ID ASC "
				+ "	OFFSET "+startFrom+" ROWS "
				+ "	FETCH NEXT 50 ROWS ONLY; ");
			
			Query nativeQuery = entityManager.createNativeQuery(queryBuilder.toString());
			List<Object[]> resultList = nativeQuery.getResultList();	
			List<Map<String, String>> listData=new ArrayList<>();
			 for (Object[] row : resultList) {
				  Map<String,String> mapData=new HashMap<>();
				  mapData.put("customerId",(String) row[0]);
				  mapData.put("accountId",(String) row[1]);
				  mapData.put("branchName",(String) row[2]);
				  mapData.put("firstName",(String) row[3]);
				  mapData.put("middleName",(String) row[4]);
				  mapData.put("lastName",(String) row[5]);
				  mapData.put("productType",(String) row[6]);
				  mapData.put("nameOfBusiness",(String) row[7]);
				  mapData.put("systemRatingList",(String) row[8]);
				  mapData.put("manualRatingList",(String) row[9]);	 
				  listData.add(mapData);
			 }
			 returnData.put("listData",listData);
			 
		return returnData;
	}
	
	@Override
	public List<Map<String, Object>> getTransModeFundType(String custId, String startDate, String endDate) {
		String query="SELECT\r\n"
				+ "				gtfc.DESCRIPTION as decription,\r\n"
				+ "				SUM(ft.LCY_AMOUNT) amt,\r\n"
				+ "				COUNT(ft.LCY_AMOUNT) cnt\r\n"
				+ "			FROM\r\n"
				+ "				ENTPROD.Financial_Transaction ft,\r\n"
				+ "				ENTPROD.GOAML_TRANSMODE_FUNDS_CODE gtfc \r\n"
				+ "			where\r\n"
				+ "				ft.CBS_TRAN_MODE =gtfc.TRANSMODE_CODE \r\n"
				+ "				and ft.CBS_FUNDS_TYPE =gtfc.FUNDS_CODE and \r\n"
				+ "				ft.CUSTOMER_ID ='"+custId+"'  \r\n"
				+ "				AND \r\n"
				+ "				ft.TRANSACTION_VALUE_DATE BETWEEN '"+startDate+"' AND '"+endDate+"' \r\n"
				+ "			GROUP By\r\n"
				+ "				gtfc.DESCRIPTION";

		List<Map<String, Object>> objectData = new ArrayList<>();
		List<Object[]> query2 = entityManager.createNativeQuery(query).getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("decription", (String) record[0]);
			data.put("amt", (double) record[1]);
			data.put("cnt", (Integer) record[2]);
			objectData.add(data);
		});
		return objectData;
	}
	
	
	@Override
	public List<Map<String, Object>> getTransModeFundType(String custId,String accountId, String startDate, String endDate) {
		String query="SELECT\r\n"
				+ "				gtfc.DESCRIPTION as decription,\r\n"
				+ "				SUM(ft.TRANSACTION_AMOUNT) amt,\r\n"
				+ "				COUNT(ft.TRANSACTION_AMOUNT) cnt\r\n"
				+ "			FROM\r\n"
				+ "				ENTPROD.Financial_Transaction ft,\r\n"
				+ "				ENTPROD.GOAML_TRANSMODE_FUNDS_CODE gtfc \r\n"
				+ "			where\r\n"
				+ "				ft.CBS_TRAN_MODE =gtfc.TRANSMODE_CODE \r\n"
				+ "				and ft.CBS_FUNDS_TYPE =gtfc.FUNDS_CODE and \r\n"
				+ "				ft.CUSTOMER_ID ='"+custId+"' and ft.ACCOUNT_ID='"+accountId+"' \r\n"
				+ "				AND \r\n"
				+ "				ft.TRANSACTION_VALUE_DATE BETWEEN '"+startDate+"' AND '"+endDate+"' \r\n"
				+ "			GROUP By\r\n"
				+ "				gtfc.DESCRIPTION";

		List<Map<String, Object>> objectData = new ArrayList<>();
		List<Object[]> query2 = entityManager.createNativeQuery(query).getResultList();
		query2.stream().forEach((record) -> {
			Map<String, Object> data = new HashMap<>();
			data.put("decription", (String) record[0]);
			data.put("amt", (double) record[1]);
			data.put("cnt", (Integer) record[2]);
			objectData.add(data);
		});
		return objectData;
	}

	@Override
	public Map<String, Object> getCustomerTopData(String customerId, String accountId) {
		String query = "select top 1 CUSTOMER_ID,Account_ID,Cust_Type from ENTPROD.customer_profile where $customer $account";
		if (customerId != null && customerId.trim().length() != 0
				|| accountId != null && accountId.trim().length() != 0) {
			if (customerId != null && customerId.trim().length() != 0) {
				query = query.replace("$customer", " customer_id='" + customerId + "'");
			} else {
				query = query.replace("$customer", "");
			}

			if (accountId != null && accountId.trim().length() != 0) {
				query = query.replace("$account", " and account_id='" + accountId + "'");
			} else {
				query = query.replace("$account", "");
			}
			
		
		}
		Map<String, Object> objectData = new HashMap();
		List<Object[]> query2 = entityManager.createNativeQuery(query).getResultList();
		query2.stream().forEach((record) -> {
			objectData.put("customerId", (String) record[0]);
			objectData.put("accountId", (String) record[1]);
			objectData.put("custType", (String) record[2]);
		});
		return objectData;
	}

}
