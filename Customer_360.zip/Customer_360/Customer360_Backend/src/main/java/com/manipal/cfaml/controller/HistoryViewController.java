package com.manipal.cfaml.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.service.HistoryViewService;

/**
 * @author Rahul Rathod
 *
 * 
 */
@RequestMapping("history")
@RestController
public class HistoryViewController {

	@Autowired
	HistoryViewService historyService;

	@GetMapping("/getHistoryViewInfo")
	public List<Map<String, Object>> getHistoryViewInfo(@RequestParam(required = false, name = "customerId") String custID,
			@RequestParam(required = false, name = "accountId") String accId,
			@RequestParam(required = false, name = "startDate") String startDate,
			@RequestParam(required = false, name = "endDate") String endDate) {

		return historyService.getHistoryViewInfo(custID, accId, startDate, endDate);

	}
}
