package com.manipal.cfaml.reports.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface SARReportService {
	List<Map<String,Object>> getSuspiciousActivityReport(String customerId, String fromDate,
			String toDate, String scenarioName, String branchName, String status);

	HashMap<String, Object> scenarioAndBranchDetails();
	
	ArrayList<HashMap<String, Object>> getDirectorData(String customerId, String custType, String accountId);

	ArrayList<HashMap<String, Object>> getSignatoryData(String customerId, String custType, String accountId);
	
	Map<String, Object> getEntityData(String customerId, String accountId);

	Map<String, Object> getAccountDetails(String customerId, String accountId);

	List<Map<String, Object>> getReportIndicatorsList();
}
