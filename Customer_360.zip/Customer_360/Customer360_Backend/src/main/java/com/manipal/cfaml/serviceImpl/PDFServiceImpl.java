package com.manipal.cfaml.serviceImpl;

import java.io.ByteArrayOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itextpdf.io.IOException;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.color.WebColors;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.manipal.cfaml.constant.CommonUseMethod;
import com.manipal.cfaml.entity.AccountRelation;
import com.manipal.cfaml.entity.Address;
import com.manipal.cfaml.entity.CountryCode;
import com.manipal.cfaml.entity.CustomerProfile;
import com.manipal.cfaml.pojo.AccountForCDDDataReport;
import com.manipal.cfaml.pojo.AccountPersonForCDDDatReportList;
import com.manipal.cfaml.pojo.AddressForCDDDataReport;
import com.manipal.cfaml.pojo.CDDReportFieldsConfig;
import com.manipal.cfaml.pojo.EntityForCDDDataReport;
import com.manipal.cfaml.pojo.FamilyForCDDDataReport;
import com.manipal.cfaml.pojo.IdentificationForCDDDataReport;
import com.manipal.cfaml.pojo.PersonForCDDDataReport;
import com.manipal.cfaml.pojo.RevenueForCDDDataReport;
import com.manipal.cfaml.repository.AccountPersonsInfoRepository;
import com.manipal.cfaml.repository.AddressRepository;
import com.manipal.cfaml.repository.CountryCodeRepository;
import com.manipal.cfaml.repository.CustomerIdInfoRepository;
import com.manipal.cfaml.repository.CustomerProfileRepository;
import com.manipal.cfaml.roles.entity.FunctionalityList;
import com.manipal.cfaml.roles.repository.RoleFunctionalityRepository;
import com.manipal.cfaml.roles.service.RoleFunctionalityForCDD;
import com.manipal.cfaml.service.CommonService;
import com.manipal.cfaml.service.CustomerService;
import com.manipal.cfaml.service.PDFService;

@Service
public class PDFServiceImpl implements PDFService{
	
	@Autowired
	CustomerService customerService;

	@Autowired
	private AddressRepository addressRepo;

	@Autowired
	private AccountPersonsInfoRepository accountPersonsInfoRepo;
	
	@Autowired
	private CustomerProfileRepository custRepository;
	
	@Autowired
	CountryCodeRepository countryCodeRepo;
	
	@Autowired
	RoleFunctionalityRepository roleRepo;
	
	@Autowired
	CommonService commonServ;
	
	@Autowired
	CustomerIdInfoRepository customerIdInfoRepo;
		
	@Override
	public ByteArrayOutputStream cddDataReportPdfDownload(String custID,HttpServletResponse response,Map<String, Object> configFile,String userID) {
		CustomerProfile customerDeatils=custRepository.findByCustomerId(custID).get(0);
		List<Map<String, Object>> accountDetails=null;
		List<CountryCode> addressList= null;
		List<Map<String,Object>> allAccountDetails=null;
		String customerID=customerDeatils.getCustomerId();
		Map<String, Object> enumData=commonServ.getEnum();
		List<Map<String,Object>> natureOfBusinessLlist=(List<Map<String, Object>>) enumData.get("natureOfBusinessList");
//		List<Map<String,Object>> currencyList=(List<Map<String, Object>>) enumData.get("currencyList");
		List<Map<String,Object>> docTypeList=(List<Map<String, Object>>) enumData.get("docTypeList");
//		List<Map<String,Object>> maritalStatusList=(List<Map<String, Object>>) enumData.get("maritalStatusList");
		List<Map<String,Object>> accStatusList=(List<Map<String, Object>>) enumData.get("accStatusList");
//		List<Map<String,Object>> educationList=(List<Map<String, Object>>) enumData.get("educationList");
		List<AccountRelation> getBusinessList=(List<AccountRelation>) enumData.get("getBusinessList");
		List<Map<String,Object>> allAccountList= (List<Map<String, Object>>) enumData.get("accountTypeList");;
		String customerName=(CommonUseMethod.checkNullEmptyBlank(customerDeatils.getFirstName()) ? "" : customerDeatils.getFirstName()+" ")+
				(CommonUseMethod.checkNullEmptyBlank(customerDeatils.getMiddleName()) ? "" : customerDeatils.getMiddleName()+" ")+
				(CommonUseMethod.checkNullEmptyBlank(customerDeatils.getLastName()) ? "" : customerDeatils.getLastName()+" ");
		boolean entity=false,selfEmployed = false,unemployed = false;
		try {
			if (customerDeatils.getCustType().equalsIgnoreCase("Non-Individual")) {
				entity = true;
				selfEmployed = false;
				unemployed = false;
			} else if (customerDeatils.getCustType().equalsIgnoreCase("Individual - Self-employed")) {
				selfEmployed = true;
				entity = false;
				unemployed = false;
			} else if (customerDeatils.getCustType().equalsIgnoreCase("Individual - Unemployed")) {
				unemployed = true;
				entity = false;
				selfEmployed = false;
			}
		} catch (Exception e) {
		}
		Address address = null;
		try {
			address = addressRepo.findByAddressId(custID);
			if (address == null) {
				address = new Address();
			}
		} catch (Exception e) {
			address = new Address();
		}
		try {
			allAccountDetails = accountPersonsInfoRepo.findByCustomerIdForPdf(custID);
		} catch (Exception e) {
			allAccountDetails=null;
		}
		try {
			accountDetails = custRepository.getAccountDetailsByCustId(custID);

		} catch (Exception e) {
			accountDetails=null;
		}
		try {
			addressList = countryCodeRepo.findAll();
		} catch (Exception e) {
			addressList=null;
		}
		
		CDDReportFieldsConfig fieldsConfig=new RoleFunctionalityForCDD().hideFieldsDataConfig(configFile);
		EntityForCDDDataReport entityForm = patchEntityForm(customerDeatils,addressList,natureOfBusinessLlist,getBusinessList,fieldsConfig);
		AddressForCDDDataReport addressForm= patchAddressForm(customerDeatils,address,addressList,fieldsConfig);
		RevenueForCDDDataReport revenueForm= patchRevenueForm(customerDeatils,address,addressList,fieldsConfig);
		FamilyForCDDDataReport familyForm= patchFamilyForm(customerDeatils,fieldsConfig);
		PersonForCDDDataReport personalForm=patchPersonalForm(customerDeatils,addressList,fieldsConfig);
		List<FunctionalityList> roleList=roleRepo.getPagesForRolesOnUserId(userID);
		RoleFunctionalityForCDD roleSer =new RoleFunctionalityForCDD().getRoleWiseTabs(roleList);
		Map<String,AccountForCDDDataReport> accountFormList=null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        List<Map<String, Object>> identificationData=null;
        try {
        	identificationData=customerIdInfoRepo.getByCustomerId(custID);
		} catch (Exception e) {
			identificationData=new ArrayList<>();
		}
		try {
			accountFormList=accountPatchForm(accountDetails,allAccountList,accStatusList,fieldsConfig);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		try {
			baos=generateCDDDataReportPdf(allAccountDetails,entity,selfEmployed,unemployed,personalForm,entityForm,
					docTypeList,addressForm,familyForm,revenueForm,customerID,customerName,accountFormList,roleSer,addressList,fieldsConfig,identificationData);
		} catch (java.io.IOException e) {
			e.printStackTrace();
		}
		return baos;
		
	}
	
	ByteArrayOutputStream generateCDDDataReportPdf(List<Map<String, Object>> personalAccountInfo,
			boolean entity, boolean selfEmployed, boolean unemployed, PersonForCDDDataReport personalForm,
			EntityForCDDDataReport entityForm, List<Map<String,Object>> docTypeList,
			AddressForCDDDataReport addressForm, FamilyForCDDDataReport familyForm, RevenueForCDDDataReport revenueForm,
			String customerID, String customerName, Map<String, AccountForCDDDataReport> accountFormList, RoleFunctionalityForCDD roleSer, List<CountryCode> addressList, CDDReportFieldsConfig fieldsConfig, List<Map<String, Object>> identificationData)
			throws java.io.IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

		PdfWriter writer = new PdfWriter(baos);
		PdfDocument pdfDocument;
		pdfDocument = new PdfDocument(writer);
		Document document = new Document(pdfDocument);
		float tableDatapadding = 5, fontSize = 10, headerSize = 12;
		PdfFont font = PdfFontFactory.createFont(FontConstants.HELVETICA);
		PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA);
		Border border = new SolidBorder(Color.LIGHT_GRAY, 0.5f);
		Color dataFontColor = Color.DARK_GRAY;
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		try {
//			Header Table
			Table headerTable = new Table(new float[] { 25f, 25f, 25f, 25f })
					.setBackgroundColor(WebColors.getRGBColor("#F2F2F2"));
			headerTable.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize).setBorder(border);

			Cell header = new Cell(1, 4).setBorder(border);
			header.add(new Paragraph("CDD DATA REPORT").setFontSize(16).setFont(bold).setBold())
					.setTextAlignment(TextAlignment.CENTER);
			headerTable.addCell(header);

			headerTable.addCell(new Cell().add(new Paragraph("Customer Id : ").setFont(font)).setBorder(border));
			headerTable.addCell(new Cell().add(new Paragraph(customerID).setFontColor(dataFontColor).setFont(font))
					.setBorder(border));

			headerTable.addCell(new Cell().add(new Paragraph("Customer Name : ").setFont(font)).setBorder(border));
			headerTable.addCell(new Cell().add(new Paragraph(customerName).setFontColor(dataFontColor).setFont(font))
					.setBorder(border));

			headerTable.addCell(new Cell().add(new Paragraph("Date of Report: ").setFont(font)).setBorder(border));
			headerTable.addCell(new Cell(1, 3)
					.add(new Paragraph(df.format(date)).setFontColor(dataFontColor).setFont(font)).setBorder(border));

			document.add(headerTable);

			if (!entity && roleSer.getPersonal()) {
//				Personal Data
				Table personalTable = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				personalTable.addCell(new Cell(1, 6)
						.add(new Paragraph("Personal").setTextAlignment(TextAlignment.CENTER).setFont(font)
								.setFontSize(headerSize))
						.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				personalTable.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);

				personalTable.addCell(new Cell().add(new Paragraph("Salutation").setFont(font)).setBorder(border));
				personalTable
						.addCell(new Cell().add(new Paragraph(personalForm.getSalutation()).setFontColor(dataFontColor))
								.setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Short Name").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getShortName()).setFontColor(dataFontColor)).setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Age").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph(personalForm.getAge()).setFontColor(dataFontColor))
						.setBorder(border));

				personalTable.addCell(new Cell().add(new Paragraph("First Name").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getFirstName()).setFontColor(dataFontColor)).setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Middle Name").setFont(font)).setBorder(border));
				personalTable
						.addCell(new Cell().add(new Paragraph(personalForm.getMiddleName()).setFontColor(dataFontColor))
								.setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Last Name").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getLastName()).setFontColor(dataFontColor)).setBorder(border));

				personalTable.addCell(new Cell().add(new Paragraph("Marital Status").setFont(font)).setBorder(border));
				personalTable.addCell(
						new Cell().add(new Paragraph(personalForm.getMaritalStatus()).setFontColor(dataFontColor))
								.setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Gender").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getGender()).setFontColor(dataFontColor)).setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Nationality").setFont(font)).setBorder(border));
				personalTable.addCell(
						new Cell().add(new Paragraph(personalForm.getNationality()).setFontColor(dataFontColor))
								.setBorder(border));

				personalTable
						.addCell(new Cell().add(new Paragraph("Date of Birth (AD)").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getDateOfBirthAd().toString()).setFontColor(dataFontColor))
						.setBorder(border));
				personalTable
						.addCell(new Cell().add(new Paragraph("Date of Birth (BS)").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getDateOfBirthBs().toString()).setFontColor(dataFontColor))
						.setBorder(border));
				personalTable.addCell(new Cell().add(new Paragraph("Residence").setFont(font)).setBorder(border));
				personalTable.addCell(new Cell()
						.add(new Paragraph(personalForm.getResidence()).setFontColor(dataFontColor)).setBorder(border));

				personalTable.addCell(new Cell().add(new Paragraph("Education Level").setFont(font)).setBorder(border));
				personalTable.addCell(
						new Cell(1, 5).add(new Paragraph(personalForm.getEducationLevel()).setFontColor(dataFontColor))
								.setBorder(border));

				document.add(personalTable);
			} else if(roleSer.getEntity()){
				// Entity Data
				Table entityTable = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				entityTable.addCell(new Cell(1, 6)
						.add(new Paragraph("Entity").setTextAlignment(TextAlignment.CENTER).setFont(font)
								.setFontSize(headerSize))
						.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				entityTable.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);

				entityTable.addCell(new Cell().add(new Paragraph("Full Name").setFont(font)).setBorder(border));
				entityTable.addCell(new Cell().add(new Paragraph(entityForm.getFullName()).setFontColor(dataFontColor))
						.setBorder(border));
				entityTable.addCell(new Cell().add(new Paragraph("Short Name").setFont(font)).setBorder(border));
				entityTable.addCell(new Cell().add(new Paragraph(entityForm.getShortName()).setFontColor(dataFontColor))
						.setBorder(border));
				entityTable
						.addCell(new Cell().add(new Paragraph("Incorporation Number").setFont(font)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph(entityForm.getIncorporationNumber()).setFontColor(dataFontColor))
								.setBorder(border));

				entityTable.addCell(
						new Cell().add(new Paragraph("Incorporation Authority").setFont(font)).setBorder(border));
				entityTable.addCell(new Cell()
						.add(new Paragraph(entityForm.getIncorporationAuthority()).setFontColor(dataFontColor))
						.setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph("Date of Incorporation (AD)").setFont(font)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph(entityForm.getDateOfEstablismentAd()).setFontColor(dataFontColor))
								.setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph("Date of Incorporation (BS)").setFont(font)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph(entityForm.getDateOfEstablismentBs()).setFontColor(dataFontColor))
								.setBorder(border));

				entityTable
						.addCell(new Cell().add(new Paragraph("Incorporated Country").setFont(font)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph(entityForm.getIncorporatingCountry()).setFontColor(dataFontColor))
								.setBorder(border));
				entityTable
						.addCell(new Cell().add(new Paragraph("Nature of Business").setFont(font)).setBorder(border));
				entityTable.addCell(new Cell().add(new Paragraph(entityForm.getTypeOfIndustry()).setFontColor(dataFontColor)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph("Type of Incorporation").setFont(font)).setBorder(border));
				entityTable
						.addCell(new Cell().add(new Paragraph(entityForm.getBusinessList()).setFontColor(dataFontColor))
								.setBorder(border));

				entityTable.addCell(new Cell().add(new Paragraph("PAN Number").setFont(font)).setBorder(border));
				entityTable.addCell(new Cell().add(new Paragraph(entityForm.getPanNumber()).setFontColor(dataFontColor))
						.setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph("PAN Number Issue Date (AD)").setFont(font)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph(entityForm.getPanIssueDateAd()).setFontColor(dataFontColor))
								.setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph("PAN Number Issue Date (BS)").setFont(font)).setBorder(border));
				entityTable.addCell(
						new Cell().add(new Paragraph(entityForm.getPanIssueDateBs()).setFontColor(dataFontColor))
								.setBorder(border));

				document.add(entityTable.setBorder(border));
			}
			
			if(roleSer.getIdentification()) {
				Table identificationDataTable = new Table(new float[] { 25f, 25f, 25f, 25f }).setMarginTop(20).setBorder(border);
				identificationDataTable
						.addCell(new Cell(1, 4)
								.add(new Paragraph("Identification").setTextAlignment(TextAlignment.CENTER)
										.setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				identificationDataTable.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);
				 for (Map<String,Object> docTypeData : docTypeList) {
					 String docName="";
					 try {
						 docName= docTypeData.get("name").toString();
					} catch (Exception e) {						
					}
					
					try {
						Map<String,Object> data= identificationData.stream()
								.filter(a -> a.get("ID_TYPE").toString().equals(docTypeData.get("code").toString()))
								.collect(Collectors.toList()).get(0);
							if(data != null) {
								IdentificationForCDDDataReport identificationForm= patchIdentificationForm(data,addressList,fieldsConfig,docName);
								identificationPdfDataPatch(identificationForm,headerSize,tableDatapadding,font,border,fontSize,dataFontColor,identificationDataTable);

							}	
					} catch (Exception e) {
					}					
				}
				 document.add(identificationDataTable);

			}
			
//			Address Data
			if(roleSer.getAddress()) {
				Table addressData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				addressData
						.addCell(new Cell(1, 6)
								.add(new Paragraph("Address").setTextAlignment(TextAlignment.CENTER).setFontSize(headerSize)
										.setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				addressData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);

				addressData
						.addCell(new Cell(1, 6).add(new Paragraph("Contact Details").setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Mobile Number").setFont(font)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph(addressForm.getMobileNumber()).setFontColor(dataFontColor))
						.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Landline Number").setFont(font)).setBorder(border));
				addressData.addCell(new Cell()
						.add(new Paragraph(addressForm.getLandLineNumber()).setFontColor(dataFontColor)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Email Address").setFont(font)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph(addressForm.getEmailAddress()).setFontColor(dataFontColor))
						.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Web Site").setFont(font)).setBorder(border));
				addressData.addCell(new Cell(1, 6).add(new Paragraph(addressForm.getWebSite()).setFontColor(dataFontColor))
						.setBorder(border));

				addressData.addCell(
						new Cell(1, 6).add(new Paragraph("Correspondence Address").setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("House Number").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getCurrentHouseNumber()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Tole").setFont(font)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph(addressForm.getCurrentTole()).setFontColor(dataFontColor))
						.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Ward Number").setFont(font)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph(addressForm.getCurrentWard()).setFontColor(dataFontColor))
						.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("District").setFont(font)).setBorder(border));
				addressData
						.addCell(new Cell().add(new Paragraph(addressForm.getCurrentDistrict()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("MN/VDC/City").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getCurrentMnVdcCity()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Province").setFont(font)).setBorder(border));
				addressData
						.addCell(new Cell().add(new Paragraph(addressForm.getCurrentProvince()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Zip Code").setFont(font)).setBorder(border));
				addressData.addCell(new Cell()
						.add(new Paragraph(addressForm.getCurrentzipCode()).setFontColor(dataFontColor)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
				addressData.addCell(new Cell()
						.add(new Paragraph(addressForm.getCurrentCountry()).setFontColor(dataFontColor)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Country Code").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getCurrentCountryCode()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell(1, 3).add(new Paragraph("Google Plus Codes").setFont(font)).setBorder(border));
				addressData.addCell(new Cell(1, 3)
						.add(new Paragraph(addressForm.getCurrentGooglePlusCode()).setFontColor(dataFontColor))
						.setBorder(border));

				addressData.addCell(
						new Cell(1, 6).add(new Paragraph("Parmanent Address").setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("House Number").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentHouseNumber()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Tole").setFont(font)).setBorder(border));
				addressData.addCell(new Cell()
						.add(new Paragraph(addressForm.getParmanentTole()).setFontColor(dataFontColor)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Ward Number").setFont(font)).setBorder(border));
				addressData.addCell(new Cell()
						.add(new Paragraph(addressForm.getParmanentWard()).setFontColor(dataFontColor)).setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("District").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentDistrict()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("MN/VDC/City").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentmnVdcCity()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Province").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentProvince()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Zip Code").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentzipCode()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentCountry()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell().add(new Paragraph("Country Code").setFont(font)).setBorder(border));
				addressData.addCell(
						new Cell().add(new Paragraph(addressForm.getParmanentCountryCode()).setFontColor(dataFontColor))
								.setBorder(border));
				addressData.addCell(new Cell(1, 3).add(new Paragraph("Google Plus Codes").setFont(font)).setBorder(border));
				addressData.addCell(new Cell(1, 3)
						.add(new Paragraph(addressForm.getParmanentGooglePlusCode()).setFontColor(dataFontColor))
						.setBorder(border));

				document.add(addressData);
			}

			if (!entity && roleSer.getFamily()){
//				Family Data
				Table familyData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				familyData
						.addCell(new Cell(1, 6)
								.add(new Paragraph("Family").setTextAlignment(TextAlignment.CENTER)
										.setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				familyData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);
				familyData.addCell(new Cell().add(new Paragraph("Mother’s Full Name").setFont(font)).setBorder(border));
				familyData.addCell(new Cell().add(new Paragraph(familyForm.getMotherName()).setFontColor(dataFontColor))
						.setBorder(border));
				familyData.addCell(new Cell().add(new Paragraph("Father’s Full Name").setFont(font)).setBorder(border));
				familyData.addCell(new Cell().add(new Paragraph(familyForm.getFatherName()).setFontColor(dataFontColor))
						.setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph("Grandmother’s Full Name").setFont(font)).setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph(familyForm.getGrandMotherName()).setFontColor(dataFontColor))
								.setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph("Grandfather's Full Name").setFont(font)).setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph(familyForm.getGrandFatherName()).setFontColor(dataFontColor))
								.setBorder(border));
				familyData.addCell(new Cell().add(new Paragraph("Spouse’s Full Name").setFont(font)).setBorder(border));
				familyData.addCell(new Cell().add(new Paragraph(familyForm.getSpouseName()).setFontColor(dataFontColor))
						.setBorder(border));
				familyData
						.addCell(new Cell().add(new Paragraph("Daughter's Full Name").setFont(font)).setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph(familyForm.getDaughterFullName()).setFontColor(dataFontColor))
								.setBorder(border));
				familyData.addCell(new Cell().add(new Paragraph("Son's Full Name").setFont(font)).setBorder(border));
				familyData.addCell(new Cell()
						.add(new Paragraph(familyForm.getSonFullName()).setFontColor(dataFontColor)).setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph("Daughter's Full Name (2)").setFont(font)).setBorder(border));
				familyData.addCell(
						new Cell().add(new Paragraph(familyForm.getDaughterFullName2()).setFontColor(dataFontColor))
								.setBorder(border));
				familyData
						.addCell(new Cell().add(new Paragraph("Son's Full Name (2)").setFont(font)).setBorder(border));
				familyData
						.addCell(new Cell().add(new Paragraph(familyForm.getSonFullName2()).setFontColor(dataFontColor))
								.setBorder(border));
				document.add(familyData);
			}

			if (!(selfEmployed || unemployed) && roleSer.getRevenue()) {
//				employedByOthers Revenue Data
				Table revenueData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				revenueData
						.addCell(new Cell(1, 6)
								.add(new Paragraph("Revenue").setTextAlignment(TextAlignment.CENTER)
										.setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				revenueData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);
				revenueData
						.addCell(new Cell().add(new Paragraph("Name of the Employer").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getNameOfTheEmployer()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph("Employer Line of Business").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell()
						.add(new Paragraph(revenueForm.getEmployerLineOfBusiness()).setFontColor(dataFontColor))
						.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Work Tenure").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getWorkExperience()).setFontColor(dataFontColor))
								.setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("Designation").setFont(font)).setBorder(border));
				revenueData
						.addCell(new Cell().add(new Paragraph(revenueForm.getDesignation()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph("Employer Contact Number").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getContactNumber()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Department ").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell()
						.add(new Paragraph(revenueForm.getDepartment()).setFontColor(dataFontColor)).setBorder(border));

				revenueData.addCell(
						new Cell().add(new Paragraph("Regular Source of Income").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell()
						.add(new Paragraph(revenueForm.getRegularSourceOfIncome()).setFontColor(dataFontColor))
						.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Source of Wealth").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getSourceOfWealth()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Net worth").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph(revenueForm.getNetWorth()).setFontColor(dataFontColor))
						.setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("PAN Number ").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell()
						.add(new Paragraph(revenueForm.getPanNumber()).setFontColor(dataFontColor)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("House Number").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentHouseNumber()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Tole").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentTole()).setFontColor(dataFontColor))
								.setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("Ward").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentDistrict()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("MN/VDC/City").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentmnVdcCity()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Province").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentProvince()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Zip Code").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentzipCode()).setFontColor(dataFontColor))
								.setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentCountry()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Country Code").setFont(font)).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph(revenueForm.getParmanentCountryCode()).setFontColor(dataFontColor))
								.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Google Plus Code").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell()
						.add(new Paragraph(revenueForm.getParmanentGooglePlusCode()).setFontColor(dataFontColor))
						.setBorder(border));

				document.add(revenueData);
			} else if (selfEmployed && roleSer.getRevenue()) {
//				selfEmployed Revenue Data
				Table revenueData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				revenueData
						.addCell(new Cell(1, 6)
								.add(new Paragraph("Revenue").setTextAlignment(TextAlignment.CENTER)
										.setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				revenueData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);
				revenueData
						.addCell(new Cell().add(new Paragraph("Name of the Employer").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph("Employer Line of Business").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Work Tenure").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("Designation").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Title").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Department ").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(
						new Cell().add(new Paragraph("Regular Source of Income").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Source of Wealth").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Net worth").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("PAN Number ").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph("Employer Contact Number ").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Address").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("City").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("State").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				document.add(revenueData);
			} else if (unemployed && roleSer.getRevenue()) {
//				unemployed Revenue Data
				Table revenueData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
						.setBorder(border);
				revenueData
						.addCell(new Cell(1, 6)
								.add(new Paragraph("Revenue").setTextAlignment(TextAlignment.CENTER)
										.setFontSize(headerSize).setFont(font))
								.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
				revenueData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);
				revenueData.addCell(new Cell().add(new Paragraph("Status").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(
						new Cell().add(new Paragraph("Regular Source of Income").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Name of Provider").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("Source of Wealth").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Source of Income of the Provider").setFont(font))
						.setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Pan Number").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("House Number").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Tole").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Ward").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("District").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("MN/VDC/City").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Province").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				revenueData.addCell(new Cell().add(new Paragraph("Zip Code").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Country Code").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("Google Plus Code").setFont(font)).setBorder(border));
				revenueData.addCell(new Cell().add(new Paragraph("")).setBorder(border));

				document.add(revenueData);
			}

			if(roleSer.getAccount()) {
				for (Map.Entry<String, AccountForCDDDataReport> entry : accountFormList.entrySet()) {
					AccountForCDDDataReport accountOb = entry.getValue();
//						Account Data
					Table accountData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f }).setMarginTop(20)
							.setBorder(border);
					accountData
							.addCell(new Cell(1, 6)
									.add(new Paragraph("Account").setTextAlignment(TextAlignment.CENTER)
											.setFontSize(headerSize).setFont(font))
									.setBackgroundColor(WebColors.getRGBColor("#F2F2F2")).setBorder(border));
					accountData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);
					accountData.addCell(new Cell().add(new Paragraph("Account Number").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountNumber()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph("Account Name").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountName()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph("Account Age").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountAge())).setFontColor(dataFontColor)
							.setBorder(border));

					accountData.addCell(new Cell().add(new Paragraph("Account Type").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountType()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph("Account Branch").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountBranch()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData
							.addCell(new Cell().add(new Paragraph("Account Opening Date").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountOpeningDate()))
							.setFontColor(dataFontColor).setBorder(border));

					accountData.addCell(new Cell().add(new Paragraph("Account Currency").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountCurrency()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(
							new Cell().add(new Paragraph("Purpose of Opening Account").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getPurposeOfAccount()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData
							.addCell(new Cell().add(new Paragraph("Account Status Type").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getAccountStatusType()))
							.setFontColor(dataFontColor).setBorder(border));

					accountData.addCell(
							new Cell().add(new Paragraph("Estimated Annual Turnover").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getEstimatedAnnualTurnover()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(
							new Cell().add(new Paragraph("Estimated Annual Income").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getEstimatedAnnualIncome()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(
							new Cell().add(new Paragraph("Estimated Monthly Income").setFont(font)).setBorder(border));
					accountData.addCell(new Cell().add(new Paragraph(accountOb.getEstimatedMonthlyIncome()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(
							new Cell().add(new Paragraph("Upper Limit on Loan Accounts").setFont(font)).setBorder(border));
					accountData.addCell(new Cell(1, 2).add(new Paragraph(accountOb.getUpperLimitOnLoanAccounts()))
							.setFontColor(dataFontColor).setBorder(border));
					accountData.addCell(new Cell(1, 2).setBorder(border));
					document.add(accountData);

					List<Map<String, Object>> filterData = personalAccountInfo.stream()
							.filter(a -> a.get("account_id").toString().equals(accountOb.getAccountNumber()))
							.collect(Collectors.toList());

					for (int i = 0; i < filterData.size(); i++) {
						Map<String, Object> ob = filterData.get(i);
						if ((roleSer.getDirectors() && ob.get("cbs_party_role_type").toString().equalsIgnoreCase("BOD"))
								|| (roleSer.getSignatories() && ob.get("cbs_party_role_type").toString().equalsIgnoreCase("Signatory"))) {
							String title = ob.get("cbs_party_role_type").toString();
							if (entity) {
								AccountPersonForCDDDatReportList fieldsVisible = null;
								if (title.equalsIgnoreCase("Beneficiary")) {
									title = "Beneficial Owner";
									fieldsVisible=fieldsConfig.getBeneficiaryForm();
								}
								if (title.equalsIgnoreCase("BOD")) {
									title = "Director";
									fieldsVisible=fieldsConfig.getDirectorsForm();
								}else if (title.equalsIgnoreCase("Signatory")) {
									title = "Signatories";
									fieldsVisible=fieldsConfig.getSignatoriesForm();
								}else if(title.equalsIgnoreCase("Nominee")) {
									fieldsVisible=fieldsConfig.getNomineeForm();
								}
								
								AccountPersonForCDDDatReportList accData = patchAccountPersonListData(ob,addressList,fieldsVisible);
								createPdftemplateForPersonalAccountRoleType(document, tableDatapadding, fontSize, accData,
										title, font, headerSize, border, dataFontColor);
							}
						} else {
							AccountPersonForCDDDatReportList fieldsVisible;
							String title = ob.get("cbs_party_role_type").toString();
							if (title.equalsIgnoreCase("BOD")) {
								title = "Director";
							} else if (title.equalsIgnoreCase("Signatory")) {
								title = "Signatories";
							}
							if(roleSer.getNominee() && ob.get("cbs_party_role_type").toString().equals("Nominee")) {
								fieldsVisible=fieldsConfig.getNomineeForm();
								AccountPersonForCDDDatReportList accData = patchAccountPersonListData(ob,addressList,fieldsVisible);
								createPdftemplateForPersonalAccountRoleType(document, tableDatapadding, fontSize, accData,
										title, font, headerSize, border, dataFontColor);
							}
							if(roleSer.getDirectors() && ob.get("cbs_party_role_type").toString().equals("BOD")) {
								fieldsVisible=fieldsConfig.getDirectorsForm();
								AccountPersonForCDDDatReportList accData = patchAccountPersonListData(ob,addressList,fieldsVisible);
								createPdftemplateForPersonalAccountRoleType(document, tableDatapadding, fontSize, accData,
										title, font, headerSize, border, dataFontColor);
							}
							if(roleSer.getSignatories() && ob.get("cbs_party_role_type").toString().equals("Signatory")) {
								fieldsVisible=fieldsConfig.getSignatoriesForm();
								AccountPersonForCDDDatReportList accData = patchAccountPersonListData(ob,addressList,fieldsVisible);
								createPdftemplateForPersonalAccountRoleType(document, tableDatapadding, fontSize, accData,
										title, font, headerSize, border, dataFontColor);
							}
							if(roleSer.getBeneficiary() && ob.get("cbs_party_role_type").toString().equals("Beneficiary")) {
								fieldsVisible=fieldsConfig.getBeneficiaryForm();
								AccountPersonForCDDDatReportList accData = patchAccountPersonListData(ob,addressList,fieldsVisible);
								createPdftemplateForPersonalAccountRoleType(document, tableDatapadding, fontSize, accData,
										title, font, headerSize, border, dataFontColor);
							}
						}
					}
				}
			}
			document.close();
			writer.flush();
			writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return baos;
	}

	void createPdftemplateForPersonalAccountRoleType(Document document, float tableDatapadding, float fontSize,
			AccountPersonForCDDDatReportList accData, String titleName, PdfFont font, float headersize, Border border,
			Color dataFontColor) {
		Table data = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f });
		data.addCell(new Cell(1, 6).add(new Paragraph(titleName)
				.setFontSize(headersize).setFont(font)).setBackgroundColor(WebColors.getRGBColor("#DEEAF6"))
				.setBorder(border));
		data.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);

		data.addCell(new Cell().add(new Paragraph("Full Name").setFont(font)).setBorder(border));
		data.addCell(
				new Cell().add(new Paragraph(accData.getFullName()).setFontColor(dataFontColor)).setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Relationship").setFont(font)).setBorder(border));
		data.addCell(
				new Cell().add(new Paragraph(accData.getRelationship()).setFontColor(dataFontColor)).setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Contact Number").setFont(font)).setBorder(border));
		data.addCell(new Cell().add(new Paragraph(accData.getContactNumber()).setFontColor(dataFontColor))
				.setBorder(border));
		
		data.addCell(new Cell().add(new Paragraph("Date of Birth (AD)").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getDateOfBirthAd()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Date of Birth (BS)").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getDateOfBirthBs()).setFontColor(dataFontColor))
				.setBorder(border));

		data.addCell(new Cell(1, 3).add(new Paragraph("Permanent Contact Details").setFontSize(11).setFont(font).setTextAlignment(TextAlignment.CENTER)
				).setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
		data.addCell(new Cell(1, 3).add(new Paragraph("Communication Contact Details").setFontSize(11).setTextAlignment(TextAlignment.CENTER)
				.setFont(font)).setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
		data.addCell(new Cell().add(new Paragraph("House Number").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentHouseNumber()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("House Number").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentHouseNumber()).setFontColor(dataFontColor))
				.setBorder(border));
		
		data.addCell(new Cell().add(new Paragraph("Tole").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentTole()).setFontColor(dataFontColor))
				.setBorder(border));		
		data.addCell(new Cell().add(new Paragraph("Tole").setFont(font)).setBorder(border));
		data.addCell(
				new Cell(1,2).add(new Paragraph(accData.getCurrentTole()).setFontColor(dataFontColor)).setBorder(border));

		data.addCell(new Cell().add(new Paragraph("Ward").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentWard()).setFontColor(dataFontColor))
				.setBorder(border));		
		data.addCell(new Cell().add(new Paragraph("Ward").setFont(font)).setBorder(border));
		data.addCell(
				new Cell(1,2).add(new Paragraph(accData.getCurrentWard()).setFontColor(dataFontColor)).setBorder(border));
		
		data.addCell(new Cell().add(new Paragraph("District").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentDistrict()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("District").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentDistrict()).setFontColor(dataFontColor))
				.setBorder(border));

		data.addCell(new Cell().add(new Paragraph("MN/VDC/City").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentmnVdcCity()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("MN/VDC/City").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentmnVdcCity()).setFontColor(dataFontColor))
				.setBorder(border));
		
		data.addCell(new Cell().add(new Paragraph("Province").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentProvince()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Province").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentProvince()).setFontColor(dataFontColor))
				.setBorder(border));

		data.addCell(new Cell().add(new Paragraph("Zip Code").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentzipCode()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Zip Code").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentzipCode()).setFontColor(dataFontColor))
				.setBorder(border));

		data.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentCountry()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Country").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentCountry()).setFontColor(dataFontColor))
				.setBorder(border));
		
		data.addCell(new Cell().add(new Paragraph("Country Code").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentCountryCode()).setFontColor(dataFontColor))
				.setBorder(border));		
		data.addCell(new Cell().add(new Paragraph("Country Code").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentCountryCode()).setFontColor(dataFontColor))
				.setBorder(border));
		
		data.addCell(new Cell().add(new Paragraph("Google Plus Code").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getParmanentGooglePlusCode()).setFontColor(dataFontColor))
				.setBorder(border));
		data.addCell(new Cell().add(new Paragraph("Google Plus Code").setFont(font)).setBorder(border));
		data.addCell(new Cell(1,2).add(new Paragraph(accData.getCurrentGooglePlusCode()).setFontColor(dataFontColor))
				.setBorder(border));
		document.add(data);

		Table childData = new Table(new float[] { 18f, 16f, 16f, 16f, 16f, 18f });
		childData.addCell(new Cell(1, 3).add(new Paragraph("Primary Identification").setFontSize(11).setTextAlignment(TextAlignment.CENTER)
				.setFont(font)).setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
		childData.addCell(new Cell(1, 3).add(new Paragraph("Secondary Identification").setFontSize(11).setTextAlignment(TextAlignment.CENTER)
				.setFont(font)).setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));
		childData.setWidthPercent(100).setPadding(tableDatapadding).setFontSize(fontSize);

		childData.addCell(new Cell().add(new Paragraph("Document Type").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPPrimaryIdType()).setFontColor(dataFontColor)).setBorder(border));		
		childData.addCell(new Cell().add(new Paragraph("Document Type").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTPrimaryIdType()).setFontColor(dataFontColor)).setBorder(border));
		
		childData.addCell(new Cell().add(new Paragraph("Document Number").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPPrimaryIdNumber()).setFontColor(dataFontColor)).setBorder(border));
		childData.addCell(new Cell().add(new Paragraph("Document Number").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTPrimaryIdNumber()).setFontColor(dataFontColor)).setBorder(border));

		childData.addCell(new Cell().add(new Paragraph("Issue Authority").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPIssueAuthority()).setFontColor(dataFontColor)).setBorder(border));
		childData.addCell(new Cell().add(new Paragraph("Issue Authority").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTIssueAuthority()).setFontColor(dataFontColor)).setBorder(border));
		
		childData.addCell(new Cell().add(new Paragraph("Country of Issue").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPIssuseCountry()).setFontColor(dataFontColor)).setBorder(border));
		childData.addCell(new Cell().add(new Paragraph("Country of Issue").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTIssuseCountry()).setFontColor(dataFontColor)).setBorder(border));

		childData.addCell(new Cell().add(new Paragraph("Issue Date (AD)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPIssueDateAd()).setFontColor(dataFontColor)).setBorder(border));		
		childData.addCell(new Cell().add(new Paragraph("Issue Date (AD)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTIssueDateAd()).setFontColor(dataFontColor)).setBorder(border));
		
		childData.addCell(new Cell().add(new Paragraph("Issue Date (BS)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPIssueDateBs()).setFontColor(dataFontColor)).setBorder(border));
		childData.addCell(new Cell().add(new Paragraph("Issue Date (BS)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTIssueDateBs()).setFontColor(dataFontColor)).setBorder(border));

		childData.addCell(new Cell().add(new Paragraph("Expiry Date (AD)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPExpiryDateAd()).setFontColor(dataFontColor)).setBorder(border));		
		childData.addCell(new Cell().add(new Paragraph("Expiry Date (AD)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTExpiryDateAd()).setFontColor(dataFontColor)).setBorder(border));
		
		childData.addCell(new Cell().add(new Paragraph("Expiry Date (BS)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getPExpiryDateBs()).setFontColor(dataFontColor)).setBorder(border));
		childData.addCell(new Cell().add(new Paragraph("Expiry Date (BS)").setFont(font)).setBorder(border));
		childData.addCell(new Cell(1,2).add(new Paragraph(accData.getTExpiryDateBs()).setFontColor(dataFontColor)).setBorder(border));
		document.add(childData);
	}
	
	private PersonForCDDDataReport patchPersonalForm(CustomerProfile customerDeatils, List<CountryCode> addressList, CDDReportFieldsConfig fieldsConfig) {
		String getResidence = null;
		try {
			getResidence = addressList.stream().filter(a -> a.getCountryAlpha2().equals(customerDeatils.getResidence())).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		String getNationality = null;
		try {
			getNationality = addressList.stream().filter(a -> a.getCountryAlpha2().equals(customerDeatils.getNationality())).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat df2=new SimpleDateFormat("yyyy-MM-dd");
		PersonForCDDDataReport fieldVisible=fieldsConfig.getPersonalForm();
		PersonForCDDDataReport personalForm=PersonForCDDDataReport.builder().
				salutation(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getTitle(),fieldVisible.getSalutation()) ?  "" : customerDeatils.getTitle()).
				shortName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getAlias(),fieldVisible.getShortName()) ?  "" : customerDeatils.getAlias()).
				age(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDateOfBirth(),fieldVisible.getAge()) ?  "" : String.valueOf(CommonUseMethod.calculateAge(customerDeatils.getDateOfBirth()))).
				lastName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getLastName(),fieldVisible.getLastName()) ?  "" : customerDeatils.getLastName()).
				dateOfBirthAd(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDateOfBirth(),fieldVisible.getDateOfBirthAd()) ?  "" : df.format(customerDeatils.getDateOfBirth())).
				dateOfBirthBs(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDateOfBirth(),fieldVisible.getDateOfBirthBs()) ?  "" : CommonUseMethod.adtobs(df2.format(customerDeatils.getDateOfBirth()))).
				firstName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getFirstName(),fieldVisible.getFirstName()) ?  "" : customerDeatils.getFirstName()).
				middleName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getMiddleName(),fieldVisible.getMiddleName()) ?  "" : customerDeatils.getMiddleName()).
				gender(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getSex(),fieldVisible.getGender()) ?  "" : customerDeatils.getSex()).
				maritalStatus(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getMaritalStatusDiscription(),fieldVisible.getMaritalStatus()) ?  "" : customerDeatils.getMaritalStatusDiscription()).
				educationLevel(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getEducationLevel(),fieldVisible.getEducationLevel()) ?  "" : customerDeatils.getEducationLevel()).
				residence(CommonUseMethod.checkNullEmptyBlankForCddReport(getResidence,fieldVisible.getResidence()) ? "" : getResidence ).
				nationality(CommonUseMethod.checkNullEmptyBlankForCddReport(getNationality,fieldVisible.getNationality()) ? "" : getNationality).
				build();
		return personalForm;
	}
	
	private EntityForCDDDataReport patchEntityForm(CustomerProfile customerDeatils, List<CountryCode> addressList, List<Map<String, Object>> natureOfBusinessLlist, List<AccountRelation> getBusinessList, CDDReportFieldsConfig fieldsConfig) {
		SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat df2=new SimpleDateFormat("yyyy-MM-dd");
		String incorporatingCountry=null;
		EntityForCDDDataReport fieldsVisible=fieldsConfig.getEntityForm();
		try{incorporatingCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(customerDeatils.getIncoporationIssuedCountry())).collect(Collectors.toList()).get(0).getCountryName();}catch(Exception w) {}
//		String natureOfBusiness= natureOfBusinessLlist.stream().filter(a -> a.get("code").toString().equals(customerDeatils.getIncoporationIssuedCountry())).collect(Collectors.toList()).get(0).getCountryName();
		String businessList=null;
		try{businessList = getBusinessList.stream().filter(a -> a.getKey1().equals(customerDeatils.getAccountRelation())).collect(Collectors.toList()).get(0).getDescr();}catch(Exception w) {}
		
		String typeOfIndustry=null;
		try{typeOfIndustry = natureOfBusinessLlist.stream().filter(a -> a.get("code").equals(customerDeatils.getTypeOfBusiness())).collect(Collectors.toList()).get(0).get("description").toString();}catch(Exception w) {}
		
		String fullName=(CommonUseMethod.checkNullEmptyBlank(customerDeatils.getFirstName()) ? "" : customerDeatils.getFirstName())
				+" "+(CommonUseMethod.checkNullEmptyBlank(customerDeatils.getMiddleName()) ? "" : customerDeatils.getMiddleName())
						+" "+(CommonUseMethod.checkNullEmptyBlank(customerDeatils.getLastName()) ? "" : customerDeatils.getLastName());
		EntityForCDDDataReport entityForm=EntityForCDDDataReport.builder().
				fullName(CommonUseMethod.checkNullEmptyBlankForCddReport(fullName,fieldsVisible.getFullName()) ? "" : fullName )
				.shortName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getAlias(),fieldsVisible.getShortName()) ? "" : customerDeatils.getAlias() )
				.dateOfEstablismentAd(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDateOfBirth(),fieldsVisible.getDateOfEstablismentAd()) ? "" : df.format(customerDeatils.getDateOfBirth()) )
				.dateOfEstablismentBs(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDateOfBirth(),fieldsVisible.getDateOfEstablismentBs()) ? "" : CommonUseMethod.adtobs(df2.format(customerDeatils.getDateOfBirth())))
				.businessList(CommonUseMethod.checkNullEmptyBlankForCddReport(businessList,fieldsVisible.getBusinessList()) ? "" : businessList)
				.incorporationNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getIncorporationNumber(),fieldsVisible.getIncorporationNumber()) ? "" : customerDeatils.getIncorporationNumber() )
				.incorporationAuthority(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getIncoprporationIssuedBy(),fieldsVisible.getIncorporationAuthority()) ? "" : customerDeatils.getIncoprporationIssuedBy() )
				.incorporatingCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(incorporatingCountry,fieldsVisible.getIncorporatingCountry()) ? "" : incorporatingCountry)
				.panNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getPanNo(),fieldsVisible.getPanNumber()) ? "" : customerDeatils.getPanNo() )
				.panIssueDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getPanIssueDate(),fieldsVisible.getPanIssueDateAd()) ? "" : df.format(customerDeatils.getPanIssueDate()) )
				.panIssueDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getPanIssueDate(),fieldsVisible.getPanIssueDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(customerDeatils.getPanIssueDate())))
				.typeOfIndustry(CommonUseMethod.checkNullEmptyBlankForCddReport(typeOfIndustry,fieldsVisible.getTypeOfIndustry()) ? "" : typeOfIndustry)
				.build();
		return entityForm;
	}
	
	private IdentificationForCDDDataReport patchIdentificationForm(Map<String,Object> data2, List<CountryCode> addressList, CDDReportFieldsConfig fieldsConfig, String docName) {
		SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat df2=new SimpleDateFormat("yyyy-MM-dd");
		String countryOfIssue =null;
		try {
			countryOfIssue = addressList.stream().filter(a -> a.getCountryAlpha2().equals(data2.get("ID_ISSUE_COUNTRY"))).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		IdentificationForCDDDataReport fieldsVisible=fieldsConfig.getIdentificationForm();
		IdentificationForCDDDataReport data=IdentificationForCDDDataReport.builder().
				identificationDocType(CommonUseMethod.checkNullEmptyBlankForCddReport(docName,fieldsVisible.getIdentificationDocType()) ? "" : docName).
				identificationDocNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(data2.get("ID_NUMBER"),fieldsVisible.getIdentificationDocNumber()) ? "" : data2.get("ID_NUMBER").toString()).
				identificationDocIssuedDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(data2.get("ID_ISSUE_DATE"),fieldsVisible.getIdentificationDocIssuedDateAd()) ? "" : df.format(data2.get("ID_ISSUE_DATE"))).
				identificationDocIssuedDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(data2.get("ID_ISSUE_DATE"),fieldsVisible.getIdentificationDocIssuedDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(data2.get("ID_ISSUE_DATE")))).
				idenificationDocIssuedBy(CommonUseMethod.checkNullEmptyBlankForCddReport(data2.get("ID_ISSUED_BY"),fieldsVisible.getIdenificationDocIssuedBy()) ? "" : data2.get("ID_ISSUED_BY").toString()).
				expiredDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(data2.get("ID_EXPIRY_DATE"),fieldsVisible.getExpiredDateAd()) ? "" : df.format(data2.get("ID_EXPIRY_DATE"))).
				expiredDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(data2.get("ID_EXPIRY_DATE"),fieldsVisible.getExpiredDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(data2.get("ID_EXPIRY_DATE")))).
				countryOfIssue(CommonUseMethod.checkNullEmptyBlankForCddReport(countryOfIssue,fieldsVisible.getCountryOfIssue()) ? "" : countryOfIssue).
				build();
		return data;
	}
	
	
	private FamilyForCDDDataReport patchFamilyForm(CustomerProfile customerDeatils, CDDReportFieldsConfig fieldsConfig) {
		JSONObject childsData = null,childs = null;
		String sonName1 = null,daughterName1 = null,sonName2 = null,daughterName2 = null;
		try {
			childsData = new JSONObject(customerDeatils.getChildName());		
			childs=new JSONObject(childsData.getString("child"));	
		} catch (Exception e) {
		}
		try {
			sonName1=childs.get("sonFullName").toString();
		} catch (Exception e) {
			// TODO: handle exception
		}
		try {
			daughterName1=childs.get("daughterFullName").toString();
		} catch (Exception e) {
		}
		try {
			sonName2=childs.get("sonFullName2").toString();
		} catch (Exception e) {
		}
		try {
			daughterName2=childs.get("daughterFullName2").toString();
		} catch (Exception e) {
			// TODO: handle exception
		}
		FamilyForCDDDataReport fieldsVisible=fieldsConfig.getFamilyForm();

		FamilyForCDDDataReport data=FamilyForCDDDataReport.builder().
				fatherName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getFatherName(),fieldsVisible.getFatherName()) ? "" :customerDeatils.getFatherName()).
				motherName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getMotherName(),fieldsVisible.getMotherName()) ? "" :customerDeatils.getMotherName()).
				spouseName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getSpouseName(),fieldsVisible.getSpouseName()) ? "" :customerDeatils.getSpouseName()).
				grandFatherName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getGrandFatherName(),fieldsVisible.getGrandFatherName()) ? "" :customerDeatils.getGrandFatherName()).
				grandMotherName(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getGrandMotherName(),fieldsVisible.getGrandMotherName()) ? "" :customerDeatils.getGrandMotherName()).
				sonFullName(CommonUseMethod.checkNullEmptyBlankForCddReport(sonName1,fieldsVisible.getSonFullName()) ? "" : sonName1).
				daughterFullName(CommonUseMethod.checkNullEmptyBlankForCddReport(daughterName1,fieldsVisible.getDaughterFullName()) ? "" :daughterName1).
				daughterFullName2(CommonUseMethod.checkNullEmptyBlankForCddReport(sonName2,fieldsVisible.getDaughterFullName2()) ? "" :sonName2).
				sonFullName2(CommonUseMethod.checkNullEmptyBlankForCddReport(daughterName2,fieldsVisible.getSonFullName2()) ? "" :daughterName2).
				build();
		return data;
	}


	private RevenueForCDDDataReport patchRevenueForm(CustomerProfile customerDeatils, Address address, List<CountryCode> addressList, CDDReportFieldsConfig fieldsConfig) {
		String parmanentCountry =null;
		try {
			parmanentCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(address.getPCountry())).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		RevenueForCDDDataReport fieldsVisible=fieldsConfig.getRevenueForm();
		RevenueForCDDDataReport data=RevenueForCDDDataReport.builder().
				nameOfTheEmployer(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getNameOfTheEmployer(),fieldsVisible.getNameOfTheEmployer()) ? "" : customerDeatils.getNameOfTheEmployer()). 
				designation(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDesignation(),fieldsVisible.getDesignation()) ? "" : customerDeatils.getDesignation()). 
				employerLineOfBusiness(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getNameOfBusiness(),fieldsVisible.getEmployerLineOfBusiness()) ? "" : customerDeatils.getNameOfBusiness()). 
				workExperience(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getWorkExperience(),fieldsVisible.getWorkExperience()) ? "" : customerDeatils.getWorkExperience()). 
				department(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getDepartment(),fieldsVisible.getDepartment()) ? "" : customerDeatils.getDepartment()). 
				regularSourceOfIncome(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getSourceOfIncome(),fieldsVisible.getRegularSourceOfIncome()) ? "" : customerDeatils.getSourceOfIncome()). 
				sourceOfWealth(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getSourceOfWealth(),fieldsVisible.getSourceOfWealth()) ? "" : customerDeatils.getSourceOfWealth()). 
				netWorth(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getNetWorth(),fieldsVisible.getNetWorth()) ? "" : customerDeatils.getNetWorth()). 
				panNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getPanNo(),fieldsVisible.getPanNumber()) ? "" : customerDeatils.getPanNo()). 
				employersContactNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getEmployersContactNumber(),fieldsVisible.getEmployersContactNumber()) ? "" : customerDeatils.getEmployersContactNumber()). 
				parmanentHouseNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress1(),fieldsVisible.getParmanentHouseNumber()) ? "" : address.getPAddress1()). 
				parmanentTole(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress2(),fieldsVisible.getParmanentTole()) ? "" : address.getPAddress2()). 
				parmanentDistrict(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress4(),fieldsVisible.getParmanentDistrict()) ? "" : address.getPAddress4()). 
				parmanentmnVdcCity(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPCityName(),fieldsVisible.getParmanentmnVdcCity()) ? "" : address.getPCityName()). 
				parmanentProvince(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPState(),fieldsVisible.getParmanentProvince()) ? "" : address.getPState()). 
				parmanentCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(parmanentCountry,fieldsVisible.getParmanentCountry()) ? "" : parmanentCountry). 
				parmanentCountryCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPCountry(),fieldsVisible.getParmanentCountryCode()) ? "" : address.getPCountry()). 
				parmanentGooglePlusCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPgPlusCode(),fieldsVisible.getParmanentGooglePlusCode()) ? "" : address.getPgPlusCode()). 
				nameOfBusiness(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getNameOfBusiness(),fieldsVisible.getNameOfBusiness()) ? "" : customerDeatils.getNameOfBusiness()). 
				typeOfBusiness(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getTypeOfBusiness(),fieldsVisible.getTypeOfBusiness()) ? "" : customerDeatils.getTypeOfBusiness()). 
				lineOfBusiness(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getNameOfBusiness(),fieldsVisible.getLineOfBusiness()) ? "" : customerDeatils.getNameOfBusiness()). 
				contactNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getMobileNumber(),fieldsVisible.getContactNumber()) ? "" : customerDeatils.getMobileNumber()). 
				sourceOfIncomeOfTheProvider(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getSourceOfIncome(),fieldsVisible.getSourceOfIncomeOfTheProvider()) ? "" : customerDeatils.getSourceOfIncome()). 
				parmanentzipCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPZipcode(),fieldsVisible.getParmanentzipCode()) ? "" : address.getPZipcode())
				.build();
		return data;
	}


	private AddressForCDDDataReport patchAddressForm(CustomerProfile customerDeatils, Address address, List<CountryCode> addressList, CDDReportFieldsConfig fieldsConfig) {
		String currentCountry =null;
		try {
			currentCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(address.getCountry())).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		String parmanentCountry =null;
		try {
			parmanentCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(address.getPCountry())).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		AddressForCDDDataReport fieldsVisible=fieldsConfig.getAddressForm();
		AddressForCDDDataReport data = AddressForCDDDataReport.builder().
				landLineNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getLandlineNumber(),fieldsVisible.getLandLineNumber()) ? "" : customerDeatils.getLandlineNumber()).
				mobileNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getMobileNumber(),fieldsVisible.getMobileNumber()) ? "" : customerDeatils.getMobileNumber()).
				emailAddress(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getEmailId(),fieldsVisible.getEmailAddress()) ? "" : customerDeatils.getEmailId()).
				currentHouseNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getAddress1(),fieldsVisible.getCurrentHouseNumber()) ? "" : address.getAddress1()).
				currentTole(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getAddress2(),fieldsVisible.getCurrentTole()) ? "" : address.getAddress2()).
				currentWard(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getAddress3(),fieldsVisible.getCurrentWard()) ? "" : address.getAddress3()).
				currentDistrict(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getAddress4(),fieldsVisible.getCurrentDistrict()) ? "" : address.getAddress4()).
				currentCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(currentCountry,fieldsVisible.getCurrentCountry()) ? "" : currentCountry).
				currentProvince(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getState(),fieldsVisible.getCurrentProvince()) ? "" : address.getState()).
				currentCountryCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getCountry(),fieldsVisible.getCurrentCountryCode()) ? "" : address.getCountry()).
				currentGooglePlusCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getGPlusCode(),fieldsVisible.getCurrentGooglePlusCode()) ? "" : address.getGPlusCode()).
				currentMnVdcCity(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getCityName(),fieldsVisible.getCurrentMnVdcCity()) ? "" : address.getCityName()).
				parmanentHouseNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress1(),fieldsVisible.getParmanentHouseNumber()) ? "" : address.getPAddress1()).
				parmanentTole(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress2(),fieldsVisible.getParmanentTole()) ? "" : address.getPAddress2()).
				parmanentWard(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress3(),fieldsVisible.getParmanentWard()) ? "" : address.getPAddress3()).
				parmanentDistrict(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPAddress4(),fieldsVisible.getParmanentDistrict()) ? "" : address.getPAddress4()).
				parmanentmnVdcCity(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPCityName(),fieldsVisible.getParmanentmnVdcCity()) ? "" : address.getPCityName()).
				parmanentProvince(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPState(),fieldsVisible.getParmanentProvince()) ? "" : address.getPState()).
				parmanentCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(parmanentCountry,fieldsVisible.getParmanentCountry()) ? "" : parmanentCountry).
				parmanentCountryCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPCountry(),fieldsVisible.getParmanentCountryCode()) ? "" : address.getPCountry()).
				parmanentGooglePlusCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPgPlusCode(),fieldsVisible.getParmanentGooglePlusCode()) ? "" : address.getPgPlusCode()).
				parmanentzipCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getPZipcode(),fieldsVisible.getParmanentzipCode()) ? "" : address.getPZipcode()).
				currentzipCode(CommonUseMethod.checkNullEmptyBlankForCddReport(address.getZipcode(),fieldsVisible.getCurrentzipCode()) ? "" : address.getZipcode()).
				webSite(CommonUseMethod.checkNullEmptyBlankForCddReport(customerDeatils.getWebsite(),fieldsVisible.getWebSite()) ? "" : customerDeatils.getWebsite()).
				build();
		return data;
	}
	
	
	private Map<String, AccountForCDDDataReport> accountPatchForm(List<Map<String, Object>> accountDetails, List<Map<String, Object>> allAccountList, List<Map<String, Object>> accStatusList, CDDReportFieldsConfig fieldsConfig) throws JSONException {
		Map<String,AccountForCDDDataReport> accountFormList=new HashMap<>();
		SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");

		for (Map<String, Object> entry : accountDetails) {
			if (!accountFormList.containsKey(entry.get("accountId"))) {
				String accountType =null;
				try {
					accountType = allAccountList.stream().filter(a -> a.get("value").toString().equals(entry.get("accountType").toString())).collect(Collectors.toList()).get(0).get("description").toString();
				} catch (Exception e) {
				}
				String accountStatusType =null;
				try {
					accountStatusType = accStatusList.stream().filter(a -> a.get("code").toString().equals(entry.get("accountStatusCode").toString())).collect(Collectors.toList()).get(0).get("name").toString();
				} catch (Exception e) {
				}
				AccountForCDDDataReport fieldsVisible=fieldsConfig.getAccountForm();
				AccountForCDDDataReport data =AccountForCDDDataReport.builder().
						estimatedMonthlyIncome(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("monthlyIncome"),fieldsVisible.getEstimatedMonthlyIncome()) ? "" : entry.get("monthlyIncome").toString()).
						 estimatedAnnualIncome(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("income"),fieldsVisible.getEstimatedAnnualIncome()) ? "" : entry.get("income").toString()).
						 estimatedAnnualTurnover(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("turnover"),fieldsVisible.getEstimatedAnnualTurnover()) ? "" : entry.get("turnover").toString()).
						 accountCurrency(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("currencyType"),fieldsVisible.getAccountCurrency()) ? "" : entry.get("currencyType").toString()).
						 accountOpeningDate(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("accountOpenDate"),fieldsVisible.getAccountOpeningDate()) ? "" : df.format(entry.get("accountOpenDate"))).
						 accountAge(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("accountAge"),fieldsVisible.getAccountAge()) ? "" : entry.get("accountAge").toString()).
						 accountBranch(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("branchName"),fieldsVisible.getAccountBranch()) ? "" : entry.get("branchName").toString()).
						 accountType(CommonUseMethod.checkNullEmptyBlankForCddReport(accountType,fieldsVisible.getAccountType()) ? "" : accountType).
						 accountName(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("accountName"),fieldsVisible.getAccountName()) ? "" : entry.get("accountName").toString()).
						 accountNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("accountId"),fieldsVisible.getAccountNumber()) ? "" : entry.get("accountId").toString()).
						 purposeOfAccount(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("purpose"),fieldsVisible.getPurposeOfAccount()) ? "" : entry.get("purpose").toString()).
						 upperLimitOnLoanAccounts(CommonUseMethod.checkNullEmptyBlankForCddReport(entry.get("overdraftLimit"),fieldsVisible.getUpperLimitOnLoanAccounts()) ? "" : entry.get("overdraftLimit").toString()).
						 accountStatusType(CommonUseMethod.checkNullEmptyBlankForCddReport(accountStatusType,fieldsVisible.getAccountStatusType()) ? "" : accountStatusType).
						 build();
				accountFormList.put(entry.get("accountId").toString(),data);
		     }
		}
		return accountFormList;
	}
	
	private AccountPersonForCDDDatReportList patchAccountPersonListData(Map<String, Object> ob, List<CountryCode> addressList, AccountPersonForCDDDatReportList fieldsVisible) {
		SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat df2=new SimpleDateFormat("yyyy-MM-dd");
		String pIssuseCountry =null;
		try {
			pIssuseCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(ob.get("identification_doc_issue_country").toString())).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		String currentCountry =null;
		try {
			currentCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(ob.get("tcountry"))).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		
		String tIssuseCountry =null;
		try {
			tIssuseCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(ob.get("sIdentification_doc_issue_country"))).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		String parmanentCountry =null;
		try {
			parmanentCountry = addressList.stream().filter(a -> a.getCountryAlpha2().equals(ob.get("pcountry"))).collect(Collectors.toList()).get(0).getCountryName();
		} catch (Exception e) {
		}
		AccountPersonForCDDDatReportList data=AccountPersonForCDDDatReportList.builder().
				  fullName(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("fullName"),fieldsVisible.getFullName()) ? "" : ob.get("fullName").toString()).
		            relationship(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("cbs_account_person_role_type"),fieldsVisible.getRelationship()) ? "" : ob.get("cbs_account_person_role_type").toString()).
		            contactNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("contactNumber"),fieldsVisible.getContactNumber()) ? "" : ob.get("contactNumber").toString()).
		            dateOfBirthAd(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("dob"),fieldsVisible.getDateOfBirthAd()) ? "" : df.format(convertStringToDate(ob.get("dob").toString()))).
		            pPrimaryIdType(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_type"),fieldsVisible.getPPrimaryIdType()) ? "" : ob.get("identification_doc_type").toString()).
		            pPrimaryIdNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_number"),fieldsVisible.getPPrimaryIdNumber()) ? "" : ob.get("identification_doc_number").toString()).
		            pIssueDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_issued_date"),fieldsVisible.getPIssueDateAd()) ? "" : df.format(convertStringToDate(ob.get("identification_doc_issued_date").toString()))).
		            pIssueDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_issued_date"),fieldsVisible.getPIssueDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(convertStringToDate(ob.get("identification_doc_issued_date").toString())))).
		            tPrimaryIdType(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdentification_doc_type"),fieldsVisible.getTPrimaryIdType()) ? "" : ob.get("sIdentification_doc_type").toString()).
		            tPrimaryIdNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdentification_doc_number"),fieldsVisible.getTPrimaryIdNumber()) ? "" : ob.get("sIdentification_doc_number").toString()).
		            tIssueDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdentification_doc_issued_date"),fieldsVisible.getTIssueDateAd()) ? "" : df.format(convertStringToDate(ob.get("sIdentification_doc_issued_date").toString()))).
		            tIssueDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdentification_doc_issued_date"),fieldsVisible.getTIssueDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(convertStringToDate(ob.get("sIdentification_doc_issued_date").toString())))).
		            pIssueAuthority(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_issued_by"),fieldsVisible.getPIssueAuthority()) ? "" : ob.get("identification_doc_issued_by").toString()).
		            tIssueAuthority(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdenification_doc_issued_by"),fieldsVisible.getTIssueAuthority()) ? "" : ob.get("sIdenification_doc_issued_by").toString()).
		            pIssuseCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(pIssuseCountry,fieldsVisible.getPIssuseCountry()) ? "" : pIssuseCountry).
		            tIssuseCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(tIssuseCountry,fieldsVisible.getTIssuseCountry()) ? "" : tIssuseCountry).
		            dateOfBirthBs(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("dob"),fieldsVisible.getDateOfBirthBs()) ? "" : CommonUseMethod.adtobs(df2.format(convertStringToDate(ob.get("dob").toString())))).
		            currentWard(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("taddress3"),fieldsVisible.getCurrentWard()) ? "" : ob.get("taddress3").toString()).
		            currentDistrict(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("taddress4"),fieldsVisible.getCurrentDistrict()) ? "" : ob.get("taddress4").toString()).
		            currentmnVdcCity(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("tCity"),fieldsVisible.getCurrentmnVdcCity()) ? "" : ob.get("tCity").toString()).
		            currentProvince(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("tState"),fieldsVisible.getCurrentProvince()) ? "" : ob.get("tState").toString()).
		            currentCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(currentCountry,fieldsVisible.getCurrentCountry()) ? "" : currentCountry).
		            currentCountryCode(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("tcountry"),fieldsVisible.getCurrentCountryCode()) ? "" : ob.get("tcountry").toString()).
		            currentGooglePlusCode(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("gPlusCode"),fieldsVisible.getCurrentGooglePlusCode()) ? "" : ob.get("gPlusCode").toString()).
		            parmanentHouseNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("paddress1"),fieldsVisible.getParmanentHouseNumber()) ? "" : ob.get("paddress1").toString()).
		            parmanentTole(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("paddress2"),fieldsVisible.getParmanentTole()) ? "" : ob.get("paddress2").toString()).
		            parmanentDistrict(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("paddress4"),fieldsVisible.getParmanentDistrict()) ? "" : ob.get("paddress4").toString()).
		            parmanentmnVdcCity(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("pCity"),fieldsVisible.getParmanentmnVdcCity()) ? "" : ob.get("pCity").toString()).
		            parmanentProvince(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("pState"),fieldsVisible.getParmanentProvince()) ? "" : ob.get("pState").toString()).
		            parmanentCountry(CommonUseMethod.checkNullEmptyBlankForCddReport(parmanentCountry,fieldsVisible.getParmanentCountry()) ? "" : parmanentCountry).
		            parmanentCountryCode(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("pcountry"),fieldsVisible.getParmanentCountryCode()) ? "" : ob.get("pcountry").toString()).
		            parmanentGooglePlusCode(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("pgPlusCode"),fieldsVisible.getParmanentGooglePlusCode()) ? "" : ob.get("pgPlusCode").toString()).
		            parmanentzipCode(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("pzipcode"),fieldsVisible.getParmanentzipCode()) ? "" : ob.get("pzipcode").toString()).
		            currentzipCode(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("tzipcode"),fieldsVisible.getCurrentzipCode()) ? "" : ob.get("tzipcode").toString()).
		            pExpiryDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_expiry_date"),fieldsVisible.getPExpiryDateAd()) ? "" : df.format(convertStringToDate(ob.get("identification_doc_expiry_date").toString()))).
		            pExpiryDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("identification_doc_expiry_date"),fieldsVisible.getPExpiryDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(convertStringToDate(ob.get("identification_doc_expiry_date").toString())))).
		            tExpiryDateAd(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdentification_doc_expiry_date"),fieldsVisible.getTExpiryDateAd()) ? "" : df.format(convertStringToDate(ob.get("sIdentification_doc_expiry_date").toString()))).
		            tExpiryDateBs(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("sIdentification_doc_expiry_date"),fieldsVisible.getTExpiryDateBs()) ? "" : CommonUseMethod.adtobs(df2.format(convertStringToDate(ob.get("sIdentification_doc_expiry_date").toString())))).
		            currentHouseNumber(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("taddress1"),fieldsVisible.getCurrentHouseNumber()) ? "" : ob.get("taddress1").toString()).
		            currentTole(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("taddress2"),fieldsVisible.getCurrentTole()) ? "" : ob.get("taddress2").toString()).
		            parmanentWard(CommonUseMethod.checkNullEmptyBlankForCddReport(ob.get("paddress3"),fieldsVisible.getParmanentWard()) ? "" : ob.get("paddress3").toString()).
		            build();
				return data;
	}
	
	void identificationPdfDataPatch(IdentificationForCDDDataReport identificationForm, float headerSize, float tableDatapadding, PdfFont font, Border border, float fontSize, Color dataFontColor, Table identificationData) {
	

		identificationData.addCell(
				new Cell(1, 4).add(new Paragraph(identificationForm.getIdentificationDocType()).setFontSize(headerSize).setFont(font))
						.setBackgroundColor(WebColors.getRGBColor("#DEEAF6")).setBorder(border));

		identificationData
				.addCell(new Cell().add(new Paragraph("Document Number").setFont(font)).setBorder(border));
		identificationData.addCell(new Cell()
				.add(new Paragraph(identificationForm.getIdentificationDocNumber()).setFontColor(dataFontColor))
				.setBorder(border));
		identificationData
				.addCell(new Cell().add(new Paragraph("Issue Date (AD)").setFont(font)).setBorder(border));
		identificationData.addCell(new Cell().add(
				new Paragraph(identificationForm.getIdentificationDocIssuedDateAd()).setFontColor(dataFontColor))
				.setBorder(border));
		
		identificationData
				.addCell(new Cell().add(new Paragraph("Issue Date (BS) ").setFont(font)).setBorder(border));
		identificationData.addCell(new Cell().add(
				new Paragraph(identificationForm.getIdentificationDocIssuedDateBs()).setFontColor(dataFontColor))
				.setBorder(border));

		identificationData
				.addCell(new Cell().add(new Paragraph("Issuing Authority").setFont(font)).setBorder(border));
		identificationData.addCell(new Cell()
				.add(new Paragraph(identificationForm.getIdenificationDocIssuedBy()).setFontColor(dataFontColor))
				.setBorder(border));
		identificationData
				.addCell(new Cell().add(new Paragraph("Country of Issue").setFont(font)).setBorder(border));
		identificationData.addCell(
				new Cell().add(new Paragraph(identificationForm.getCountryOfIssue()).setFontColor(dataFontColor))
						.setBorder(border));

		identificationData
				.addCell(new Cell().add(new Paragraph("Expire Date (AD)").setFont(font)).setBorder(border));
		identificationData.addCell(
				new Cell().add(new Paragraph(identificationForm.getExpiredDateAd()).setFontColor(dataFontColor))
						.setBorder(border));
		identificationData
				.addCell(new Cell().add(new Paragraph("Expire Date (BS)").setFont(font)).setBorder(border));
		identificationData.addCell(
				new Cell().add(new Paragraph(identificationForm.getExpiredDateBs()).setFontColor(dataFontColor))
						.setBorder(border));
		identificationData
		.addCell(new Cell(1, 2).setBorder(border));
	}
	
	Date convertStringToDate(String date) {
		Date date1 = null;
		try {
			date1=new SimpleDateFormat("yyyy-MM-dd").parse(date);  
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date1;		
	}


}
