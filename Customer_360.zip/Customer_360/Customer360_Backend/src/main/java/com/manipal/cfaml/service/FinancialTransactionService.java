package com.manipal.cfaml.service;

import java.text.ParseException;
import java.util.Map;

/**
 * @author Rahul Rathod
 *
 * 
 */

public interface FinancialTransactionService {

	Map<String, Object> getTransactionDetailsBasedOnChannels(String customerId,String startDate, String endDate,String accountId) throws ParseException;

}
