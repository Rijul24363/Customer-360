package com.manipal.cfaml.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.json.JSONException;

/**
 * @author Rahul Rathod
 *
 * 
 */

public interface CustomerService {

	List<Map<String,Object>> searchCustomer(String custID, String custType, String custName, String panNo);

	Map<String, Object> getCustomerDetails(String custID);

	Map<String, Object> getCustomerDetailsForCDD(String custID);

	List<String> getAccountListByCustomerId(String customerId);

	Map<String, Object> getAccountDetailsByCustIdAndAddId(String customerId, String accountId);

	Map<String, Object> getCddDataBasedOnAccountId(String customerId, String accountId);

	void saveSubmit(Map<String, String> resData) throws ParseException, JSONException;

	Map<String, Object> getRiskDisrtibution();

	Map<String,Object> getCRRData(String crr, Integer startFrom,String inputSearch);

	Map<String, Integer> getCDDataCount();

	Map<String,Object> getCDDDataStatus(String startFrom, String dtInputFields);

	Map<String, Object> getCustomerTopData(String custID, String accountId);
}
