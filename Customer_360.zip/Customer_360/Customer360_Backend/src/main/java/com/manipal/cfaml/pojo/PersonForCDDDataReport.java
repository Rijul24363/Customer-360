package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PersonForCDDDataReport {
	private String salutation;
	private String shortName;
	private String age;
	private String lastName;
	private String dateOfBirthAd;
	private String firstName;
	private String middleName;
	private String nationality;
	private String gender;
	private String residence;
	private String maritalStatus;
	private String educationLevel;
	private String dateOfBirthBs;
}
