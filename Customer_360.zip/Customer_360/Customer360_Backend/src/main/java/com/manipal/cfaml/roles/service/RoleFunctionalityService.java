package com.manipal.cfaml.roles.service;

import java.util.List;
import java.util.Map;

import com.manipal.cfaml.entity.UserInfo;
import com.manipal.cfaml.roles.entity.FunctionalityList;

public interface RoleFunctionalityService {

	List<FunctionalityList> getPagesForRolesOnUserId(String userId);
	
	UserInfo getUserDetails(String userName);

	Map<String, Object> getUserDetails(String userId, String roleId);
}
