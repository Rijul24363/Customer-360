package com.manipal.cfaml.constant;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.springframework.util.ObjectUtils;

public class CommonUseMethod {

	public static boolean checkNullEmptyBlankForCddReport(Object strToCheck, String hideField) {
		// check whether the given string is null or not
		if(hideField.equals("false")) {
			return true;
		}
		if (strToCheck == null) {
			return true;
		}
		// check whether the given string is empty or not
		else if (ObjectUtils.isEmpty(strToCheck)) {
			return true;
		}
		// check whether the given string is blank or not
		else {
			return false;
		}
	}
	
	public static boolean checkNullEmptyBlank(Object strToCheck) {
		// check whether the given string is null or not
		if (strToCheck == null) {
			return true;
		}
		// check whether the given string is empty or not
		else if (ObjectUtils.isEmpty(strToCheck)) {
			return true;
		}
		// check whether the given string is blank or not
		else {
			return false;
		}
	}
	
	public static String adtobs(String adDate) {
        if (adDate != null && !adDate.isEmpty()) {
            LocalDate adLocalDate = LocalDate.parse(adDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate bsLocalDate = adLocalDate.plusYears(56).plusMonths(8).plusDays(14);
            return bsLocalDate.plusDays(1).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } 
//        else if (bsDate != null && !bsDate.isEmpty()) {
//            LocalDate bsLocalDate = LocalDate.parse(bsDate, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
//            LocalDate adLocalDate = bsLocalDate.minusYears(56).minusMonths(8).minusDays(16);
//            return adLocalDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
//        }
        return null;
    }
	
	public static int calculateAge(Date dateOfBirth) { 
		LocalDate birthDate = dateOfBirth.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate today = LocalDate.now();
		Period period = Period.between(birthDate, today);
		return period.getYears(); 
	}
	
	public static int calculateAgeString(String dateOfBirth) {
        LocalDate today = LocalDate.now();
        LocalDate birthDate = LocalDate.parse(dateOfBirth, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        Period period = Period.between(birthDate, today);
        return period.getYears();
    }
}
