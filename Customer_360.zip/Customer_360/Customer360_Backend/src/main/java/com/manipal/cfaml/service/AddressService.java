package com.manipal.cfaml.service;

import java.util.Map;

/**
 * @author Rahul Rathod
 *
 * 
 */

public interface AddressService {
//	 Map<String, Object> getAddressDetails();


}
