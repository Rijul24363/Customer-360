package com.manipal.cfaml.serviceImpl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.repository.CountryCodeRepository;
import com.manipal.cfaml.repository.StateCodeRepository;
import com.manipal.cfaml.service.AddressService;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	CountryCodeRepository countryCodeRepo;

	@Autowired
	StateCodeRepository stateCodeRepo;


}
