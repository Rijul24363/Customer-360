package com.manipal.cfaml.reports.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.cfaml.reports.repository.SARReportRepository;
import com.manipal.cfaml.reports.service.SARReportService;


@Service
public class SARReportServiceImpl implements SARReportService{
	
	@Autowired
	SARReportRepository sarReportRepo;

	@Override
	public List<Map<String, Object>> getSuspiciousActivityReport(String customerId, 
			String fromDate, String toDate, String scenarioName, String branchName, String status) {
		
		return sarReportRepo.getSuspiciousActivityReport(customerId, fromDate, toDate, scenarioName, branchName, status);
	}

	@Override
	public HashMap<String, Object> scenarioAndBranchDetails() {
		return sarReportRepo.scenarioAndBranchDetails();
	}


	@Override
	public ArrayList<HashMap<String, Object>> getDirectorData(String customerId, String custType, String accountId) {
		return sarReportRepo.getPersonInfo("director", custType, customerId, accountId);
	}
	
	@Override
	public ArrayList<HashMap<String, Object>> getSignatoryData(String customerId, String custType, String accountId) {
		return sarReportRepo.getPersonInfo("signatory", custType, customerId, accountId);

	}

	@Override
	public Map<String, Object> getEntityData(String customerId,String accountId) {
		
		return sarReportRepo.getEntityData(customerId,accountId);
	}

	@Override
	public Map<String, Object> getAccountDetails(String customerId, String accountId) {
		// TODO Auto-generated method stub
		return sarReportRepo.getAccountDetails(customerId,accountId);
	}

	@Override
	public List<Map<String, Object>> getReportIndicatorsList() {
		return sarReportRepo.getReportIndicatorsList();
	}


}
