package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "ACCOUNT_PERSONS_INFO")
public class AccountPersonsInfo {

	@Id
	@Column(name = "Id")
	private String id;

	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "cbs_party_role_type")
	private String cbsPartyRoleType;

	@Column(name = "Roles")
	private String roles;

	@Column(name = "cbs_account_person_role_type")
	private String cbsAccountPersonRoleType;

	@Column(name = "cbs_entity_person_role_type")
	private String cbsEntityPersonRoleType;

	@Column(name = "Title")
	private String title;

	@Column(name = "account_id")
	private String accountId;

	@Column(name = "ssn_citizenship")
	private String ssnCitizenship;

	@Column(name = "First_Name")
	private String firstName;

	@Column(name = "Middle_Name")
	private String middleName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@Column(name = "nationality")
	private String nationality;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "Father_Name")
	private String fatherName;

	@Column(name = "mother_name")
	private String motherName;

	@Column(name = "Spouse_Name")
	private String spouseName;

	@Column(name = "grand_father_name")
	private String grandFatherName;

	@Column(name = "grandmother_name")
	private String grandMotherName;

	@Column(name = "MARITAL_STATUS")
	private String maritalStatus;

	@Column(name = "occupation")
	private String occupation;

	@Column(name = "PASSPORT_NO")
	private String passportNo;

	@Column(name = "Telephone_Number")
	private String telephoneNumber;

	@Column(name = "mobile_Number")
	private String mobileNumber;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "income")
	private String income;

	@Column(name = "taddress1")
	private String taddress1;

	@Column(name = "taddress2")
	private String taddress2;

	@Column(name = "taddress3")
	private String taddress3;

	@Column(name = "taddress4")
	private String taddress4;

	@Column(name = "tcity_name ")
	private String tcityName;

	@Column(name = "tstate")
	private String tstate;

	@Column(name = "tzipcode")
	private String tzipcode;

	@Column(name = "tcountry")
	private String tcountry;
	
	@Column(name = "GPLUS_CODE")
	private String gPlusCode;

	@Column(name = "Paddress1")
	private String paddress1;

	@Column(name = "Paddress2")
	private String paddress2;

	@Column(name = "paddress3")
	private String paddress3;

	@Column(name = "paddress4")
	private String paddress4;

	@Column(name = "Pcity_name")
	private String pcityName;

	@Column(name = "Pstate")
	private String pState;

	@Column(name = "pzipcode")
	private String pZipcode;

	@Column(name = "pcountry")
	private String pCountry;
	
	@Column(name = "P_GPLUS_CODE")
	private String pgPlusCode;
	
	@Column(name = "RESIDENCE")
	private String residence;

	@Column(name = "child_name")
	private String childName;

	@Column(name = "identification_doc_type")
	private String identificationDocType;

	@Column(name = "identification_doc_number")
	private String identificationDocNumber;

	@Column(name = "identification_doc_issued_by")
	private String idenificationDocIssuedBy;

	@Column(name = "identification_doc_issued_date")
	private Date identificationDocIssuedDate;

	@Column(name = "identification_doc_expiry_date")
	private Date identificationDocExpiryDate;

	@Column(name = "identification_doc_issue_country")
	private String identificationDocIssueCountry;

	@Column(name = "SIdentification_doc_type")
	private String sIdentificationDocType;

	@Column(name = "SIdentification_doc_number")
	private String sIdentificationDocNumber;

	@Column(name = "SIdenification_doc_issued_by")
	private String sIdenificationDocIssuedBy;

	@Column(name = "SIdentification_doc_issued_date")
	private Date sIdentificationDocIssuedDate;

	@Column(name = "SIdentification_doc_expiry_date")
	private Date sIdentificationDocExpiryDate;

	@Column(name = "SIdentification_doc_issue_country")
	private String sIdentificationDocIssueCountry;
	
}
