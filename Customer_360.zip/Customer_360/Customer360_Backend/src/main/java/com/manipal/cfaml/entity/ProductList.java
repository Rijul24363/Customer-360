package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "PRODUCT_LIST")
public class ProductList {

	@Id
	@Column(name = "TYPE")
	private String type;
	
	@Column(name = "DES")
	private String des;
	
	@Column(name = "CLS")
	private String cls;
	
	@Column(name = "GRP")
	private String grp;
	
	@Column(name = "WEIGHTAGE")
	private String weightage;
	
	@Column(name = "GRP2")
	private String grp2;
	
//	@Column(name = "CBS_TYPE")
//	private String cbsType;
}
