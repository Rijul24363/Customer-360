package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;

public interface CommonRepo {

	List<Map<String, Object>> getAllAccountTypeList();

	List<Map<String, Object>> getNatureOfBusiness();

	List<Map<String, Object>> getEducationList();

	List<Map<String, Object>> getIdentificationType();

	List<Map<String, Object>> getCurrency();

	List<Map<String, Object>> maritalStatus();
	
	List<Map<String, Object>> accountStatus();

	List<Map<String, Object>> accountStatusType();

	List<Map<String, Object>> getBranchList();

}
