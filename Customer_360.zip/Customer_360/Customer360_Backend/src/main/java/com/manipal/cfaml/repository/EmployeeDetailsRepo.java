package com.manipal.cfaml.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.EmployeeDetails;

public interface EmployeeDetailsRepo extends JpaRepository<EmployeeDetails, String> {

	@Query(nativeQuery = true, value="select ed.* from "
			+ "VIZPROD.USER_INFO ui, entprod.EMPLOYEE_DETAILS ed "
			+ "where ui.USER_ID  = ed.EMP_NO "
			+ "and ui.USER_ID  not in (:empId)")
	List<EmployeeDetails> getEmployeeListExceptEmpId(String empId);
}
