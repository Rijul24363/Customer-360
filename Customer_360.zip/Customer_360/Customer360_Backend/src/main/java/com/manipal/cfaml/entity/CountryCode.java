package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="COUNTRY_CODE")
public class CountryCode {
	
	@Id
	@Column(name = "COUNTRY_CODE")
	private String countryCode;

	@Column(name = "COUNTRY_ALPHA2")
	private String countryAlpha2;
	
	@Column(name = "COUNTRY_ALPHA3")
	private String countryAlpha3;
	
	@Column(name = "COUNTRY_NAME")
	private String countryName;

}
