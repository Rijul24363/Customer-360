package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class AccountForCDDDataReport {
	private String estimatedMonthlyIncome;
	private String estimatedAnnualIncome;
	private String estimatedAnnualTurnover;
	private String accountCurrency;
	private String accountOpeningDate;
	private String accountAge;
	private String accountBranch;
	private String accountType;
	private String accountName;
	private String accountNumber;
	private String purposeOfAccount;
	private String upperLimitOnLoanAccounts;
	private String relatedPersonalType;
	private String accountStatusType;
}
