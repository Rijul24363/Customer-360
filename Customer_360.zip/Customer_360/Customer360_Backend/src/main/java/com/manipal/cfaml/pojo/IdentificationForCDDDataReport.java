package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class IdentificationForCDDDataReport {
	private String identificationDocType;
	private String identificationDocNumber;
	private String identificationDocIssuedDateAd;
	private String identificationDocIssuedDateBs;
	private String idenificationDocIssuedBy;
	private String countryOfIssue;
	private String expiredDateAd;
	private String expiredDateBs;
}
