package com.manipal.cfaml.reports.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface SARReportRepository {

	List<Map<String,Object>> getSuspiciousActivityReport(String customerId, String fromDate,
			String toDate, String scenarioName, String branchName, String status);

	HashMap<String, Object> scenarioAndBranchDetails();

	ArrayList<HashMap<String, Object>> getPersonInfo(String accountPersonInfo, String custType,
			String customerId, String accountId);

	Map<String, Object> getEntityData(String customerId, String accountId);

	Map<String, Object> getAccountDetails(String customerId, String accountId);

	Map<String, Object> GoAmlConfigurationDetails();

	List<Map<String, Object>> getReportIndicatorsList();
	
	
}
