package com.manipal.cfaml.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.manipal.cfaml.entity.CountryCode;

public interface CountryCodeRepository extends JpaRepository<CountryCode, String>{
	
	List<CountryCode>findAll();

}
