package com.manipal.cfaml.pojo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class AccountPersonForCDDDatReportList {

	private String fullName;
	private String relationship;
	private String contactNumber;
	private String dateOfBirthAd;
	private String pPrimaryIdType;
	private String pPrimaryIdNumber;
	private String pIssueDateAd;
	private String pIssueDateBs;
	private String tPrimaryIdType;
	private String tPrimaryIdNumber;
	private String tIssueDateAd;
	private String tIssueDateBs;
	private String pIssueAuthority;
	private String tIssueAuthority;
	private String pIssuseCountry;
	private String tIssuseCountry;
	private String dateOfBirthBs;
	private String currentWard;
	private String currentDistrict;
	private String currentmnVdcCity;
	private String currentProvince;
	private String currentCountry;
	private String currentCountryCode;
	private String currentGooglePlusCode;
	private String parmanentHouseNumber;
	private String parmanentTole;
	private String parmanentDistrict;
	private String parmanentmnVdcCity;
	private String parmanentProvince;
	private String parmanentCountry;
	private String parmanentCountryCode;
	private String parmanentGooglePlusCode;
	private String parmanentzipCode;
	private String currentzipCode;
	private String pExpiryDateAd;
	private String pExpiryDateBs;
	private String tExpiryDateAd;
	private String tExpiryDateBs;
	private String currentHouseNumber;
	private String currentTole;
	private String parmanentWard;
}
