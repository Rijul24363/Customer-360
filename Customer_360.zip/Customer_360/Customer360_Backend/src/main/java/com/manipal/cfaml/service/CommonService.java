package com.manipal.cfaml.service;

import java.util.List;
import java.util.Map;

import com.manipal.cfaml.entity.EmployeeDetails;

public interface CommonService {

	
	List<EmployeeDetails> getEmployeeListExceptEmpId(String userId);
	
	Map<String, Object> getEnum();

	List<Map<String, Object>> getKycMasterData();

	List<Map<String, Object>> getBranchList();


}
