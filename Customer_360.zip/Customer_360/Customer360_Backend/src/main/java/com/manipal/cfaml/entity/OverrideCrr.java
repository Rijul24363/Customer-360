package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="OVERRIDE_CRR" ,schema = "VIZPROD")
public class OverrideCrr {

	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "ACCOUNT_ID")
	private String accountId;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Column(name = "OVERRIDE_USERID")
	private String overrideUserId;
	
	@Column(name = "OVERRIDE_REASON")
	private String overrideReason;
	
	@Column(name = "OVERRIDE_CRR")
	private String overrideCrr;
	
	@Column(name = "OVERRIDE_DATE ")
	private Date overrideDate;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "APPROVED_REJECTED_BY")
	private String approvedRejectedBy;
	
	@Column(name = "REVIEW_COMMENT")
	private String reviewComment;
	
	@Column(name = "WITHDRAWAL_REASON")
	private String withdrawalReason;
	
	@Column(name = "WITHDRAWL_INFO")
	private String withdrawalInfo;
	
	@Column(name = "WITHDRAWAL_USERID")
	private String withdrawalUserId;
	
	@Column(name = "WITHDRAWAL_DATE")
	private Date withdrawalDate;
}
