package com.manipal.cfaml.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.FinancialTransaction;


public interface FinancialTransactionRepository extends JpaRepository<FinancialTransaction, String> {
	
	
	@Query(nativeQuery=true, value="SELECT SUM(LCY_AMOUNT) amt,COUNT(TRANSACTION_AMOUNT) cnt,channel FROM ENTPROD.Financial_Transaction where CUSTOMER_ID =:customerId AND TRANSACTION_VALUE_DATE BETWEEN :startDate AND :endDate GROUP By channel")
	List<Map<String, Object>> getTxnAmtAndChannel(String customerId,String startDate,String endDate);
	
	@Query(nativeQuery=true, value="SELECT SUM(TRANSACTION_AMOUNT) amt,COUNT(TRANSACTION_AMOUNT) cnt,channel FROM ENTPROD.Financial_Transaction where CUSTOMER_ID =:customerId AND ACCOUNT_ID =:accountId AND TRANSACTION_VALUE_DATE BETWEEN :startDate AND :endDate GROUP By channel")
	List<Map<String, Object>> getTxnAmtAndChannel(String customerId,String accountId,String startDate,String endDate);
	

	@Query(nativeQuery=true, value="SELECT\r\n"
			+ "	TRANSACTION_MODE transMode,\r\n"
			+ "	TRANSACTION_TYPE as transaction_type, \r\n"
			+ "	SUM(LCY_AMOUNT) amt,\r\n"
			+ "	COUNT(LCY_AMOUNT) cnt\r\n"
			+ "FROM\r\n"
			+ "	ENTPROD.Financial_Transaction\r\n"
			+ "where\r\n"
			+ "	CUSTOMER_ID =:customerId\r\n"
			+ "	AND \r\n"
			+ "	TRANSACTION_VALUE_DATE BETWEEN :startDate AND :endDate\r\n"
			+ "GROUP By\r\n"
			+ "	TRANSACTION_MODE,\r\n"
			+ "	TRANSACTION_TYPE")
	List<Map<String, Object>> getModeWiseTxnAmtAndCount(String customerId,String startDate,String endDate);
	
	@Query(nativeQuery=true, value="SELECT\r\n"
			+ "	TRANSACTION_MODE transMode,\r\n"
			+ "	TRANSACTION_TYPE as transaction_type, \r\n"
			+ "	SUM(TRANSACTION_AMOUNT) amt,\r\n"
			+ "	COUNT(TRANSACTION_AMOUNT) cnt\r\n"
			+ "FROM\r\n"
			+ "	ENTPROD.Financial_Transaction\r\n"
			+ "where\r\n"
			+ "	CUSTOMER_ID =:customerId  AND ACCOUNT_ID =:accountId \r\n"
			+ "	AND \r\n"
			+ "	TRANSACTION_VALUE_DATE BETWEEN :startDate AND :endDate\r\n"
			+ "GROUP By\r\n"
			+ "	TRANSACTION_MODE,\r\n"
			+ "	TRANSACTION_TYPE")
	List<Map<String, Object>> getModeWiseTxnAmtAndCount(String customerId,String accountId,String startDate,String endDate);
	
}
 