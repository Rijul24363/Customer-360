package com.manipal.cfaml.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.manipal.cfaml.entity.AccountRelation;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Repository
public interface AccountRelationRepository extends JpaRepository<AccountRelation, String> {

//	@Query(nativeQuery=true, value="select c.COMPUTATION_INFO from VIZPROD.CRR_COMPUTATION_INFO c where c.CUSTOMER_ID = :customerId and c.ACCOUNT_ID = :accountId and c.COMPUTED_DATE BETWEEN :startDate AND :endDate")
//	List<AccountRelation> findAll();
}
