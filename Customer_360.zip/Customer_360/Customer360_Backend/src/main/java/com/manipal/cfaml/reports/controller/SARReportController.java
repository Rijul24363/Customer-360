package com.manipal.cfaml.reports.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.reports.service.SARReportService;

@RequestMapping("reports/sar_report")
@RestController
public class SARReportController {
	@Autowired
	SARReportService service;
	
	
	@GetMapping("/getSuspiciousActivityReportList")
	public List<Map<String,Object>> getSuspiciousActivityReport(
			@RequestParam(required = false, name="customerId")String customerId, 
			@RequestParam(name="startDate")String startDate,
			@RequestParam(name="endDate")String endDate,
			@RequestParam(required = false, name="scenarioName")String scenarioName,
			@RequestParam(required = false, name="branchName")String branchName,
			@RequestParam(required = false, name="status")String status) {
		return service.getSuspiciousActivityReport(customerId,startDate,endDate,scenarioName,branchName,status);
	}
	
	
	@GetMapping("/scenarioAndBranchDetails")
	public HashMap<String,Object> scenarioDetails() {
		return service.scenarioAndBranchDetails();
	}
	
	@GetMapping("/getDirectorData")
	public ArrayList<HashMap<String, Object>> getDirectorData(@RequestParam String customerId, @RequestParam String custType, 
			@RequestParam(required = false, name="accountId")String accountId) {
		return service.getDirectorData(customerId,custType,accountId);
	}
	
	@GetMapping("/getSignatoryData")
	public ArrayList<HashMap<String, Object>> getSignatoryData(@RequestParam String customerId, @RequestParam String custType, 
			@RequestParam(required = false,name="accountId")String accountId) {
		return service.getSignatoryData(customerId,custType,accountId);
	}
	
	
	@GetMapping("/getEntityDataByCustomerId")
	public Map<String, Object> getEntityDataByCustomerId(@RequestParam String customerId,
			@RequestParam(required = false,name="accountId")String accountId) {
		return service.getEntityData(customerId,accountId);
	}
	
	@GetMapping("/getAccountDetails")
	public Map<String, Object> getAccountDetails(@RequestParam String customerId,
			@RequestParam(name="accountId")String accountId) {
		return service.getAccountDetails(customerId,accountId);
	}
	
	
	@GetMapping("/getReportIndicatorsList")
	public List<Map<String, Object>> getReportIndicatorsList() {
		return service.getReportIndicatorsList();
	}
	
}
