package com.manipal.cfaml.roles.controller;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.entity.UserInfo;
import com.manipal.cfaml.roles.entity.FunctionalityList;
import com.manipal.cfaml.roles.service.RoleFunctionalityService;
import com.manipal.cfaml.security.EncryptDecrypt;

@RequestMapping("roles")
@RestController
public class RoleFunctionalityController {
	
	@Autowired
	RoleFunctionalityService roleService;
	
	@Value("${security.encryption_key}")
	private String ENCRYPTION_KEY;
	
	@Value("${customer360UrlRedirect}")
	private String customer360UrlRedirect;
	
	@Value("${reportUrlRedirect}")
	private String reportUrlRedirect;
	
	
	@Value("${security.jwt.token.secret-key}")
	private String jetToken;

	@GetMapping("/getPagesForRolesOnUserId")
	public List<FunctionalityList> getPagesForRolesOnUserId(@RequestParam(required = false, name="userId")String userId) {
		return roleService.getPagesForRolesOnUserId(userId);
	}
	
	@PostMapping("/sessionFromJSP")
	public void sessionFromJSP(HttpServletRequest request, HttpServletResponse response) {
//		HttpSession session=request.getSession();
		String userName=request.getParameter("userName");
		String customerId=null;
		try {
			customerId=request.getParameter("customerId");
		} catch (Exception e) {			
		}
		String returnUrl=null,module=null;
    	String encodedBase64Key = EncryptDecrypt.encodeKey(ENCRYPTION_KEY);

		try {
			returnUrl=EncryptDecrypt.encryptData(request.getParameter("returnUrl"),encodedBase64Key);
		} catch (Exception e) {			
		}
		try {
			module=request.getParameter("module");
		} catch (Exception e) {			
		}
		UserInfo userData = roleService.getUserDetails(userName);
		
		String encryptUserId = null, encryptRoleId = null;
		try {
	    	encryptUserId=EncryptDecrypt.encryptData(userData.getUserId(), encodedBase64Key);
		} catch (Exception e) {
		}
		try {
			encryptRoleId=EncryptDecrypt.encryptData(userData.getRoleId(), encodedBase64Key);

		} catch (Exception e) {
		}
		try {
			String url=null;
			if(module.equalsIgnoreCase("Reports")) {
				url=reportUrlRedirect+"appLog?utoken="+encryptUserId+"&rtoken="+encryptRoleId+"&customerId="+customerId+"&returnUrl="+URLEncoder.encode(returnUrl, StandardCharsets.UTF_8.toString());
				if(returnUrl==null) {
					url=reportUrlRedirect+"appLog?utoken="+encryptUserId+"&rtoken="+encryptRoleId+"&customerId="+customerId;
				}
			}else {
				url=customer360UrlRedirect+"appLog?utoken="+encryptUserId+"&rtoken="+encryptRoleId+"&customerId="+customerId+"&returnUrl="+URLEncoder.encode(returnUrl, StandardCharsets.UTF_8.toString());
				if(returnUrl==null) {
					url=customer360UrlRedirect+"appLog?utoken="+encryptUserId+"&rtoken="+encryptRoleId+"&customerId="+customerId;
				}
			}
			response.sendRedirect(url);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@GetMapping("/getUserDetails")
	public Map<String, Object> getUserDetails(@RequestParam String userId,@RequestParam String roleId) {
		return roleService.getUserDetails(userId,roleId);
	}
}
