package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name="TASK_DETAILS", schema="VIZPROD")
public class TaskDetails {

	@Id
	@Column(name = "ACCOUNT_ID")
	private String accId;
	
	@Column(name = "TRANSACTION_REFERENCE_NUMBER")
	private String transactionReferenceNumber;
	
}
