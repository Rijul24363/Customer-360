package com.manipal.cfaml.service;

import java.util.List;
import java.util.Map;

/**
 * @author Rahul Rathod
 *
 * 
 */

public interface HistoryViewService {

	List<Map<String, Object>> getHistoryViewInfo(String custID, String accId, String startDate, String endDate);

}
