package com.manipal.cfaml.service;

import java.util.List;
import java.util.Map;

import com.manipal.cfaml.entity.SanctionsListSummary;

public interface SanctionService {
	
	List<Map<String, Object>> getSanctionListInfo(String custID, String accId,String startDate,String endDate);

}
