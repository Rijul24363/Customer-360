package com.manipal.cfaml.serviceImpl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.manipal.cfaml.entity.AccountPersonsInfo;
import com.manipal.cfaml.entity.Address;
import com.manipal.cfaml.entity.CrrComputationInfo;
import com.manipal.cfaml.entity.CustomerIdInfo;
import com.manipal.cfaml.entity.CustomerProfile;
import com.manipal.cfaml.entity.KycOtherInfo;
import com.manipal.cfaml.entity.KycReviewRequest;
import com.manipal.cfaml.entity.OverrideCrr;
import com.manipal.cfaml.repository.AccountPersonsInfoRepository;
import com.manipal.cfaml.repository.AddressRepository;
import com.manipal.cfaml.repository.CrrComputationInfoRepository;
import com.manipal.cfaml.repository.CustomerIdInfoRepository;
import com.manipal.cfaml.repository.CustomerProfileRepository;
import com.manipal.cfaml.repository.CustomerRepositoryCustom;
import com.manipal.cfaml.repository.KycMasterDataRepository;
import com.manipal.cfaml.repository.KycReviewRequestRepositoy;
import com.manipal.cfaml.repository.OverrideCrrRepository;
import com.manipal.cfaml.repository.SanctionsListSummaryRepository;
import com.manipal.cfaml.repository.kycOtherInfoRepository;
import com.manipal.cfaml.service.CustomerService;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepositoryCustom custRepositoryCustom;

	@Autowired
	private CustomerProfileRepository custRepository;

	@Autowired
	private SanctionsListSummaryRepository sanctionListSummaryRepo;

	@Autowired
	private AddressRepository addressRepo;

	@Autowired
	private AccountPersonsInfoRepository accountPersonsInfoRepo;

	@Autowired
	KycReviewRequestRepositoy kycReviewRepo;

	@Autowired
	KycMasterDataRepository kycMasRepo;

	@Autowired
	kycOtherInfoRepository KycOtherInfoRkpo;

	@Autowired
	CrrComputationInfoRepository crrComputationInfoRepo;

	@Autowired
	OverrideCrrRepository overrideCrrRepo;

	@Autowired
	CustomerIdInfoRepository customerIdInfoRepo;

	@Override
	public Map<String, Object> getRiskDisrtibution() {
		return custRepository.getRiskDisrtibution();
	}

	@Override
	public List<Map<String, Object>> searchCustomer(String custID, String custType, String custName, String panNo) {
		String query = "";
		if (custID != null) {
			query += "c.CUSTOMER_ID LIKE LOWER(CONCAT('%','" + custID + "','%'))";
		}
		if (custType != null) {
			if (custID != null) {
				query += " and ";
			}
			query += "c.CUST_TYPE LIKE LOWER(CONCAT('%','" + custType + "','%'))";
		}
		if (custName != null) {
			if (custType != null || custID != null) {
				query += " and ";
			}
			
			String[] splitspace=custName.split(" ");
			for (int i = 0; i < splitspace.length; i++) {
				query += "(LOWER(c.FIRST_NAME) LIKE LOWER(CONCAT('%','" + splitspace[i] + "','%')) or "
						+ "LOWER(c.MIDDLE_NAME) LIKE LOWER(CONCAT('%','" + splitspace[i] + "','%')) or "
						+ "LOWER(c.LAST_NAME) LIKE LOWER(CONCAT('%','" + splitspace[i] + "','%'))) and ";
			}
			query = query.substring(0, query.lastIndexOf("and"));
		}
		if (panNo != null) {
			if (custType != null || custID != null || custName != null) {
				query += " and ";
			}
			query += "c.PAN_NUMBER LIKE LOWER(CONCAT('%','" + panNo + "','%'))";
		}
		return custRepositoryCustom.findForSearchPanel(query);
	}

	@Override
	public Map<String, Object> getCustomerDetailsForCDD(String custID) {
		Map<String, Object> res = new HashMap<String, Object>();
		try {
			CustomerProfile cp = custRepository.findByCustomerId(custID).get(0);
			res.put("customerProfile", new JSONObject(cp)); 
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			res.put("address", new JSONObject(addressRepo.findByAddressId(custID)));

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			res.put("otherInfo", new JSONObject(KycOtherInfoRkpo.getKycOtherOnCustId(custID)));

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			res.put("identificationData", customerIdInfoRepo.getByCustomerId(custID));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public List<String> getAccountListByCustomerId(String customerId) {
		return custRepository.findAccountIdByCustomerId(customerId);
	}

	@Override
	public Map<String, Object> getAccountDetailsByCustIdAndAddId(String customerId, String accountId) {
		return custRepository.getAccountDetailsByCustIdAndAddId(customerId, accountId);
	}

	@Override
	public Map<String, Object> getCddDataBasedOnAccountId(String customerId, String accountId) {
		Map<String, Object> res = new HashMap<String, Object>();
		accountId = "%" + accountId + "%";
		res.put("nominee", accountPersonsInfoRepo.findByCustomerIdAndAccountIdAndCbsPartyRoleType(customerId, accountId,
				"Nominee"));
		res.put("beneficiary", accountPersonsInfoRepo.findByCustomerIdAndAccountIdAndCbsPartyRoleType(customerId,
				accountId, "Beneficiary"));
		res.put("directors",
				accountPersonsInfoRepo.findByCustomerIdAndAccountIdAndCbsPartyRoleType(customerId, accountId, "BOD"));
		res.put("signatories", accountPersonsInfoRepo.findByCustomerIdAndAccountIdAndCbsPartyRoleType(customerId,
				accountId, "Signatory"));
		return res;
	}

	@Override
	public void saveSubmit(Map<String, String> resData) throws ParseException, JSONException {
		KycReviewRequest kycReviewRequest=new KycReviewRequest();

		if (resData.get("screenName").equals("History View")) {
			Optional<KycReviewRequest> optionalKyc = kycReviewRepo.findById(Long.parseLong(String.valueOf(resData.get("requestId"))));
			if (optionalKyc.isPresent()) {
				KycReviewRequest kyc = optionalKyc.get();
				kycReviewRequest=kyc;
				kycReviewRequest.setStatus(resData.get("status"));
				kycReviewRequest.setApprovedBy(resData.get("auditedBy"));
				kycReviewRequest.setApprovedDate(new Date());;
			}
		}else {
			long requestId=0;
			try {
				requestId = kycReviewRepo.latestCount();
				requestId = requestId+1;
			} catch (Exception e) {
				requestId = requestId+1;
			}
			//maker checker
			if (resData.get("status").contains("A") && !resData.get("screenName").equals("History View")) {
				kycReviewRequest.setRequestId(requestId);
				kycReviewRequest.setCustomerId(resData.get("customerId"));
				kycReviewRequest.setAccountId(resData.get("accountId"));
				kycReviewRequest.setComment(resData.get("comment"));
				kycReviewRequest.setCreatedBy(resData.get("createdBy"));
				kycReviewRequest.setCreatedDate(new Date());
				kycReviewRequest.setApprovedBy(resData.get("auditedBy"));
				kycReviewRequest.setApprovedDate(new Date());
				kycReviewRequest.setScreenName(resData.get("screenName"));
				kycReviewRequest.setFieldsUpdated(resData.get("fieldsUpdated"));
				kycReviewRequest.setStatus(resData.get("status"));
				kycReviewRequest.setCbsAccountId(resData.get("selectedAccountData"));
				kycReviewRequest.setIdentificationId(resData.get("selectedIdentictionNumber"));
			} else {			
				kycReviewRequest.setRequestId(requestId);
				kycReviewRequest.setCustomerId(resData.get("customerId"));
				kycReviewRequest.setAccountId(resData.get("accountId"));
				kycReviewRequest.setComment(resData.get("comment"));
				kycReviewRequest.setCreatedBy(resData.get("createdBy"));
				kycReviewRequest.setCreatedDate(new Date());
				kycReviewRequest.setApprovedBy(null);
				kycReviewRequest.setApprovedDate(null);
				kycReviewRequest.setScreenName(resData.get("screenName"));
				kycReviewRequest.setFieldsUpdated(resData.get("fieldsUpdated"));
				kycReviewRequest.setStatus(resData.get("status"));
				kycReviewRequest.setCbsAccountId(resData.get("selectedAccountData"));
				kycReviewRequest.setIdentificationId(resData.get("selectedIdentictionNumber"));

			}
		}

			if (resData.get("status").contains("A")) {
				if (resData.get("screenName").contains("CDD/Other")) {
					KycOtherInfo KycOtherInfo = new KycOtherInfo();
					JSONObject json = new JSONObject(resData.get("fieldsUpdated"));
					String newValue = null;
					String fieldValue = null;
					@SuppressWarnings("unchecked")
					Iterator<String> keys = json.keys();

					while (keys.hasNext()) {
						try {

							fieldValue = keys.next();
							JSONObject value = json.getJSONObject(fieldValue);
							newValue = value.get("newValue").toString();

							if (fieldValue.equals("customerLiabilityReport")) {
								if (newValue != null && !newValue.isEmpty()) {
									KycOtherInfo.setServiceAvailed(newValue);
								}
							} else if (fieldValue.equals("customerLiabilityReport")) {
								if (newValue != null && !newValue.isEmpty()) {
									KycOtherInfo.setCustomerLiabilityReport(newValue);
								}
							} else if (fieldValue.equals("customerLiabilityReport")) {
								if (newValue != null && !newValue.isEmpty()) {
									KycOtherInfo.setOtherReport(newValue);
								}
							}
							KycOtherInfo.setAccountId(resData.get("accountId"));
							KycOtherInfo.setCustomerId(resData.get("customerId"));						
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

				} else if (resData.get("screenName").contains("CDD/")
						|| resData.get("screenName").contains("View") && !resData.get("screenName").contains("CDD/Other")) {
					try {
						saveDataInTable(kycReviewRequest.getFieldsUpdated(), kycReviewRequest.getScreenName(), kycReviewRequest.getCustomerId(),
								kycReviewRequest.getAccountId(), kycReviewRequest.getCbsAccountId(),
								kycReviewRequest.getIdentificationId());
					} catch (ParseException | JSONException e) {
						e.printStackTrace();
					}
				}					
				
		}
			try {
				kycReviewRepo.save(kycReviewRequest);
			} catch (Exception e) {
				e.printStackTrace();
			}

	}

	private void saveDataInTable(String fieldsUpdated, String screenName, String custId, String accId,
			String selectedAccountData, String selectedIdentictionNumber) throws ParseException, JSONException {
		JSONObject json = new JSONObject(fieldsUpdated);
		String newValue = null;
		String feildValue = null;
		Iterator<String> keys = json.keys();
		Map<String, Object> customerProfile = new HashMap<>();
		Map<String, Object> accountPersonsInfo = new HashMap<>();
		Map<String, Object> address = new HashMap<>();
		Map<String, Object> identification = new HashMap<>();

		while (keys.hasNext()) {
			try {
				feildValue = keys.next();
				JSONObject value = json.getJSONObject(feildValue);
				newValue = value.get("newValue").toString();
			} catch (Exception e) {
			}

			try {
				if (screenName.contains("View")) {
					if (feildValue.equals("pep")) {
						customerProfile.put("pep", newValue);
					} else if (feildValue.equals("fatca")) {
						customerProfile.put("fatca", newValue);
					}
				} else if (screenName.contains("CDD/Personal")) {
					if (feildValue.equals("salutation")) {
						customerProfile.put("title", newValue);
					} else if (feildValue.equals("shortName")) {
						customerProfile.put("alias", newValue);
					} else if (feildValue.equals("lastName")) {
						customerProfile.put("lastName", newValue);
					} else if (feildValue.equals("dateOfBirthAd")) {
						customerProfile.put("dateOfBirth", newValue);
					} else if (feildValue.equals("firstName")) {
						customerProfile.put("firstName", newValue);
					} else if (feildValue.equals("middleName")) {
						customerProfile.put("middleName", newValue);
					} else if (feildValue.equals("nationality")) {
						customerProfile.put("nationality", newValue);
					} else if (feildValue.equals("gender")) {
						customerProfile.put("sex", newValue);
					} else if (feildValue.equals("residence")) {
						customerProfile.put("residence", newValue);
					} else if (feildValue.equals("maritalStatus")) {
						customerProfile.put("maritalStatusDiscription", newValue);
					} else if (feildValue.equals("educationLevel")) {
						customerProfile.put("educationLevel", newValue);
					}
				} else if (screenName.contains("CDD/Entity")) {
					if (feildValue.equals("fullName")) {
//						String name[] = fullNameSplit(newValue);
						customerProfile.put("firstName", newValue);
//						customerProfile.put("middleName", name[1]);
//						customerProfile.put("lastName", name[2]);
					} else if (feildValue.equals("shortName")) {
						customerProfile.put("alias", newValue);
					} else if (feildValue.equals("dateOfEstablismentAd")) {
						customerProfile.put("dateOfBirth", newValue);
					} else if (feildValue.equals("businessList")) {
						customerProfile.put("businessList", newValue);
					} else if (feildValue.equals("incorporationNumber")) {
						customerProfile.put("incorporationNumber", newValue);
					} else if (feildValue.equals("incorporatingBody")) {
						customerProfile.put("incoprporationIssuedBy", newValue);
					} else if (feildValue.equals("incorporatingCountry")) {
						customerProfile.put("incoporationIssuedCountry", newValue);
					} else if (feildValue.equals("panNumber")) {
						customerProfile.put("panNo", newValue);
					} else if (feildValue.equals("panIssueDateAd")) {
						customerProfile.put("panIssueDate", newValue);
					}else if (feildValue.equals("typeOfIndustry")) {
						customerProfile.put("sectorCode", newValue);
					}
				} else if (screenName.contains("CDD/Identification")) {
					if (feildValue.equals("identificationDocType")) {
						identification.put("identificationDocType", newValue);
					} else if (feildValue.equals("identificationDocNumber")) {
						identification.put("identificationDocNumber", newValue);
					} else if (feildValue.equals("identificationDocIssuedDateAd")) {
						identification.put("identificationDocIssuedDate", newValue);
					} else if (feildValue.equals("idenificationDocIssuedBy")) {
						identification.put("idenificationDocIssuedBy", newValue);
					} else if (feildValue.equals("expiredDateAd")) {
						identification.put("identificationDocExpiredDate", newValue);
					} else if (feildValue.equals("countryOfIssue")) {
						identification.put("identificationDocIssueCountry", newValue);
					}
				} else if (screenName.contains("CDD/Address")) {
					if (feildValue.equals("currentHouseNumber")) {
						address.put("taddress1", newValue);
					} else if (feildValue.equals("currentTole")) {
						address.put("taddress2", newValue);
					} else if (feildValue.equals("currentWard")) {
						address.put("taddress3", newValue);
					} else if (feildValue.equals("currentDistrict")) {
						address.put("taddress4", newValue);
					} else if (feildValue.equals("currentMnVdcCity")) {
						address.put("cityName", newValue);
					} else if (feildValue.equals("currentProvince")) {
						address.put("state", newValue);
					} else if (feildValue.equals("currentCountryCode")) {
						address.put("country", newValue);
					} else if (feildValue.equals("currentCountry")) {
						address.put("country", newValue);
					} else if (feildValue.equals("currentGooglePlusCode")) {
						address.put("gplusCode", newValue);
					} else if (feildValue.equals("currentzipCode")) {
						address.put("zipcode", newValue);
					} else if (feildValue.equals("parmanentHouseNumber")) {
						address.put("paddress1", newValue);
					} else if (feildValue.equals("parmanentTole")) {
						address.put("paddress2", newValue);
					} else if (feildValue.equals("parmanentWard")) {
						address.put("paddress3", newValue);
					} else if (feildValue.equals("parmanentDistrict")) {
						address.put("paddress4", newValue);
					} else if (feildValue.equals("parmanentmnVdcCity")) {
						address.put("pcityName", newValue);
					} else if (feildValue.equals("parmanentProvince")) {
						address.put("pstate", newValue);
					} else if (feildValue.equals("parmanentCountryCode")) {
						address.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentCountry")) {
						address.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentGooglePlusCode")) {
						address.put("pgPlusCode", newValue);
					} else if (feildValue.equals("parmanentzipCode")) {
						address.put("pzipcode", newValue);
					} else if (feildValue.equals("landLineNumber")) {
						customerProfile.put("landLineNumber", newValue);
					} else if (feildValue.equals("mobileNumber")) {
						customerProfile.put("mobileNumber", newValue);
					} else if (feildValue.equals("emailAddress")) {
						customerProfile.put("emailId", newValue);
					} else if (feildValue.equals("website")) {
						customerProfile.put("website", newValue);
					}
				} else if (screenName.contains("CDD/Revenue")) {
					if (feildValue.equals("nameOfTheEmployer")) {
						customerProfile.put("nameOfTheEmployer", newValue);
					} else if (feildValue.equals("designation")) {
						customerProfile.put("designation", newValue);
					} else if (feildValue.equals("employerLineOfBusiness")) {
						customerProfile.put("nameOfBusiness", newValue);
					} else if (feildValue.equals("workExperience")) {
						customerProfile.put("workExperience", newValue);
					} else if (feildValue.equals("department")) {
						customerProfile.put("department", newValue);
					} else if (feildValue.equals("regularSourceOfIncome")) {
						customerProfile.put("sourceOfIncome", newValue);
					} else if (feildValue.equals("sourceOfWealth")) {
						customerProfile.put("sourceOfWealth", newValue);
					} else if (feildValue.equals("netWorth")) {
						customerProfile.put("netWorth", newValue);
					} else if (feildValue.equals("panNumber")) {
						customerProfile.put("panNo", newValue);
					} else if (feildValue.equals("employersContactNumber")) {
						customerProfile.put("employersContactNumber", newValue);
					} else if (feildValue.equals("parmanentHouseNumber")) {
						address.put("empaddress1", newValue);
					} else if (feildValue.equals("parmanentTole")) {
						address.put("empaddress2", newValue);
					} else if (feildValue.equals("parmanentWard")) {
						address.put("empaddress3", newValue);
					} else if (feildValue.equals("parmanentDistrict")) {
						address.put("empaddress4", newValue);
					} else if (feildValue.equals("parmanentmnVdcCity")) {
						address.put("empcityname", newValue);
					} else if (feildValue.equals("parmanentProvince")) {
						address.put("empstate", newValue);
					} else if (feildValue.equals("parmanentCountryCode")) {
						address.put("empcountry", newValue);
					} else if (feildValue.equals("parmanentCountry")) {
						address.put("empcountry", newValue);
					} else if (feildValue.equals("parmanentGooglePlusCode")) {
						address.put("empgpcode", newValue);
					} else if (feildValue.equals("parmanentzipCode")) {
						address.put("empzipcode", newValue);
					} else if (feildValue.equals("nameOfBusiness")) {
						customerProfile.put("nameOfBusiness", newValue);
					} else if (feildValue.equals("typeOfBusiness")) {
						customerProfile.put("typeOfBusiness", newValue);
					} else if (feildValue.equals("contactNumber")) {
						customerProfile.put("mobileNumber", newValue);
					} else if (feildValue.equals("sourceOfIncomeOfTheProvider")) {
						customerProfile.put("sourceOfIncome", newValue);
					}
				} else if (screenName.contains("CDD/Family")) {
					if (feildValue.equals("fatherName")) {
						customerProfile.put("fatherName", newValue);
					} else if (feildValue.equals("motherName")) {
						customerProfile.put("motherName", newValue);
					} else if (feildValue.equals("spouseName")) {
						customerProfile.put("spouseName", newValue);
					} else if (feildValue.equals("grandFatherName")) {
						customerProfile.put("grandFatherName", newValue);
					} else if (feildValue.equals("grandMotherName")) {
						customerProfile.put("grandMotherName", newValue);
					} else if (feildValue.equals("sonFullName")) {
						customerProfile.put("sonFullName", newValue);
					}  else if (feildValue.equals("sonFullName2")) {
						customerProfile.put("sonFullName2", newValue);
					}else if (feildValue.equals("daughterFullName")) {
						customerProfile.put("daughterFullName", newValue);
					}else if (feildValue.equals("daughterFullName2")) {
						customerProfile.put("daughterFullName2", newValue);
					}
				} else if (screenName.contains("CDD/Directors")) {
					accountPersonsInfo.put("cbsrole", "BOD");

					if (feildValue.equals("fullName")) {
						String name[] = fullNameSplit(newValue);
						try{accountPersonsInfo.put("firstName", name[0]);}catch(Exception e) {}
						try{accountPersonsInfo.put("middleName", name[1]);}catch(Exception e) {}
						try{accountPersonsInfo.put("lastName", name[2]);}catch(Exception e) {}
					} else if (feildValue.equals("relationship")) {
						accountPersonsInfo.put("cbsAccountPersonRoleType", newValue);
					} else if (feildValue.equals("contactNumber")) {
						accountPersonsInfo.put("contactNumber", newValue);
					} else if (feildValue.equals("dateOfBirthAd")) {
						accountPersonsInfo.put("dob", newValue);
					} else if (feildValue.equals("pPrimaryIdType")) {
						accountPersonsInfo.put("identificationDocType", newValue);
					} else if (feildValue.equals("pPrimaryIdNumber")) {
						accountPersonsInfo.put("identificationDocNumber", newValue);
					} else if (feildValue.equals("pIssuseCountry")) {
						accountPersonsInfo.put("identificationDocIssueCountry", newValue);
					} else if (feildValue.equals("pIssueDateAd")) {
						accountPersonsInfo.put("identificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pExpiryDateAd")) {
						accountPersonsInfo.put("identificationDocExpiredDate", newValue);
					} else if (feildValue.equals("tPrimaryIdType")) {
						accountPersonsInfo.put("sIdentificationDocType", newValue);
					} else if (feildValue.equals("tPrimaryIdNumber")) {
						accountPersonsInfo.put("sIdentificationDocNumber", newValue);
					} else if (feildValue.equals("tIssueDateAd")) {
						accountPersonsInfo.put("sIdentificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pIssueAuthority")) {
						accountPersonsInfo.put("pIssueAuthority", newValue);
					} else if (feildValue.equals("tIssueAuthority")) {
						accountPersonsInfo.put("tIssueAuthority", newValue);
					} else if (feildValue.equals("currentHouseNumber")) {
						accountPersonsInfo.put("taddress1", newValue);
					} else if (feildValue.equals("currentTole")) {
						accountPersonsInfo.put("taddress2", newValue);
					} else if (feildValue.equals("currentWard")) {
						accountPersonsInfo.put("taddress3", newValue);
					} else if (feildValue.equals("currentDistrict")) {
						accountPersonsInfo.put("taddress4", newValue);
					} else if (feildValue.equals("currentmnVdcCity")) {
						accountPersonsInfo.put("tcityName", newValue);
					} else if (feildValue.equals("currentProvince")) {
						accountPersonsInfo.put("tstate", newValue);
					} else if (feildValue.equals("currentCountryCode")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentCountry")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentGooglePlusCode")) {
						accountPersonsInfo.put("gplusCode", newValue);
					} else if (feildValue.equals("currentzipCode")) {
						accountPersonsInfo.put("zipcode", newValue);
					} else if (feildValue.equals("parmanentHouseNumber")) {
						accountPersonsInfo.put("paddress1", newValue);
					} else if (feildValue.equals("parmanentTole")) {
						accountPersonsInfo.put("paddress2", newValue);
					} else if (feildValue.equals("parmanentWard")) {
						accountPersonsInfo.put("paddress3", newValue);
					} else if (feildValue.equals("parmanentDistrict")) {
						accountPersonsInfo.put("paddress4", newValue);
					} else if (feildValue.equals("parmanentmnVdcCity")) {
						accountPersonsInfo.put("pcityName", newValue);
					} else if (feildValue.equals("parmanentProvince")) {
						accountPersonsInfo.put("pstate", newValue);
					} else if (feildValue.equals("parmanentCountryCode")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentCountry")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentGooglePlusCode")) {
						accountPersonsInfo.put("pgPlusCode", newValue);
					} else if (feildValue.equals("parmanentzipCode")) {
						accountPersonsInfo.put("pzipcode", newValue);
					} else if (feildValue.equals("tIssuseCountry")) {
						accountPersonsInfo.put("tIssuseCountry", newValue);
					} else if (feildValue.equals("tExpiryDateAd")) {
						accountPersonsInfo.put("tExpiryDateAd", newValue);
					}
				} else if (screenName.contains("CDD/Signatories")) {
					accountPersonsInfo.put("cbsrole", "Signatory");

					if (feildValue.equals("fullName")) {
						String name[] = fullNameSplit(newValue);
						try{accountPersonsInfo.put("firstName", name[0]);}catch(Exception e) {}
						try{accountPersonsInfo.put("middleName", name[1]);}catch(Exception e) {}
						try{accountPersonsInfo.put("lastName", name[2]);}catch(Exception e) {}
					} else if (feildValue.equals("relationship")) {
						accountPersonsInfo.put("cbsAccountPersonRoleType", newValue);
					} else if (feildValue.equals("contactNumber")) {
						accountPersonsInfo.put("contactNumber", newValue);
					} else if (feildValue.equals("dateOfBirthAd")) {
						accountPersonsInfo.put("dob", newValue);
					} else if (feildValue.equals("pPrimaryIdType")) {
						accountPersonsInfo.put("identificationDocType", newValue);
					} else if (feildValue.equals("pPrimaryIdNumber")) {
						accountPersonsInfo.put("identificationDocNumber", newValue);
					} else if (feildValue.equals("pIssuseCountry")) {
						accountPersonsInfo.put("identificationDocIssueCountry", newValue);
					} else if (feildValue.equals("pIssueDateAd")) {
						accountPersonsInfo.put("identificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pExpiryDateAd")) {
						accountPersonsInfo.put("identificationDocExpiredDate", newValue);
					} else if (feildValue.equals("tPrimaryIdType")) {
						accountPersonsInfo.put("sIdentificationDocType", newValue);
					} else if (feildValue.equals("tPrimaryIdNumber")) {
						accountPersonsInfo.put("sIdentificationDocNumber", newValue);
					} else if (feildValue.equals("tIssueDateAd")) {
						accountPersonsInfo.put("sIdentificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pIssueAuthority")) {
						accountPersonsInfo.put("pIssueAuthority", newValue);
					} else if (feildValue.equals("tIssueAuthority")) {
						accountPersonsInfo.put("tIssueAuthority", newValue);
					} else if (feildValue.equals("currentHouseNumber")) {
						accountPersonsInfo.put("taddress1", newValue);
					} else if (feildValue.equals("currentTole")) {
						accountPersonsInfo.put("taddress2", newValue);
					} else if (feildValue.equals("currentWard")) {
						accountPersonsInfo.put("taddress3", newValue);
					} else if (feildValue.equals("currentDistrict")) {
						accountPersonsInfo.put("taddress4", newValue);
					} else if (feildValue.equals("currentmnVdcCity")) {
						accountPersonsInfo.put("tcityName", newValue);
					} else if (feildValue.equals("currentProvince")) {
						accountPersonsInfo.put("tstate", newValue);
					} else if (feildValue.equals("currentCountryCode")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentCountry")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentGooglePlusCode")) {
						accountPersonsInfo.put("gplusCode", newValue);
					} else if (feildValue.equals("currentzipCode")) {
						accountPersonsInfo.put("zipcode", newValue);
					} else if (feildValue.equals("parmanentHouseNumber")) {
						accountPersonsInfo.put("paddress1", newValue);
					} else if (feildValue.equals("parmanentTole")) {
						accountPersonsInfo.put("paddress2", newValue);
					} else if (feildValue.equals("parmanentWard")) {
						accountPersonsInfo.put("paddress3", newValue);
					} else if (feildValue.equals("parmanentDistrict")) {
						accountPersonsInfo.put("paddress4", newValue);
					} else if (feildValue.equals("parmanentmnVdcCity")) {
						accountPersonsInfo.put("pcityName", newValue);
					} else if (feildValue.equals("parmanentProvince")) {
						accountPersonsInfo.put("pstate", newValue);
					} else if (feildValue.equals("parmanentCountryCode")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentCountry")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentGooglePlusCode")) {
						accountPersonsInfo.put("pgPlusCode", newValue);
					} else if (feildValue.equals("parmanentzipCode")) {
						accountPersonsInfo.put("pzipcode", newValue);
					}else if (feildValue.equals("tIssuseCountry")) {
						accountPersonsInfo.put("tIssuseCountry", newValue);
					}else if (feildValue.equals("tExpiryDateAd")) {
						accountPersonsInfo.put("tExpiryDateAd", newValue);
					}
				} else if (screenName.contains("CDD/Nominee")) {
					accountPersonsInfo.put("cbsrole", "Nominee");

					if (feildValue.equals("fullName")) {
						String name[] = fullNameSplit(newValue);
						try{accountPersonsInfo.put("firstName", name[0]);}catch(Exception e) {}
						try{accountPersonsInfo.put("middleName", name[1]);}catch(Exception e) {}
						try{accountPersonsInfo.put("lastName", name[2]);}catch(Exception e) {}
					} else if (feildValue.equals("relationship")) {
						accountPersonsInfo.put("cbsAccountPersonRoleType", newValue);
					} else if (feildValue.equals("contactNumber")) {
						accountPersonsInfo.put("contactNumber", newValue);
					} else if (feildValue.equals("dateOfBirthAd")) {
						accountPersonsInfo.put("dob", newValue);
					} else if (feildValue.equals("pPrimaryIdType")) {
						accountPersonsInfo.put("identificationDocType", newValue);
					} else if (feildValue.equals("pPrimaryIdNumber")) {
						accountPersonsInfo.put("identificationDocNumber", newValue);
					} else if (feildValue.equals("pIssuseCountry")) {
						accountPersonsInfo.put("identificationDocIssueCountry", newValue);
					} else if (feildValue.equals("pIssueDateAd")) {
						accountPersonsInfo.put("identificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pExpiryDateAd")) {
						accountPersonsInfo.put("identificationDocExpiredDate", newValue);
					} else if (feildValue.equals("tPrimaryIdType")) {
						accountPersonsInfo.put("sIdentificationDocType", newValue);
					} else if (feildValue.equals("tPrimaryIdNumber")) {
						accountPersonsInfo.put("sIdentificationDocNumber", newValue);
					} else if (feildValue.equals("tIssueDateAd")) {
						accountPersonsInfo.put("sIdentificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pIssueAuthority")) {
						accountPersonsInfo.put("pIssueAuthority", newValue);
					} else if (feildValue.equals("tIssueAuthority")) {
						accountPersonsInfo.put("tIssueAuthority", newValue);
					} else if (feildValue.equals("currentHouseNumber")) {
						accountPersonsInfo.put("taddress1", newValue);
					} else if (feildValue.equals("currentTole")) {
						accountPersonsInfo.put("taddress2", newValue);
					} else if (feildValue.equals("currentWard")) {
						accountPersonsInfo.put("taddress3", newValue);
					} else if (feildValue.equals("currentDistrict")) {
						accountPersonsInfo.put("taddress4", newValue);
					} else if (feildValue.equals("currentmnVdcCity")) {
						accountPersonsInfo.put("tcityName", newValue);
					} else if (feildValue.equals("currentProvince")) {
						accountPersonsInfo.put("tstate", newValue);
					} else if (feildValue.equals("currentCountryCode")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentCountry")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentGooglePlusCode")) {
						accountPersonsInfo.put("gplusCode", newValue);
					} else if (feildValue.equals("currentzipCode")) {
						accountPersonsInfo.put("zipcode", newValue);
					} else if (feildValue.equals("parmanentHouseNumber")) {
						accountPersonsInfo.put("paddress1", newValue);
					} else if (feildValue.equals("parmanentTole")) {
						accountPersonsInfo.put("paddress2", newValue);
					} else if (feildValue.equals("parmanentWard")) {
						accountPersonsInfo.put("paddress3", newValue);
					} else if (feildValue.equals("parmanentDistrict")) {
						accountPersonsInfo.put("paddress4", newValue);
					} else if (feildValue.equals("parmanentmnVdcCity")) {
						accountPersonsInfo.put("pcityName", newValue);
					} else if (feildValue.equals("parmanentProvince")) {
						accountPersonsInfo.put("pstate", newValue);
					} else if (feildValue.equals("parmanentCountryCode")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentCountry")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentGooglePlusCode")) {
						accountPersonsInfo.put("pgPlusCode", newValue);
					} else if (feildValue.equals("parmanentzipCode")) {
						accountPersonsInfo.put("pzipcode", newValue);
					}else if (feildValue.equals("tIssuseCountry")) {
						accountPersonsInfo.put("tIssuseCountry", newValue);
					}else if (feildValue.equals("tExpiryDateAd")) {
						accountPersonsInfo.put("tExpiryDateAd", newValue);
					}
				} else if (screenName.contains("CDD/Beneficiary") || screenName.contains("CDD/Beneficial Owner")) {
					accountPersonsInfo.put("cbsrole", "Beneficiary");
					if (feildValue.equals("fullName")) {
						String name[] = fullNameSplit(newValue);
						try{accountPersonsInfo.put("firstName", name[0]);}catch(Exception e) {}
						try{accountPersonsInfo.put("middleName", name[1]);}catch(Exception e) {}
						try{accountPersonsInfo.put("lastName", name[2]);}catch(Exception e) {}
					} else if (feildValue.equals("relationship")) {
						accountPersonsInfo.put("cbsAccountPersonRoleType", newValue);
					} else if (feildValue.equals("contactNumber")) {
						accountPersonsInfo.put("contactNumber", newValue);
					} else if (feildValue.equals("dateOfBirthAd")) {
						accountPersonsInfo.put("dob", newValue);
					} else if (feildValue.equals("pPrimaryIdType")) {
						accountPersonsInfo.put("identificationDocType", newValue);
					} else if (feildValue.equals("pPrimaryIdNumber")) {
						accountPersonsInfo.put("identificationDocNumber", newValue);
					} else if (feildValue.equals("pIssuseCountry")) {
						accountPersonsInfo.put("identificationDocIssueCountry", newValue);
					} else if (feildValue.equals("pIssueDateAd")) {
						accountPersonsInfo.put("identificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pExpiryDateAd")) {
						accountPersonsInfo.put("identificationDocExpiredDate", newValue);
					} else if (feildValue.equals("tPrimaryIdType")) {
						accountPersonsInfo.put("sIdentificationDocType", newValue);
					} else if (feildValue.equals("tPrimaryIdNumber")) {
						accountPersonsInfo.put("sIdentificationDocNumber", newValue);
					} else if (feildValue.equals("tIssueDateAd")) {
						accountPersonsInfo.put("sIdentificationDocIssuedDate", newValue);
					} else if (feildValue.equals("pIssueAuthority")) {
						accountPersonsInfo.put("pIssueAuthority", newValue);
					} else if (feildValue.equals("tIssueAuthority")) {
						accountPersonsInfo.put("tIssueAuthority", newValue);
					} else if (feildValue.equals("currentHouseNumber")) {
						accountPersonsInfo.put("taddress1", newValue);
					} else if (feildValue.equals("currentTole")) {
						accountPersonsInfo.put("taddress2", newValue);
					} else if (feildValue.equals("currentWard")) {
						accountPersonsInfo.put("taddress3", newValue);
					} else if (feildValue.equals("currentDistrict")) {
						accountPersonsInfo.put("taddress4", newValue);
					} else if (feildValue.equals("currentmnVdcCity")) {
						accountPersonsInfo.put("tcityName", newValue);
					} else if (feildValue.equals("currentProvince")) {
						accountPersonsInfo.put("tstate", newValue);
					} else if (feildValue.equals("currentCountryCode")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentCountry")) {
						accountPersonsInfo.put("tcountry", newValue);
					} else if (feildValue.equals("currentGooglePlusCode")) {
						accountPersonsInfo.put("gplusCode", newValue);
					} else if (feildValue.equals("currentzipCode")) {
						accountPersonsInfo.put("zipcode", newValue);
					} else if (feildValue.equals("parmanentHouseNumber")) {
						accountPersonsInfo.put("paddress1", newValue);
					} else if (feildValue.equals("parmanentTole")) {
						accountPersonsInfo.put("paddress2", newValue);
					} else if (feildValue.equals("parmanentWard")) {
						accountPersonsInfo.put("paddress3", newValue);
					} else if (feildValue.equals("parmanentDistrict")) {
						accountPersonsInfo.put("paddress4", newValue);
					} else if (feildValue.equals("parmanentmnVdcCity")) {
						accountPersonsInfo.put("pcityName", newValue);
					} else if (feildValue.equals("parmanentProvince")) {
						accountPersonsInfo.put("pstate", newValue);
					} else if (feildValue.equals("parmanentCountryCode")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentCountry")) {
						accountPersonsInfo.put("pcountry", newValue);
					} else if (feildValue.equals("parmanentGooglePlusCode")) {
						accountPersonsInfo.put("pgPlusCode", newValue);
					} else if (feildValue.equals("parmanentzipCode")) {
						accountPersonsInfo.put("pzipcode", newValue);
					}else if (feildValue.equals("tIssuseCountry")) {
						accountPersonsInfo.put("tIssuseCountry", newValue);
					}else if (feildValue.equals("tExpiryDateAd")) {
						accountPersonsInfo.put("tExpiryDateAd", newValue);
					}
				} else if (screenName.contains("CDD/Account")) {
					if (feildValue.equals("estimatedMonthlyIncome")) {
						customerProfile.put("monthlyIncome", newValue);
					} else if (feildValue.equals("estimatedAnnualIncome")) {
						customerProfile.put("income", newValue);
					} else if (feildValue.equals("estimatedAnnualTurnover")) {
						customerProfile.put("turnover", newValue);
					} else if (feildValue.equals("accountCurrency")) {
						customerProfile.put("currencyType", newValue);
					} else if (feildValue.equals("accountOpeningDate")) {
						customerProfile.put("accountOpenDate", newValue);
					} else if (feildValue.equals("accountAge")) {
						customerProfile.put("accountAge", newValue);
					} else if (feildValue.equals("accountBranch")) {
						customerProfile.put("branchName", newValue);
					} else if (feildValue.equals("accountType")) {
						customerProfile.put("accountType", newValue);
					} else if (feildValue.equals("accountName")) {
						customerProfile.put("accountName", newValue);
					} else if (feildValue.equals("accountNumber")) {
						customerProfile.put("accountId", newValue);
					} else if (feildValue.equals("purposeOfAccount")) {
						customerProfile.put("purpose", newValue);
					} else if (feildValue.equals("upperLimitOnLoanAccounts")) {
						customerProfile.put("overdraftLimit", newValue);
					} else if (feildValue.equals("accountStatusType")) {
						customerProfile.put("accountStatusCode", newValue);
					}					
					customerProfile.put("accId", accId);
					
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		try {
			saveToTable(customerProfile, accountPersonsInfo, address, identification, custId, accId,
					selectedAccountData, selectedIdentictionNumber,screenName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Transactional
	private void saveToTable(Map<String, Object> customerProfile, Map<String, Object> accountPersonsInfo,
			Map<String, Object> address, Map<String, Object> identification, String custId, String accId,
			String selectedAccountData, String selectedIdentictionNumber, String screenName) {
		Address addressRepoData = null;
		CustomerProfile custPro = null;
		List<CustomerProfile> multiCustProfile = new ArrayList<>();
		List<CustomerProfile> multiCustProfile2 = new ArrayList<>();

		CustomerIdInfo customerIdInfo = new CustomerIdInfo();
		try {
			if (address != null && !address.isEmpty()) {
				addressRepoData = addressRepo.findByAddressId(custId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		try {
			if (customerProfile != null && !customerProfile.isEmpty()) {
				try {
					if (customerProfile.get("accId") !=null) {
						custPro = custRepository.findByCustomerIdAndAccountId(custId, accId);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}	
				if(custPro == null) {
					multiCustProfile = custRepository.findByCustomerId(custId);
					for (CustomerProfile customerProfile2 : multiCustProfile) {
						multiCustProfile2.add(setCPPatchData(customerProfile, customerProfile2));
					}

					try {
						custRepository.saveAll(multiCustProfile2);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}else {
					custPro=setCPPatchData(customerProfile, custPro);
					try {
						custRepository.save(custPro);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (identification != null && !identification.isEmpty()) {
				Optional<CustomerIdInfo> customerIdInfos = null;
				if (selectedIdentictionNumber != null) {
					customerIdInfos = customerIdInfoRepo.findById(Long.parseLong(selectedIdentictionNumber));
					if (customerIdInfos.isPresent()) {
						customerIdInfo = customerIdInfos.get();
					}
				} else {
					BigInteger id = customerIdInfoRepo.latestCount();
					id = id.add(BigInteger.ONE);
					customerIdInfo.setId(id.longValue());
					customerIdInfo.setCustomerId(custId);
					}
				
				if (identification.get("identificationDocType") != null
						&& !identification.get("identificationDocType").toString().isEmpty()) {
					customerIdInfo.setIdType(identification.get("identificationDocType").toString());
				}
				if (identification.get("identificationDocNumber") != null
						&& !identification.get("identificationDocNumber").toString().isEmpty()) {
					customerIdInfo.setIdNumber(identification.get("identificationDocNumber").toString());
				}
				if (identification.get("identificationDocIssueCountry") != null
						&& !identification.get("identificationDocIssueCountry").toString().isEmpty()) {
					customerIdInfo.setIdIssueCountry(identification.get("identificationDocIssueCountry").toString());
				}
				if (identification.get("identificationDocIssuedDate") != null
						&& !identification.get("identificationDocIssuedDate").toString().isEmpty()) {
					customerIdInfo.setIdIssueDate(dateFormat(identification.get("identificationDocIssuedDate").toString()));
				}
				if (identification.get("idenificationDocIssuedBy") != null
						&& !identification.get("idenificationDocIssuedBy").toString().isEmpty()) {
					customerIdInfo.setIdIssuedBy(identification.get("idenificationDocIssuedBy").toString());
				}
				if (identification.get("identificationDocExpiredDate") != null
						&& !identification.get("identificationDocExpiredDate").toString().isEmpty()) {
					customerIdInfo
							.setIdExpiryDate(dateFormat(identification.get("identificationDocExpiredDate").toString()));
				}
				if (customerIdInfo != null) {
					try {
						customerIdInfoRepo.save(customerIdInfo);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (screenName.contains("CDD/Beneficiary") || screenName.contains("CDD/Beneficial Owner") ||
					screenName.contains("CDD/Directors") ||screenName.contains("CDD/Nominee") ||
					screenName.contains("CDD/Signatories")) {				
				Optional<AccountPersonsInfo> accBaseds = java.util.Optional.empty();
				if (selectedAccountData != null && !selectedAccountData.isEmpty()) {
					accBaseds=accountPersonsInfoRepo.findById(selectedAccountData);
				}
					AccountPersonsInfo accBased = new AccountPersonsInfo();
					if (accBaseds.isPresent()) {
						accBased = accBaseds.get();
					}else {
						accBased.setId(accId+"-"+custId+"-"+new Date().getTime());
						if (accountPersonsInfo.get("cbsrole") != null
								&& !accountPersonsInfo.get("cbsrole").toString().isEmpty()) {
							accBased.setCbsPartyRoleType(accountPersonsInfo.get("cbsrole").toString());
						}
					}
					if (accountPersonsInfo.get("contactNumber") != null
							&& !accountPersonsInfo.get("contactNumber").toString().isEmpty()) {
						accBased.setMobileNumber(accountPersonsInfo.get("contactNumber").toString());
					} 
					if (accountPersonsInfo.get("firstName") != null
							&& !accountPersonsInfo.get("firstName").toString().isEmpty()) {
						accBased.setFirstName(accountPersonsInfo.get("firstName").toString());
					} 
					if (accountPersonsInfo.get("lastName") != null
							&& !accountPersonsInfo.get("lastName").toString().isEmpty()) {
						accBased.setLastName(accountPersonsInfo.get("lastName").toString());
					} 
					if (accountPersonsInfo.get("middleName") != null
							&& !accountPersonsInfo.get("middleName").toString().isEmpty()) {
						accBased.setMiddleName(accountPersonsInfo.get("middleName").toString());
					} 
					if (accountPersonsInfo.get("dob") != null && !accountPersonsInfo.get("dob").toString().isEmpty()) {
						accBased.setDateOfBirth(dateFormat(accountPersonsInfo.get("dob").toString()));
					} 
					if (accountPersonsInfo.get("paddress1") != null
							&& !accountPersonsInfo.get("paddress1").toString().isEmpty()) {
						accBased.setPaddress1(accountPersonsInfo.get("paddress1").toString());
					} 
					if (accountPersonsInfo.get("paddress2") != null
							&& !accountPersonsInfo.get("paddress2").toString().isEmpty()) {
						accBased.setPaddress2(accountPersonsInfo.get("paddress2").toString());
					}
					if (accountPersonsInfo.get("paddress3") != null
							&& !accountPersonsInfo.get("paddress3").toString().isEmpty()) {
						accBased.setPaddress3(accountPersonsInfo.get("paddress3").toString());
					}
					if (accountPersonsInfo.get("paddress4") != null
							&& !accountPersonsInfo.get("paddress4").toString().isEmpty()) {
						accBased.setPaddress4(accountPersonsInfo.get("paddress4").toString());
					} 
					if (accountPersonsInfo.get("pcityName") != null
							&& !accountPersonsInfo.get("pcityName").toString().isEmpty()) {
						accBased.setPcityName(accountPersonsInfo.get("pcityName").toString());
					} 
					if (accountPersonsInfo.get("pstate") != null
							&& !accountPersonsInfo.get("pstate").toString().isEmpty()) {
						accBased.setPState(accountPersonsInfo.get("pstate").toString());
					} 
					if (accountPersonsInfo.get("pgPlusCode") != null
							&& !accountPersonsInfo.get("pgPlusCode").toString().isEmpty()) {
						accBased.setPgPlusCode(accountPersonsInfo.get("pgPlusCode").toString());
					} 
					if (accountPersonsInfo.get("pCountry") != null
							&& !accountPersonsInfo.get("pCountry").toString().isEmpty()) {
						accBased.setPCountry(accountPersonsInfo.get("pCountry").toString());
					} 
					if (accountPersonsInfo.get("taddress1") != null
							&& !accountPersonsInfo.get("taddress1").toString().isEmpty()) {
						accBased.setTaddress1(accountPersonsInfo.get("taddress1").toString());
					} 
					if (accountPersonsInfo.get("taddress2") != null
							&& !accountPersonsInfo.get("taddress2").toString().isEmpty()) {
						accBased.setTaddress2(accountPersonsInfo.get("taddress2").toString());
					} 
					if (accountPersonsInfo.get("taddress3") != null
							&& !accountPersonsInfo.get("taddress3").toString().isEmpty()) {
						accBased.setTaddress3(accountPersonsInfo.get("taddress3").toString());
					}
					if (accountPersonsInfo.get("taddress4") != null
							&& !accountPersonsInfo.get("taddress4").toString().isEmpty()) {
						accBased.setTaddress4(accountPersonsInfo.get("taddress4").toString());
					} 
					if (accountPersonsInfo.get("tcityName") != null
							&& !accountPersonsInfo.get("tcityName").toString().isEmpty()) {
						accBased.setTcityName(accountPersonsInfo.get("tcityName").toString());
					}
					if (accountPersonsInfo.get("tstate") != null
							&& !accountPersonsInfo.get("tstate").toString().isEmpty()) {
						accBased.setTstate(accountPersonsInfo.get("tstate").toString());
					} 
					if (accountPersonsInfo.get("gplusCode") != null
							&& !accountPersonsInfo.get("gplusCode").toString().isEmpty()) {
						accBased.setGPlusCode(accountPersonsInfo.get("gplusCode").toString());
					} 
					if (accountPersonsInfo.get("tcountry") != null
							&& !accountPersonsInfo.get("tcountry").toString().isEmpty()) {
						accBased.setTcountry(accountPersonsInfo.get("tcountry").toString());
					} 
					if (accountPersonsInfo.get("identificationDocType") != null
							&& !accountPersonsInfo.get("identificationDocType").toString().isEmpty()) {
						accBased.setIdentificationDocType(accountPersonsInfo.get("identificationDocType").toString());
					} 
					if (accountPersonsInfo.get("identificationDocNumber") != null
							&& !accountPersonsInfo.get("identificationDocNumber").toString().isEmpty()) {
						accBased.setIdentificationDocNumber(accountPersonsInfo.get("identificationDocNumber").toString());
					} 
					if (accountPersonsInfo.get("identificationDocIssuedDate") != null
							&& !accountPersonsInfo.get("identificationDocIssuedDate").toString().isEmpty()) {
						accBased.setIdentificationDocIssuedDate(
								dateFormat(accountPersonsInfo.get("identificationDocIssuedDate").toString()));
					} 					
					if (accountPersonsInfo.get("sIdentificationDocType") != null
							&& !accountPersonsInfo.get("sIdentificationDocType").toString().isEmpty()) {
						accBased.setSIdentificationDocType(accountPersonsInfo.get("sIdentificationDocType").toString());
					} 
					if (accountPersonsInfo.get("sIdentificationDocNumber") != null
							&& !accountPersonsInfo.get("sIdentificationDocNumber").toString().isEmpty()) {
						accBased.setSIdentificationDocNumber(accountPersonsInfo.get("sIdentificationDocNumber").toString());
					} 
					if (accountPersonsInfo.get("sIdentificationDocIssuedDate") != null
							&& !accountPersonsInfo.get("sIdentificationDocIssuedDate").toString().isEmpty()) {
						accBased.setSIdentificationDocIssuedDate(
								dateFormat(accountPersonsInfo.get("sIdentificationDocIssuedDate").toString()));
					}
					if (accountPersonsInfo.get("pIssueAuthority") != null
							&& !accountPersonsInfo.get("pIssueAuthority").toString().isEmpty()) {
						accBased.setIdenificationDocIssuedBy(accountPersonsInfo.get("pIssueAuthority").toString());
					} 
					if (accountPersonsInfo.get("tIssueAuthority") != null
							&& !accountPersonsInfo.get("tIssueAuthority").toString().isEmpty()) {
						accBased.setSIdenificationDocIssuedBy(accountPersonsInfo.get("tIssueAuthority").toString());
					} 
					if (accountPersonsInfo.get("tIssuseCountry") != null
							&& !accountPersonsInfo.get("tIssuseCountry").toString().isEmpty()) {
						accBased.setSIdentificationDocIssueCountry(
								accountPersonsInfo.get("tIssuseCountry").toString());
					} 
					if (accountPersonsInfo.get("identificationDocExpiredDate") != null
							&& !accountPersonsInfo.get("identificationDocExpiredDate").toString().isEmpty()) {
						accBased.setIdentificationDocExpiryDate(
								dateFormat(accountPersonsInfo.get("identificationDocExpiredDate").toString()));
					} 
					if (accountPersonsInfo.get("tExpiryDateAd") != null
							&& !accountPersonsInfo.get("tExpiryDateAd").toString().isEmpty()) {
						accBased.setSIdentificationDocExpiryDate(
								dateFormat(accountPersonsInfo.get("tExpiryDateAd").toString()));
					} 
					if (accountPersonsInfo.get("mobileNumber") != null
							&& !accountPersonsInfo.get("mobileNumber").toString().isEmpty()) {
						accBased.setMobileNumber(accountPersonsInfo.get("mobileNumber").toString());
					} 
					if (accountPersonsInfo.get("emailId") != null
							&& !accountPersonsInfo.get("emailId").toString().isEmpty()) {
						accBased.setEmailId(accountPersonsInfo.get("emailId").toString());
					} 
					if (accountPersonsInfo.get("cbsAccountPersonRoleType") != null
							&& !accountPersonsInfo.get("cbsAccountPersonRoleType").toString().isEmpty()) {
						accBased.setCbsAccountPersonRoleType(accountPersonsInfo.get("cbsAccountPersonRoleType").toString());
					}
					if (accountPersonsInfo.get("pcountry") != null
							&& !accountPersonsInfo.get("pcountry").toString().isEmpty()) {
						accBased.setPCountry(accountPersonsInfo.get("pcountry").toString());
					}
					if (accountPersonsInfo.get("identificationDocIssueCountry") != null
							&& !accountPersonsInfo.get("identificationDocIssueCountry").toString().isEmpty()) {
						accBased.setIdentificationDocIssueCountry(accountPersonsInfo.get("identificationDocIssueCountry").toString());
					}
					if (accountPersonsInfo.get("pzipcode") != null
							&& !accountPersonsInfo.get("pzipcode").toString().isEmpty()) {
						accBased.setPZipcode(accountPersonsInfo.get("pzipcode").toString());
					}
					if (accountPersonsInfo.get("zipcode") != null
							&& !accountPersonsInfo.get("zipcode").toString().isEmpty()) {
						accBased.setTzipcode(accountPersonsInfo.get("zipcode").toString());
					}
					
					accBased.setAccountId(accId);
					accBased.setCustomerId(custId);
	
					if (accBased != null) {
						accountPersonsInfoRepo.save(accBased);
					}
				}
			
		} catch (Exception e) {
			e.printStackTrace();;
		}
		try {
			if(addressRepoData ==null) {
				addressRepoData=new Address();
			}
			if (address != null && !address.isEmpty()) {
				if (address.get("paddress1") != null && !address.get("paddress1").toString().isEmpty()) {
					addressRepoData.setPAddress1(address.get("paddress1").toString());
				}
				if (address.get("paddress2") != null && !address.get("paddress2").toString().isEmpty()) {
					addressRepoData.setPAddress2(address.get("paddress2").toString());
				}
				if (address.get("paddress3") != null && !address.get("paddress3").toString().isEmpty()) {
					addressRepoData.setPAddress3(address.get("paddress3").toString());
				}
				if (address.get("paddress4") != null && !address.get("paddress4").toString().isEmpty()) {
					addressRepoData.setPAddress4(address.get("paddress4").toString());
				}
				if (address.get("pcityName") != null && !address.get("pcityName").toString().isEmpty()) {
					addressRepoData.setPCityName(address.get("pcityName").toString());
				}
				if (address.get("pstate") != null && !address.get("pstate").toString().isEmpty()) {
					addressRepoData.setPState(address.get("pstate").toString());
				}
				if (address.get("zipcode") != null && !address.get("zipcode").toString().isEmpty()) {
					addressRepoData.setZipcode(address.get("zipcode").toString());
				}
				if (address.get("pgPlusCode") != null && !address.get("pgPlusCode").toString().isEmpty()) {
					addressRepoData.setPgPlusCode(address.get("pgPlusCode").toString());
				}
				if (address.get("pcountry") != null && !address.get("pcountry").toString().isEmpty()) {
					addressRepoData.setPCountry(address.get("pcountry").toString());
				}
				if (address.get("taddress1") != null && !address.get("taddress1").toString().isEmpty()) {
					addressRepoData.setAddress1(address.get("taddress1").toString());
				}
				if (address.get("taddress2") != null && !address.get("taddress2").toString().isEmpty()) {
					addressRepoData.setAddress2(address.get("taddress2").toString());
				}
				if (address.get("taddress3") != null && !address.get("taddress3").toString().isEmpty()) {
					addressRepoData.setAddress3(address.get("taddress3").toString());
				}
				if (address.get("taddress4") != null && !address.get("taddress4").toString().isEmpty()) {
					addressRepoData.setAddress4(address.get("taddress4").toString());
				}
				if (address.get("cityName") != null && !address.get("cityName").toString().isEmpty()) {
					addressRepoData.setCityName(address.get("cityName").toString());
				}
				if (address.get("state") != null && !address.get("state").toString().isEmpty()) {
					addressRepoData.setState(address.get("state").toString());
				}
				if (address.get("gplusCode") != null && !address.get("gplusCode").toString().isEmpty()) {
					addressRepoData.setGPlusCode(address.get("gplusCode").toString());
				}
				if (address.get("country") != null && !address.get("country").toString().isEmpty()) {
					addressRepoData.setCountry(address.get("country").toString());
				}
				if (address.get("pzipcode") != null && !address.get("pzipcode").toString().isEmpty()) {
					addressRepoData.setPZipcode(address.get("pzipcode").toString());
				}
				if (address.get("empaddress1") != null && !address.get("empaddress1").toString().isEmpty()) {
					addressRepoData.setEmpAddress1(address.get("empaddress1").toString());
				}
				if (address.get("empaddress2") != null && !address.get("empaddress2").toString().isEmpty()) {
					addressRepoData.setEmpAddress2(address.get("empaddress2").toString());
				}
				if (address.get("empaddress3") != null && !address.get("empaddress3").toString().isEmpty()) {
					addressRepoData.setEmpAddress3(address.get("empaddress3").toString());
				}
				if (address.get("empaddress4") != null && !address.get("empaddress4").toString().isEmpty()) {
					addressRepoData.setEmpAddress4(address.get("empaddress4").toString());
				}
				if (address.get("empcityname") != null && !address.get("empcityname").toString().isEmpty()) {
					addressRepoData.setEmpCityName(address.get("empcityname").toString());
				}
				if (address.get("empstate") != null && !address.get("empstate").toString().isEmpty()) {
					addressRepoData.setEmpState(address.get("empstate").toString());
				}
				if (address.get("empcountry") != null && !address.get("empcountry").toString().isEmpty()) {
					addressRepoData.setEmpCountry(address.get("empcountry").toString());
				}
				if (address.get("empcountry") != null && !address.get("empcountry").toString().isEmpty()) {
					addressRepoData.setEmpCountry(address.get("empcountry").toString());
				}
				if (address.get("empgpcode") != null && !address.get("empgpcode").toString().isEmpty()) {
					addressRepoData.setEmpgPlusCode(address.get("empgpcode").toString());
				}
				if (address.get("empzipcode") != null && !address.get("empzipcode").toString().isEmpty()) {
					addressRepoData.setEmpZipcode(address.get("empzipcode").toString());
				}
				
				addressRepoData.setAddressId(custId);

				if (addressRepoData != null) {
					try {
						addressRepo.save(addressRepoData);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Map<String,Object> getCRRData(String crr,Integer startFrom,String dtInputFields) {
		return custRepositoryCustom.getCRRData(crr,startFrom,dtInputFields);
	}

	@Override
	public Map<String, Integer> getCDDataCount() {
		Map<String, Set<String>> ob = mappingKycColumnFields();
		Map<String, Integer> resultMap = new HashMap<>();
		resultMap = custRepositoryCustom.cddCountQuery(ob);
		return resultMap;

	}

	public Map<String, Set<String>> mappingKycColumnFields() {
		List<Map<String, Object>> ks = kycMasRepo.getKycMasterData();
		List<Map<String, Object>> updatedKs = new ArrayList<>();

		for (Map<String, Object> map : ks) {
			String fullyClassifiedName = (String) map.get("FULLY_CLASSIFIED_NAME");
			String[] parts = fullyClassifiedName.split("\\.(?=[^.]+$)");

			if (parts.length == 2) {
				String tableName = parts[0];
				Map<String, Object> updatedMap = new HashMap<>(map);
				updatedMap.put("FULLY_CLASSIFIED_NAME", tableName);

				updatedKs.add(updatedMap);
			} else {
				// No modification needed, add the map as-is
				updatedKs.add(map);
			}
		}
		Map<String, Set<String>> ob = getGroupedColumnNamesMap(updatedKs);
		return ob;
	}

	private Map<String, Set<String>> getGroupedColumnNamesMap(List<Map<String, Object>> map) {
		Map<String, Set<String>> returnData = new HashMap<>();
		Set<String> tableMapping = new HashSet<>();

		// Step 1: Identify duplicate values in FULLY_CLASSIFIED_NAME
		for (Map<String, Object> entry : map) {
			String fullyClassifiedName = entry.get("FULLY_CLASSIFIED_NAME").toString();
			tableMapping.add(fullyClassifiedName);
		}

		for (Iterator<String> it = tableMapping.iterator(); it.hasNext();) {
			String tableName = it.next();
			Set<String> fieldMapping = new HashSet<>();
			for (Map<String, Object> entr : map) {
				if (tableName.equalsIgnoreCase(entr.get("FULLY_CLASSIFIED_NAME").toString())) {
					fieldMapping.add(entr.get("FIELD_NAME").toString());
				}
			}
			returnData.put(tableName, fieldMapping);
		}

		return returnData;
	}

	@Override
	public Map<String, Object> getCustomerDetails(String custID) {
		Map<String, Object> res = new HashMap<>();
		try {
			res.put("accountDetails", custRepository.getAccountDetails(custID));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			res.put("sanctionScore", sanctionListSummaryRepo.getSanctionScoreForCustomerDetails(custID));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			res.put("leEnquiries", custRepository.getLeEnquiries(custID));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			res.put("fiuDMLIEnquiries", custRepository.getFIUDMLIEnquiries(custID));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			res.put("fiuDMLIFreezes", custRepository.getFIUDMLIFreezes(custID));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			res.put("adverseMedia", custRepository.getAdverseMedia(custID));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			res.put("customerOtherDetails", custRepository.findByCustomerId(custID).get(0));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			OverrideCrr overrideCrr = new OverrideCrr();
			overrideCrr = overrideCrrRepo.findFirstByCustomerIdOrderByOverrideDateDesc(custID);
			boolean isOverrideCrr = false;
			try {
				isOverrideCrr = overrideCrr != null && overrideCrr.getOverrideCrr() != null
						&& !overrideCrr.getOverrideCrr().isEmpty();
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (isOverrideCrr) {
				res.put("systemRating", overrideCrr.getOverrideCrr());
				res.put("manualRating", overrideCrr.getOverrideCrr());
			} else {
				CrrComputationInfo crrComputationInfo = crrComputationInfoRepo
						.findFirstByCustomerIdOrderByComputedDateDesc(custID);
				try {
					res.put("systemRating", crrComputationInfo.getCrrRating());
				} catch (Exception e) {
					res.put("systemRating", 0);
				}
				res.put("manualRating", null);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;

	}

	@Override
	public Map<String, Object> getCDDDataStatus(String startFrom, String dtInputFields) {
		Map<String, Set<String>> tableColumns = mappingKycColumnFields();
		Map<String, Object> nullFields = custRepositoryCustom.getCDDDataStatus(tableColumns, startFrom, dtInputFields);
		return nullFields;
	}

	private String[] fullNameSplit(String input) {
		String[] parts = null;

		try {
			parts = input.split(" ");
		} catch (Exception e) {
			// Handle the exception if the input cannot be split
			System.err.println("Error splitting the input: " + e.getMessage());
		}

		String firstName = null;
		String middleName = null;
		String lastName = null;

		if (parts != null) {
			if (parts.length >= 3) {
				firstName = parts[0];
				middleName = parts[1];
				lastName = parts[2];
			} else if (parts.length == 2) {
				firstName = parts[0];
				lastName = parts[1];
				middleName = "";
			} else if (parts.length == 1) {
				firstName = parts[0];
				middleName = "";
				lastName = "";
			}
		}

		return new String[] { firstName, middleName, lastName };
	}

	private Date dateFormat(String dateValue) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			Date date = dateFormat.parse(dateValue);
			return date;
		} catch (ParseException e) {
			return null;

		}
	}
	

	private String updateChildName(String childJson,String updatedData,String childs) {
	    try {
	        JSONObject json = new JSONObject(childJson);
	        JSONObject child = json.getJSONObject("child");
	        child.put(childs, updatedData);
	        return json.toString();
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	private CustomerProfile setCPPatchData(Map<String, Object> customerProfile, CustomerProfile custPro) {
		if (customerProfile.get("pep") != null && !customerProfile.get("pep").toString().isEmpty()) {
			custPro.setPep(customerProfile.get("pep").toString());
		}
		if (customerProfile.get("fatca") != null && !customerProfile.get("fatca").toString().isEmpty()) {
			custPro.setFatca(customerProfile.get("fatca").toString());
		}
		if (customerProfile.get("fatherName") != null && !customerProfile.get("fatherName").toString().isEmpty()) {
			custPro.setFatherName(customerProfile.get("fatherName").toString());
		}
		if (customerProfile.get("motherName") != null && !customerProfile.get("motherName").toString().isEmpty()) {
			custPro.setMotherName(customerProfile.get("motherName").toString());
		}
		if (customerProfile.get("spouseName") != null && !customerProfile.get("spouseName").toString().isEmpty()) {
			custPro.setSpouseName(customerProfile.get("spouseName").toString());
		}
		if (customerProfile.get("grandFatherName") != null
				&& !customerProfile.get("grandFatherName").toString().isEmpty()) {
			custPro.setGrandFatherName(customerProfile.get("grandFatherName").toString());
		}
		if (customerProfile.get("grandMotherName") != null
				&& !customerProfile.get("grandMotherName").toString().isEmpty()) {
			custPro.setGrandMotherName(customerProfile.get("grandMotherName").toString());
		}
		if(custPro.getChildName() == null) {
			custPro.setChildName("{\"child\": {}}");
		}
		if (customerProfile.get("sonFullName") != null && !customerProfile.get("sonFullName").toString().isEmpty()) {
			if(custPro.getChildName()!=null && !customerProfile.get("sonFullName").toString().isEmpty()) {
				custPro.setChildName(updateChildName(custPro.getChildName(), customerProfile.get("sonFullName").toString(), "sonFullName"));
			}
		}
		if (customerProfile.get("sonFullName2") != null && !customerProfile.get("sonFullName2").toString().isEmpty()) {
			if(custPro.getChildName()!=null && !customerProfile.get("sonFullName2").toString().isEmpty()) {
				custPro.setChildName(updateChildName(custPro.getChildName(), customerProfile.get("sonFullName2").toString(), "sonFullName2"));
			}
		}
		if (customerProfile.get("daughterFullName") != null && !customerProfile.get("daughterFullName").toString().isEmpty()) {
			if(custPro.getChildName()!=null && !customerProfile.get("daughterFullName").toString().isEmpty()) {
				custPro.setChildName(updateChildName(custPro.getChildName(), customerProfile.get("daughterFullName").toString(), "daughterFullName"));
			}
		}
		if (customerProfile.get("daughterFullName2") != null && !customerProfile.get("daughterFullName2").toString().isEmpty()) {
			if(custPro.getChildName()!=null && !customerProfile.get("daughterFullName2").toString().isEmpty()) {
				custPro.setChildName(updateChildName(custPro.getChildName(), customerProfile.get("daughterFullName2").toString(), "daughterFullName2"));
			}
		}

		if (customerProfile.get("title") != null && !customerProfile.get("title").toString().isEmpty()) {
			custPro.setTitle(customerProfile.get("title").toString());
		}
		if (customerProfile.get("lastName") != null && !customerProfile.get("lastName").toString().isEmpty()) {
			custPro.setLastName(customerProfile.get("lastName").toString());
		}
		if (customerProfile.get("dateOfBirth") != null
				&& !customerProfile.get("dateOfBirth").toString().isEmpty()) {
			custPro.setDateOfBirth(dateFormat(customerProfile.get("dateOfBirth").toString()));
		}
		if (customerProfile.get("firstName") != null && !customerProfile.get("firstName").toString().isEmpty()) {
			custPro.setFirstName(customerProfile.get("firstName").toString());
		}
		if (customerProfile.get("middleName") != null && !customerProfile.get("middleName").toString().isEmpty()) {
			custPro.setMiddleName(customerProfile.get("middleName").toString());
		}
		if (customerProfile.get("nationality") != null
				&& !customerProfile.get("nationality").toString().isEmpty()) {
			custPro.setNationality(customerProfile.get("nationality").toString());
		}
		if (customerProfile.get("sex") != null && !customerProfile.get("sex").toString().isEmpty()) {
			custPro.setSex(customerProfile.get("sex").toString());
		}
		if (customerProfile.get("residence") != null && !customerProfile.get("residence").toString().isEmpty()) {
			custPro.setResidence(customerProfile.get("residence").toString());
		}
		if (customerProfile.get("maritalStatusDiscription") != null
				&& !customerProfile.get("maritalStatusDiscription").toString().isEmpty()) {
			custPro.setMaritalStatusDiscription(customerProfile.get("maritalStatusDiscription").toString());
		}
		if (customerProfile.get("educationLevel") != null
				&& !customerProfile.get("educationLevel").toString().isEmpty()) {
			custPro.setEducationLevel(customerProfile.get("educationLevel").toString());
		}
		if (customerProfile.get("alias") != null && !customerProfile.get("alias").toString().isEmpty()) {
			custPro.setAlias(customerProfile.get("alias").toString());
		}
		if (customerProfile.get("incorporationDate") != null
				&& !customerProfile.get("incorporationDate").toString().isEmpty()) {
			custPro.setDateOfBirth(dateFormat(customerProfile.get("incorporationDate").toString()));
		}
		if (customerProfile.get("incorporationNumber") != null
				&& !customerProfile.get("incorporationNumber").toString().isEmpty()) {
			custPro.setIncorporationNumber(customerProfile.get("incorporationNumber").toString());
		}
		if (customerProfile.get("incoprporationIssuedBy") != null
				&& !customerProfile.get("incoprporationIssuedBy").toString().isEmpty()) {
			custPro.setIncoprporationIssuedBy(customerProfile.get("incoprporationIssuedBy").toString());
		}
		if (customerProfile.get("panNo") != null && !customerProfile.get("panNo").toString().isEmpty()) {
			custPro.setPanNo(customerProfile.get("panNo").toString());
		}
		if (customerProfile.get("panIssueDate") != null
				&& !customerProfile.get("panIssueDate").toString().isEmpty()) {
			custPro.setPanIssueDate(dateFormat(customerProfile.get("panIssueDate").toString()));
		}
		if (customerProfile.get("nameOfTheEmployer") != null
				&& !customerProfile.get("nameOfTheEmployer").toString().isEmpty()) {
			custPro.setNameOfTheEmployer(customerProfile.get("nameOfTheEmployer").toString());
		}
		if (customerProfile.get("designation") != null
				&& !customerProfile.get("designation").toString().isEmpty()) {
			custPro.setDesignation(customerProfile.get("designation").toString());
		}
		if (customerProfile.get("nameOfBusiness") != null
				&& !customerProfile.get("nameOfBusiness").toString().isEmpty()) {
			custPro.setNameOfBusiness(customerProfile.get("nameOfBusiness").toString());
		}
		if (customerProfile.get("workTenure") != null && !customerProfile.get("workTenure").toString().isEmpty()) {
			custPro.setWorkExperience(customerProfile.get("workTenure").toString());
		}
		if (customerProfile.get("department") != null && !customerProfile.get("department").toString().isEmpty()) {
			custPro.setDepartment(customerProfile.get("department").toString());
		}
		if (customerProfile.get("sourceOfIncome") != null
				&& !customerProfile.get("sourceOfIncome").toString().isEmpty()) {
			custPro.setSourceOfIncome(customerProfile.get("sourceOfIncome").toString());
		}
		if (customerProfile.get("sourceOfWealth") != null
				&& !customerProfile.get("sourceOfWealth").toString().isEmpty()) {
			custPro.setSourceOfWealth(customerProfile.get("sourceOfWealth").toString());
		}
		if (customerProfile.get("netWorth") != null && !customerProfile.get("netWorth").toString().isEmpty()) {
			custPro.setNetWorth(customerProfile.get("netWorth").toString());
		}
		if (customerProfile.get("panNo") != null && !customerProfile.get("panNo").toString().isEmpty()) {
			custPro.setPanNo(customerProfile.get("panNo").toString());
		}
		if (customerProfile.get("employersContactNumber") != null
				&& !customerProfile.get("employersContactNumber").toString().isEmpty()) {
			custPro.setEmployersContactNumber(customerProfile.get("employersContactNumber").toString());
		}
		if (customerProfile.get("address") != null && !customerProfile.get("address").toString().isEmpty()) {
			custPro.setAddress(customerProfile.get("address").toString());
		}
		if (customerProfile.get("country") != null && !customerProfile.get("country").toString().isEmpty()) {
			custPro.setCountry(customerProfile.get("country").toString());
		}
		if (customerProfile.get("nameOfBusiness") != null
				&& !customerProfile.get("nameOfBusiness").toString().isEmpty()) {
			custPro.setNameOfBusiness(customerProfile.get("nameOfBusiness").toString());
		}
		if (customerProfile.get("typeOfBusiness") != null
				&& !customerProfile.get("typeOfBusiness").toString().isEmpty()) {
			custPro.setTypeOfBusiness(customerProfile.get("typeOfBusiness").toString());
		}
		if (customerProfile.get("sourceOfIncome") != null
				&& !customerProfile.get("sourceOfIncome").toString().isEmpty()) {
			custPro.setSourceOfIncome(customerProfile.get("sourceOfIncome").toString());
		}
		if (customerProfile.get("mobileNumber") != null
				&& !customerProfile.get("mobileNumber").toString().isEmpty()) {
			custPro.setMobileNumber(customerProfile.get("mobileNumber").toString());
		}
		if (customerProfile.get("emailId") != null && !customerProfile.get("emailId").toString().isEmpty()) {
			custPro.setEmailId(customerProfile.get("emailId").toString());
		}
		if (customerProfile.get("incoporationIssuedCountry") != null
				&& !customerProfile.get("incoporationIssuedCountry").toString().isEmpty()) {
			custPro.setIncoporationIssuedCountry(customerProfile.get("incoporationIssuedCountry").toString());
		}
		if (customerProfile.get("incoporationIssuedCountry") != null
				&& !customerProfile.get("incoporationIssuedCountry").toString().isEmpty()) {
			custPro.setIncoporationIssuedCountry(customerProfile.get("incoporationIssuedCountry").toString());
		}
		if (customerProfile.get("accountName") != null
				&& !customerProfile.get("accountName").toString().isEmpty()) {
			custPro.setAccountName(customerProfile.get("accountName").toString());
		}
		if (customerProfile.get("turnover") != null && !customerProfile.get("turnover").toString().isEmpty()) {
			custPro.setTurnover(customerProfile.get("turnover").toString());
		}
		if (customerProfile.get("income") != null && !customerProfile.get("income").toString().isEmpty()) {
			custPro.setIncome(customerProfile.get("income").toString());
		}
		if (customerProfile.get("overdraftLimit") != null
				&& !customerProfile.get("overdraftLimit").toString().isEmpty()) {
			custPro.setOverDraftLimit(customerProfile.get("overdraftLimit").toString());
		}
		if (customerProfile.get("currencyType") != null
				&& !customerProfile.get("currencyType").toString().isEmpty()) {
			custPro.setCurrencyType(customerProfile.get("currencyType").toString());
		}
		if (customerProfile.get("purpose") != null && !customerProfile.get("purpose").toString().isEmpty()) {
			custPro.setPurposeOfAccount(customerProfile.get("purpose").toString());
		}
		if (customerProfile.get("purpose") != null && !customerProfile.get("purpose").toString().isEmpty()) {
			custPro.setPurposeOfAccount(customerProfile.get("purpose").toString());
		}
		if (customerProfile.get("sectorCode") != null
				&& !customerProfile.get("sectorCode").toString().isEmpty()) {
			custPro.setTypeOfBusiness(customerProfile.get("sectorCode").toString());
		}
		if (customerProfile.get("accountStatusCode") != null
				&& !customerProfile.get("accountStatusCode").toString().isEmpty()) {
			custPro.setAccountStatus(customerProfile.get("accountStatusCode").toString());
		}
		if (customerProfile.get("businessList") != null
				&& !customerProfile.get("businessList").toString().isEmpty()) {
			custPro.setAccountRelation(customerProfile.get("businessList").toString());
		}
		return custPro;
	}

	@Override
	public Map<String, Object> getCustomerTopData(String custID, String accountId) {
		return custRepositoryCustom.getCustomerTopData(custID,accountId);
	}
 
}
