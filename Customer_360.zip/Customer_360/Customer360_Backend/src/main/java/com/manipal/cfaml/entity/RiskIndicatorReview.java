package com.manipal.cfaml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "RISKINDICATOR_REVIEW")
public class RiskIndicatorReview {

	@Id
	@Column(name = "REVIEW_ID")
	private String reviewId;

	@Column(name = "DATA_ID")
	private String dataId;

	@Column(name = "RISK_SCORE_VALUE")
	private String riskScoreValue;

	@Column(name = "STATIC_DYNAMIC")
	private String staticDynamic;

	@Column(name = "RISK_SCORE_VALUE_NATURAL")
	private String riskScoreValueNatural;

	@Column(name = "RISK_SCORE_VALUE_LEGAL")
	private String riskScoreValueLegal;

	@Column(name = "RISK_PROFILE_ID")
	private String riskProfileId;

	@Column(name = "RISKINDICATORDATA_ID")
	private String riskIndicatorDataId;

	@Column(name = "REVIEW_DATETIME")
	private Date reviewDateTime;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REVIEWED_BY")
	private String reviewedBy;

	@Column(name = "APPROVED_REJECTEDBY")
	private String approvedRejectedBy;

	@Column(name = "COMMENT_REVIEWER")
	private String commentReviewer;

	@Column(name = "COMMENT_APPROVER_REJECTEDBY")
	private String commentApproverRejectedBy;

	@Column(name = "WEIGHTAGE")
	private String weightage;

	@Column(name = "CHANGED_SET")
	private String changedSet;
}
