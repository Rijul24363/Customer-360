package com.manipal.cfaml.controller;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.cfaml.service.PDFService;

@RequestMapping("pdf")
@RestController
public class PDFController {

	@Autowired
	PDFService pdfService;

	@PostMapping(value = "/cddDataReportPdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public void cddDataReportPdfDownload(@RequestBody Map<String, Object> data, HttpServletResponse response) {
		String custId=data.get("custID").toString();
		String userId=data.get("userId").toString();
		Map<String,Object> configFile=(Map<String, Object>) data.get("configFile");
		ByteArrayOutputStream baos = pdfService.cddDataReportPdfDownload(custId, response,configFile,userId);
		// setting the content type
		response.setContentType("application/pdf");
		response.setContentLength(baos.size());
		OutputStream os = null;
		try {
			os = response.getOutputStream();
		} catch (java.io.IOException e) {
			e.printStackTrace();
		}
		try {
			baos.writeTo(os);
			os.flush();
		    os.close();
		} catch (java.io.IOException e) {
			e.printStackTrace();
		}
	}
}
