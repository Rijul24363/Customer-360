package com.manipal.cfaml.constant;

public class ConstantUrl {

}

class ViewConstantUrl {

	public static String CUSTOMER_SEARCH = "/customerSearch";

	public static String GET_EMPLOYEE_LIST_EXCEPT_EMP_ID = "/getEmployeeListExceptEmpId";

	public static String GET_CUSTOMER_DETAILS = "/getCustomerDetails";
}

class CddConstantUrl {

	public static String GET_CUSTOMER_DETAILS_FOR_CDD = "/getCustomerDetailsForCDD";

	public static String GET_ADDRESS_DETAILS = "/getAddressDetails";

	public static String GET_ACCOUNT_LIST_BY_CUSTOMER_ID = "/getAccountListByCustomerId";

	public static String GET_ACCOUNT_DETAILS_BY_CUSTID_AND_ACC_ID = "/getAccountDetailsByCustIdAndAddId";

	public static String GET_CDD_DATA_BASED_ON_ACCOUNTID = "/getCddDataBasedOnAccountId";
}

class TransactionProfileConstantUrl {

	public static String TRANSACTION_DETAILS = "/transactionDetails";
}

class RiskRatingConstantUrl {

	public static String GET_RISK_INDICATOR_DATA = "/getRiskIndicatorData";

	public static String GET_COMPUTATION_INFO = "/getComputationInfo";
}

class SanctionConstantUrl {

	public static String GET_SANCTION_LIST_INFO = "/getSanctionListInfo";

}

class SaveConstantUrl {

	public static String SAVE_INFO = "/saveInfo";

}

class HistoryViewConstantUrl {

	public static String GET_HISTORY_VIEW_INFO = "/getHistoryViewInfo";

}

class RoleFunctionalityUrl {

	public static String get_Role_Wise_Page_List = "/getPagesForRolesOnUserId";
	public static String get_user_details = "/getUserDetails";

}

class MainPageConstantUrl {

	public static String GET_RISK_DISTRIBUTION = "/getRiskDisrtibution";

}