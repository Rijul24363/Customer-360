package com.manipal.cfaml.entity;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="OFFLINE_CASE_DETAILS")
public class OfflineCaseDetails {
	
	@Id
	@Column(name = "CASE_ID")
	private BigInteger caseId;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Column(name = "SCENARIO_ID")
	private String scenarioId;

}
