package com.manipal.cfaml.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.manipal.cfaml.entity.RiskIndicatorReview;

@Repository
public interface RiskIndicatorReviewRepository extends JpaRepository<RiskIndicatorReview, String>{

}
