package com.manipal.cfaml.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Rahul Rathod
 *
 * 
 */

@Getter
@Setter
@Entity
@Table(name = "RISKINDICATOR_DATA")
public class RiskIndicatorData {

	@Id
	@Column(name = "RISKINDICATOR_ID")
	private String riskIndicatorId;

	@Column(name = "RISKINDICATORDATA_ID")
	private String riskIndicatorDataId;

	@Column(name = "RISK_INDICATOR_DESC")
	private String riskIndicatorDesc;

	@Column(name = "RISK_SCORE_VALUE")
	private String riskScoreValue;

	@Column(name = "STATIC_DYNAMIC")
	private String staticDynamic;


}
