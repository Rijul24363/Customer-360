package com.manipal.cfaml.roles.repository;

import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.manipal.cfaml.entity.UserInfo;

public interface UserInfoRepository  extends JpaRepository<UserInfo, String>{

	UserInfo getByUserName(String userName);

	@Query(nativeQuery=true, value="select ri.ROLE_NAME as roleName, ui.USER_NAME as userName from VIZPROD.ROLE_INFO ri \r\n"
			+ "inner join VIZPROD.USER_INFO ui on ui.ROLE_ID = ri.ROLE_ID\r\n"
			+ "WHERE ri.ROLE_ID =:roleId and ui.USER_ID =:userId")
	Map<String, Object> getUserDetailsAndRoleDetails(String userId, String roleId);
	
}
