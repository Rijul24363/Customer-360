export const environment = {
    production: false,
    apiUrl: 'http://localhost:9090',
    tokenfForApi:"secratekey123",
    returnToCf: 'http://localhost:8080/KYC/RBAC.in',
    cfLoginUrl: 'http://localhost:8080/CrossFraud',
    fieldsConfigPath:'assets/configuration/fieldsConfig.laxmi.json',
    audit: true

};
