export const environment = {
    production: false,
    tokenfForApi:"secratekey123",
    returnToCf: '../../../../KYC/RBAC.in',
    cfLoginUrl: '../../../../CrossFraud',
    apiUrl: '../../../../Customer360_Backend',
    fieldsConfigPath:'assets/configuration/fieldsConfig.nabil.json',
    audit: true
    
};