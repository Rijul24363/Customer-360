export class Regex {
  
  public static ALPHABET_REGEX: RegExp = /^[a-zA-Z]+$/;
  
  public static ALPHA_SPACE_REGEX: RegExp = /^[a-zA-Z\s]+$/;
  
  public static ALPHA_NUMERIC_SPACE_REGEX: RegExp = /^[a-zA-Z0-9\s]+$/;

  public static NUMERIC_ALPHA_SPECIAL_SPACE_REGEX: RegExp = /^[a-zA-Z0-9\s!@#$%^&*()\-_=+[{\]};:'",<.>/?\\|]+$/;
  
  public static NUMERIC_REGEX: RegExp = /^\d+$/;
  
  public static NUMERIC_COMMA_DOT_REGEX: RegExp = /^[0-9,.]+$/;
  
  public static NUMERIC_COMMA_DOT_SPACE_REGEX: RegExp = /^[0-9,. ]+$/;
  
  public static EMAIL_REGEX: RegExp = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  public static WEBSITE_REGEX: RegExp = /^(http[s]?:\/\/)?[^\s(["<,>]*\.[^\s[",><]*$/;

  public static INDIAN_PAN_REGEX: RegExp = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;

  public static INDIAN_AADHAR_REGEX: RegExp = /^\d{12}$/;

  public static ANY_REGEX: RegExp = /^.*$/;

  public static LANDLINE_NUMBER_REGEX: RegExp = /^\d{3}-\d{7}$/;

  public static MOBILE_NUMBER_REGEX: RegExp = /^[0-9]{10}$/;

  public static NEPALI_WARD_REGEX: RegExp = /^\d{1,3}(-\d{1,2})?$/;

  public static NEPALI_GOOGLE_PLUS_CODE_REGEX: RegExp = /^[\w+-]+$/;

  public static ENTERPRISE_NAME_REGEX: RegExp = /^[a-zA-Z0-9\s\-_.,&()'"!@#$%^*[\]{}<>?/|\\]+$/;

  public static INCORPORATION_NUMBER_REGEX: RegExp = /^[A-Z]{3}-\d{3}-\d{4}$/;

  public static UNIVERSAL_ZIP_CODE_REGEX: RegExp = /^[a-zA-Z0-9\s-]+$/;

}



export class DropdownOptions {

  public static relatedPersonalType = [
    { name: 'Beneficiary or Beneficial Owner', code: 'Beneficiary or Beneficial Owner' },
    { name: 'Signatory', code: 'Signatory' },
    { name: 'Director', code: 'Director' },
  ];

  public static genderList = [
    { name: 'Male', code: 'M' },
    { name: 'Female', code: 'F' },
    { name: 'Other', code: 'Other' },
    { name: 'MIGR', code: 'MIGR' },
  ];

  public static serviceAvailed = [
    { name: 'Credit Card', code: 'Credit Card' },
    { name: 'Debit Card', code: 'Debit Card' },
    { name: 'Email Solutions', code: 'Email Solutions' },
    { name: 'Internet Banking', code: 'Internet Banking' },
    { name: 'Mobile Money Service', code: 'Mobile Money Service' },
    { name: 'Sandook (Locker)', code: 'Sandook (Locker)' },
    { name: 'Cheque Book', code: 'Cheque Book' },
    { name: 'SMS', code: 'SMS' },

  ];
  public static relationship = [
    { name: 'Spouse', code: 'Spouse' },
    { name: 'Partner', code: 'Partner' },
    { name: 'Ward', code: 'Ward' },
    { name: 'Father', code: 'Father' },
    { name: 'Mother', code: 'Mother' },
    { name: 'Sister', code: 'Sister' },
    { name: 'Brother', code: 'Brother' },
    { name: 'Son', code: 'Son' },
    { name: 'Daughter', code: 'Daughter' },
    { name: 'Friend', code: 'Friend' },
    { name: 'Employee', code: 'Employee' },
    { name: 'Employer', code: 'Employer' },
    { name: 'Colleague', code: 'Colleague' }
  ];

  public static customerCategoryList: [
    { name: "Individual - Employed by Others", code: "Individual - Employed by Others" },
    { name: "Individual - Self-employed", code: "Individual - Self-employed" },
    { name: "Individual – Unemployed  ", code: "Individual – Unemployed  " },
    { name: "Entity Customer", code: "Entity Customer" },
  ]

  public static dataTabList: [
    { name: "Bank's Policy", code: "Bank's Policy" },
    { name: "Regulatory", code: "Regulatory" }
  ]

  public static  requirementList = [
    { name: "Mandatory", code: "m" },
    { name: "Optional", code: "m" }
  ]
  
  public static policyList: [
    { name: "Bank's Policy", code: "Bank's Policy" },
    { name: "Regulatory", code: "Regulatory" }
  ]
}