import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { TabViewModule } from 'primeng/tabview';
import { DividerModule } from 'primeng/divider';
import { CalendarModule } from 'primeng/calendar';
import { PanelMenuModule } from 'primeng/panelmenu';
import { TableModule } from 'primeng/table';
import { PanelModule } from 'primeng/panel';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { CommentPanelComponent } from '../modules/customer360/cdd-module/comment-panel/comment-panel.component';
import { DialogModule } from 'primeng/dialog';

import { CardModule } from 'primeng/card';

@NgModule({
  declarations: [CommentPanelComponent,
  ],
  imports: [
    CommonModule,
    ConfirmDialogModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    CardModule,
    DialogModule
  ],
  exports:[
    InputTextareaModule,
    NgSelectModule,
    InputTextModule,
    TabViewModule,
    DividerModule,
    CalendarModule,
    PanelMenuModule,
    TableModule,
    PanelModule,
    FormsModule,
    ReactiveFormsModule,
    FormsModule,
    ConfirmDialogModule,
    CommentPanelComponent,
    CardModule,
    DialogModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class CommonUseModule { }
