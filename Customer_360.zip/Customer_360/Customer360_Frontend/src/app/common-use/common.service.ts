import { Injectable, OnInit } from '@angular/core';
import * as moment from 'moment';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { EncryptDecryptService } from '../services/encrypt-decrypt-service';
import { HttpService } from '../services/http.service';
import { environment } from 'src/environments/environment';
import { CddConstantUrl, CommonUserUrl } from './constantUrl';
import { HttpParams } from '@angular/common/http';
import { DatePipe, DecimalPipe } from '@angular/common';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class CommonService implements OnInit {
  breadcrumbMenu = new Subject<any>();
  hideCustomer360SubMenu = new Subject<any>
  eNumList = new BehaviorSubject<any>(null);

  constructor(private decrypt: EncryptDecryptService, private httpService: HttpService) {
  }
  ngOnInit(): void {
  }

  setBreadcrumbMenu(data: any) {
    this.breadcrumbMenu.next(data)
  }

  getBreadcrumbMenu(): Observable<any> {
    return this.breadcrumbMenu;
  }

  mappingKeyAndValue(data: any) {
    let tableFilteredData: any = []
    for (let obj of data) {
      for (let key in obj) {
        tableFilteredData.push({ field: key, header: key })
      }
      break
    }
    return tableFilteredData;
  }

  setHideCustomerSubMenu(hide: boolean) {
    this.hideCustomer360SubMenu.next(hide);
  }

  getHideCustomerSubMenu(): Observable<boolean> {
    return this.hideCustomer360SubMenu;
  }

  adtobs(adDate: string, bsDate?: string): any {

    if (adDate) {
      if (adDate.length === 13 && /^\d+$/.test(adDate)) {
        const date = new Date(parseInt(adDate, 10));
        const formattedDate = date.toISOString().substring(0, 10); // Format: yyyy-MM-dd
        // console.log("Formatted date:", formattedDate);
      } else {
        const adMoment = moment(adDate, "DD-MM-YYYY");
        const bsMoment = adMoment.add(56, "years").add(8, "months").add(15, "days");
        return bsMoment.format("DD/MM/YYYY");
      }
    } else if (bsDate) {
      const bsMoment = moment(bsDate, "DD/MM/YYYY");
      const adMoment = bsMoment.subtract(56, "years").subtract(8, "months").subtract(15, "days");
      return adMoment.format("YYYY-MM-DD");
    }
  }

  getToken(utoken: any, rtoken: any) {
    return new Promise((resolve, reject) => {
      let userId = this.decrypt.decryptUsingAES(utoken)
      let roleId = this.decrypt.decryptUsingAES(rtoken)
      resolve({ "userId": userId, "roleId": roleId })
    })
  }


  getEnumsData() {
    let params = new HttpParams();
    var url = environment.apiUrl + CommonUserUrl.GET_ENUM;
    this.httpService.decryptDataResponse(this.httpService.getMethod(url, params)).subscribe((res: any) => {
      let resData = res
      if (resData) {
        this.eNumList.next(resData)
      }
    });
  }



  formatValue(value: any) {
    if (value === null) {
      return '';
    }
    let stringValue = value.toString();
    let filteredValue = stringValue.replace(/[^0-9.-]/g, '');    // Filter out non-numeric characters
    let numberFormat = '1.2-2';
    let decimalPipe: DecimalPipe = new DecimalPipe('en-US'); // Use the appropriate locale for your application
    return decimalPipe.transform(filteredValue, numberFormat);
  }
  

  getKycMasterData() {
    let params = new HttpParams();
    var url = environment.apiUrl + CommonUserUrl.KYC_MASTER;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  changeDateToBS(date:any){
    let datePipe:any = new DatePipe('en-US')
    let value =this.adtobs(datePipe.transform(date,'dd/MM/yyyy')) || '';
    return value;
  }
}
