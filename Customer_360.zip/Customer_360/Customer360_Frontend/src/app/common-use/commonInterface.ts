export interface SaveData {
  customerId: string,
  createdBy?: any,
  auditedBy?: any,
  accountId?: any,
  comment?: any,
  screenName: any,
  fieldsUpdated?: any,
  selectedAccountData?: any,
  selectedIdentictionNumber?:any,
  status?: any,
  requestId?:any
}

export interface loggedinUserDetails {
  userName: string,
  roleName: string,
  userId: any,
  roleId: any
}

export interface ValidationInterface {
  require?: boolean;
  minlength?: number;
  maxlength?: number;
  regexPattern?: any;
  errorMessage: {
    requiredErrorMessage?: string;
    patternErrorMessage?: string;
    minLengthErrorMessage?: string;
    maxLengthErrorMessage?: string;
  };
  minDate?: Date | null;
  maxDate?: Date | null;
}
