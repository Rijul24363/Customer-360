export class ViewConstantUrl {

  public static CUSTOMER_SEARCH = '/customer/customerSearch';

  public static GET_EMPLOYEE_LIST_EXCEPT_EMP_ID = '/common/getEmployeeListExceptEmpId';

  public static GET_CUSTOMER_DETAILS_FOR_VIEW = '/customer/getCustomerDetailsForView';
}

export class CddConstantUrl {

  public static GET_CUSTOMER_DETAILS_FOR_CDD = '/customer/getCustomerDetailsForCDD';

  public static GET_ACCOUNT_LIST_BY_CUSTOMER_ID = '/customer/getAccountListByCustomerId';

  public static GET_ACCOUNT_DETAILS_BY_CUSTID_AND_ACC_ID = '/customer/getAccountDetailsByCustIdAndAddId';

  public static GET_CDD_DATA_BASED_ON_ACCOUNTID = '/customer/getCddDataBasedOnAccountId';

  public static GET_LIST_OF_BUSINESS = '/customer/getBusinessList';

}

export class TransactionProfileConstantUrl {

  public static TRANSACTION_DETAILS = '/customer/transactionDetails';
}

export class RiskRatingConstantUrl {

  public static GET_RISK_INDICATOR_DATA = '/riskrating/getRiskIndicatorData';

  public static GET_COMPUTATION_INFO = '/riskrating/getComputationInfo';
}
export class SanctionConstantUrl {

  public static GET_SANCTION_LIST_INFO = '/sanction/getSanctionListInfo';

}

export class SaveConstantUrl {

  public static SAVE_INFO = '/customer/updateCustomerData';

}

export class HistoryViewConstantUrl {

  public static GET_HISTORY_VIEW_INFO = '/history/getHistoryViewInfo';

}

export class RoleFunctionalityUrl {

  public static get_Role_Wise_Page_List = '/roles/getPagesForRolesOnUserId';
  public static get_user_details = '/roles/getUserDetails';

}

export class MainPageConstantUrl {

  public static GET_RISK_DISTRIBUTION = '/customer/getRiskDisrtibution';

  public static GET_CDD_COUNT = '/customer/getCDDataCount';
  public static GET_CDD_STATUS = '/customer/getCDDDataStatus';

}

export class CustomerListConstantUrl {

  public static GET_CRR_DATA = '/customer/getCRRData';

}

export class CommonUserUrl{

  public static GET_ADDRESS_DETAILS = '/common/getAddressDetails';

  public static GET_ACCOUNT_TYPE_DETAILS = '/common/getAllAccountTypeList';

  public static GET_ENUM  = '/common/getEnumData';

  public static KYC_MASTER  = '/common/getKycMasterData';

}

export class PDFUrl{
  public static Download_CDD_Report  = '/pdf/cddDataReportPdf';

}

