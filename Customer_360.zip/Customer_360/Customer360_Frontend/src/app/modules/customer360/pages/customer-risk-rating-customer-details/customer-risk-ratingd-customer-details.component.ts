import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customer-risk-rating-customer-details',
  templateUrl: './customer-risk-rating-customer-details.component.html',
  styleUrls: ['./customer-risk-rating-customer-details.component.css']
})
export class CustomerRiskRatingCustomerDetailsComponent implements OnInit{
  row: string;
  customerType = [
    { name: 'Individual - Employed by Others', code: 'Individual - Employed by Others' },
    { name: 'Individual - Self-employed', code: 'Individual - Self-employed' },
    { name: 'Individual - Unemployed', code: 'Individual - Unemployed' }    ,
    { name: 'Entity Customer', code:'Entity Customer'}  
];
constructor(private route: ActivatedRoute) {
}
ngOnInit() {
  this.route.queryParams.subscribe((params:any) => {
    this.row = params.row
    console.log(this.row)
    // Access and use other query parameters if needed
  });
}
}
