import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CddDataRequirementsComponent } from './cdd-data-requirements.component';

describe('CddDataRequirementsComponent', () => {
  let component: CddDataRequirementsComponent;
  let fixture: ComponentFixture<CddDataRequirementsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CddDataRequirementsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CddDataRequirementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
