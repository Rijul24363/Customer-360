import { Component, OnInit } from '@angular/core';
import { Customer360Service, loginSession } from '../../services/customer360.service';
import { EncryptDecryptService } from 'src/app/services/encrypt-decrypt-service';
import { FormControl, FormGroup } from '@angular/forms';
import { SaveData } from '../../../../common-use/commonInterface';
import { DatePipe } from '@angular/common';
interface CustomerDetails {
  accountDetails: BankDetails,
  sanctionScore: number,
  leEnquiries: number,
  fiuDMLIFreezes: number,
  fiuDMLIEnquiries: number,
  adverseMedia: number,
  crrSystem: any,
  crrManual: any,
  pep: any,
  fatca: any,
  profileCreationDate: any,
  currencyType: string,
  lastKycDate: string,
  kycStatus: string,
  kycDueDate: string
}

interface BankDetails {
  saving: AccountDetails[],
  loan: AccountDetails[],
  deposit: AccountDetails[]
}
interface AccountDetails {
  ACCOUNT_ID: any,
  PRODUCT_GROUP: any,
  balance: number
}
@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {
  commentForm: FormGroup = new FormGroup({
    comments: new FormControl(null),
    userId: new FormControl(null)
  })

  selectedCustDataOb: any
  employeeList: any = []
  getCustomerDetailsOb: CustomerDetails = {
    sanctionScore: 0,
    accountDetails: {
      saving: [],
      loan: [],
      deposit: [],
    },
    leEnquiries: 0,
    fiuDMLIFreezes: 0,
    fiuDMLIEnquiries: 0,
    adverseMedia: 0,
    crrSystem: null,
    crrManual: null,
    pep: null,
    fatca: null,
    profileCreationDate: null,
    currencyType: '',
    lastKycDate: 'NA',
    kycStatus: 'NA',
    kycDueDate: 'NA'
  };
  pep: any
  fatca: any
  constructor(private service: Customer360Service, private cipher: EncryptDecryptService) {
    let data: any = service.selectedCustomerData
    if (data) {
      this.selectedCustDataOb = data
    }

  }
  ngOnInit(): void {
    this.getCustomerDetails()
  }

  getCustomerDetails() {
    var datePipe: any = new DatePipe('en-US')

    this.service.getCustomerDetails(this.selectedCustDataOb.customerId).subscribe((res: any) => {
      let res2 = res;
      if (res2) {
        let accountdetails: AccountDetails[] = res2.accountDetails;
        accountdetails.forEach((ele: any) => {
          if (ele.PRODUCT_GROUP == "SBA") {
            this.getCustomerDetailsOb.accountDetails.saving.push(ele);
          } else if (ele.PRODUCT_GROUP == "ODA") {
            this.getCustomerDetailsOb.accountDetails.loan.push(ele);
          } else if (ele.PRODUCT_GROUP == "TDA") {
            this.getCustomerDetailsOb.accountDetails.deposit.push(ele);
          }
        });

        this.getCustomerDetailsOb.sanctionScore = res2.sanctionScore?.SD_SCORE ?? 0;
        this.getCustomerDetailsOb.leEnquiries = res2.leEnquiries?.CNT ?? 0;
        this.getCustomerDetailsOb.adverseMedia = res2.adverseMedia?.CNT ?? 0;
        this.getCustomerDetailsOb.fiuDMLIEnquiries = res2.fiuDMLIEnquiries?.CNT ?? 0;
        this.getCustomerDetailsOb.fiuDMLIFreezes = res2.fiuDMLIFreezes?.CNT ?? 0;
        this.getCustomerDetailsOb.crrManual = this.convertRisk(res2.manualRating) ?? null;
        this.getCustomerDetailsOb.crrSystem = this.convertRisk(res2.systemRating) ?? null;

        this.getCustomerDetailsOb.pep = res2.customerOtherDetails?.pep ?? null;
        this.getCustomerDetailsOb.fatca = res2.customerOtherDetails?.fatca ?? null;
        this.pep = res2.customerOtherDetails?.pep ?? null;
        this.fatca = res2.customerOtherDetails?.fatca ?? null;
        this.getCustomerDetailsOb.profileCreationDate = res2.customerOtherDetails?.profileCreationDate ?? null;
        this.getCustomerDetailsOb.currencyType = res2.customerOtherDetails?.currencyType ?? null;
        this.getCustomerDetailsOb.lastKycDate = res2.customerOtherDetails?.lastKycDate ? datePipe.transform(res2.customerOtherDetails?.lastKycDate, 'dd/MM/yyyy') : 'NA';
        this.getCustomerDetailsOb.kycStatus = res2.customerOtherDetails?.kycStatus ?? null;


        if (res2.customerOtherDetails?.crr == "L") {
          if (res2.customerOtherDetails.lastKycDate != null) {
            try {
              let getDate = new Date(res2.customerOtherDetails.lastKycDate)
              getDate.setFullYear(getDate.getFullYear() + 8)
              this.getCustomerDetailsOb.kycDueDate = datePipe.transform(getDate, 'dd/MM/yyyy');
            } catch (error) {
              this.getCustomerDetailsOb.kycDueDate = "NA"
            }
          } else {
            this.getCustomerDetailsOb.kycDueDate = "NA"
          }

        } else if (res2.customerOtherDetails?.crr == "M") {
          if (res2.customerOtherDetails.lastKycDate != null) {
            try {
              let getDate = new Date(res2.customerOtherDetails.lastKycDate)
              getDate.setFullYear(getDate.getFullYear() + 5)
              this.getCustomerDetailsOb.kycDueDate = datePipe.transform(getDate, 'dd/MM/yyyy');
            } catch (error) {
              this.getCustomerDetailsOb.kycDueDate = "NA"
            }
          } else {
            this.getCustomerDetailsOb.kycDueDate = "NA"
          }
        } else if (res2.customerOtherDetails?.crr == "H") {
          if (res2.customerOtherDetails.lastKycDate != null) {
            try {
              let getDate = new Date(res2.customerOtherDetails.lastKycDate)
              getDate.setFullYear(getDate.getFullYear() + 1)
              this.getCustomerDetailsOb.kycDueDate = datePipe.transform(getDate, 'dd/MM/yyyy');
            } catch (error) {
              this.getCustomerDetailsOb.kycDueDate = "NA"
            }
          } else {
            this.getCustomerDetailsOb.kycDueDate = "NA"
          }
        }

      }
    });

  }
  convertRisk(score: any) {
    if (score == "H") {
      return "High"
    }
    else if (score == "M") {
      return "Medium"
    }
    else if (score == "L") {
      return "Low"
    }
    return ""
  }



  onSubmit() {
    let saveData: SaveData;

    let changedValues = {}
    if (this.pep != this.getCustomerDetailsOb.pep) {
      changedValues = JSON.stringify({ "pep": { "oldValue": this.pep, "newValue": this.getCustomerDetailsOb.pep } })
    }
    if (this.fatca != this.getCustomerDetailsOb.fatca) {
      changedValues = JSON.stringify({ "fatca": { "oldValue": this.fatca, "newValue": this.getCustomerDetailsOb.fatca } });
    }
    saveData = {
      customerId: this.selectedCustDataOb.customerId,
      accountId: null,
      fieldsUpdated: changedValues,
      screenName: "View",
    };
    let allFormDataUpdate = new Array();
    allFormDataUpdate.push(saveData)
    this.service.setSaveData(allFormDataUpdate);
  }

}
