import { Component } from '@angular/core';

@Component({
  selector: 'app-same-name-customers',
  templateUrl: './same-name-customers.component.html',
  styleUrls: ['./same-name-customers.component.css']
})
export class SameNameCustomersComponent {

}
