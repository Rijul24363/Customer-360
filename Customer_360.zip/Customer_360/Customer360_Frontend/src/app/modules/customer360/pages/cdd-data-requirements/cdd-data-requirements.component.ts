import { Component } from '@angular/core';
import { CddForms } from '../../cdd-module/cdd/cdd.form';
import { Customer360Service } from '../../services/customer360.service';
import { CommonService } from 'src/app/common-use/common.service';
import { RoleFunctionalityService } from 'src/app/services/role-functionality.service';
import { MessageService } from 'primeng/api';
import { DropdownOptions } from 'src/app/common-use/staticData';

@Component({
  selector: 'app-cdd-data-requirements',
  templateUrl: './cdd-data-requirements.component.html',
  styleUrls: ['./cdd-data-requirements.component.css']
})
export class CddDataRequirementsComponent {
  employedByOthers: boolean = false
  selfEmployed: boolean = false
  unemployed: boolean = false
  entity: boolean = false
  beneficiary: string = "Beneficiary";

  constructor(private service: Customer360Service, private commonService: CommonService, private roleService: RoleFunctionalityService,
    public forms: CddForms, private messageService: MessageService) { }


  persnolForm = Object.keys(this.forms.personalForm.controls)
  entityForm = Object.keys(this.forms.entityForm.controls)
  identificationForm = Object.keys(this.forms.identificationForm.controls)
  addressForm = Object.keys(this.forms.addressForm.controls)
  accountForm = Object.keys(this.forms.accountForm.controls)
  revenueForm = Object.keys(this.forms.revenueForm.controls)
  familyForm = Object.keys(this.forms.familyForm.controls)
  nomineeForm = Object.keys(this.forms.nomineeForm.controls)
  beneficiaryForm = Object.keys(this.forms.beneficiaryForm.controls)
  signatoriesForm = Object.keys(this.forms.signatoriesForm.controls)
  directorsForm = Object.keys(this.forms.directorsForm.controls)
  otherForm = Object.keys(this.forms.otherForm.controls)

  requirementList =DropdownOptions.requirementList 
  policyList=DropdownOptions.policyList
  customerCategoryList=DropdownOptions.customerCategoryList
  dataTabList=DropdownOptions.dataTabList

  onSelectionChange(event: any) {
    if (event.custType == 'Non-Individual') {
      this.entity = true
      this.employedByOthers = false
      this.selfEmployed = false
      this.unemployed = false
      this.beneficiary = "Beneficial Owner";
    } else if (event.custType == 'Individual') {
      this.employedByOthers = true
      this.entity = false
      this.selfEmployed = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Employed by Others') {
      this.employedByOthers = true
      this.entity = false
      this.selfEmployed = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Self-employed') {
      this.selfEmployed = true
      this.employedByOthers = false
      this.entity = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Unemployed') {
      this.unemployed = true
      this.employedByOthers = false
      this.entity = false
      this.selfEmployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Self-employed') {
      this.selfEmployed = true
      this.employedByOthers = false
      this.entity = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    }
  }



}
