import { Component, OnInit } from '@angular/core';
import { Customer360Service } from '../../services/customer360.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-main-page',
    templateUrl: './main-page.component.html',
    styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
    riskData: any;
    cddData: any;
    riskOptions: any;
    cddOptions: any;
    totalNullCount: number = 0;
    riskDistribution:any
    constructor(private service: Customer360Service, private router: Router) {

    }
    ngOnInit() {
        this.getRiskDisrtibution()
        this.getCddCount()
    }

    getRiskDisrtibution() {
        this.service.getRiskDisrtibution().subscribe((data: any) => {
            const documentStyle = getComputedStyle(document.documentElement);
            const textColor = documentStyle.getPropertyValue('--text-color');
            this.riskDistribution  = data
            if(this.riskDistribution == null){
                this.riskDistribution = {
                    High: 0,
                    Medium: 0,
                    Low: 0,
                };
            }
            this.riskData = {
                labels: ['High', 'Medium', 'Low'],
                datasets: [
                    {
                        data: [this.riskDistribution.High, this.riskDistribution.Medium, this.riskDistribution.Low],
                        backgroundColor: [documentStyle.getPropertyValue('--blue-500'), documentStyle.getPropertyValue('--yellow-500'), documentStyle.getPropertyValue('--green-500')],
                        hoverBackgroundColor: [documentStyle.getPropertyValue('--blue-400'), documentStyle.getPropertyValue('--yellow-400'), documentStyle.getPropertyValue('--green-400')]
                    }
                ]
            };

            this.riskOptions = {
                plugins: {
                    legend: {
                        labels: {
                            usePointStyle: true,
                            color: textColor
                        }
                    }
                }
            };
        })
    }

    getCddCount() {
        this.service.getCddCount().subscribe((data: any) => {
            this.totalNullCount = data.nullCount
           
            let cddCount = data
            if(!cddCount){
                cddCount = {
                    notNullCount: 0,
                    nullCount: 0,
                };
            }
            const documentStyle = getComputedStyle(document.documentElement);
            const textColor = documentStyle.getPropertyValue('--text-color');
            this.cddData = {
                labels: ['Complete', 'Partial Available'],
                datasets: [
                    {
                        data: [cddCount.notNullCount, cddCount.nullCount],
                        backgroundColor: [documentStyle.getPropertyValue('--blue-500'), documentStyle.getPropertyValue('--yellow-500'), documentStyle.getPropertyValue('--green-500')],
                        hoverBackgroundColor: [documentStyle.getPropertyValue('--blue-400'), documentStyle.getPropertyValue('--yellow-400'), documentStyle.getPropertyValue('--green-400')]
                    }
                ]
            };

            this.cddOptions = {
                plugins: {
                    legend: {
                        labels: {
                            usePointStyle: true,
                            color: textColor
                        }
                    }
                }
            };
        })
    }


    redirectToRiskRating(e: any) {
        let row = e.element.element.$context.index
        let count=0;
        if(row == 0){
            count= this.riskDistribution.High
        }
        else if(row == 1){
            count= this.riskDistribution.Medium
        }
        else if(row == 2){
            count= this.riskDistribution.Low
        }
        const queryParams = { row: row ,count:count};
        this.router.navigate(['pages/customer_risk_rating_report'], { queryParams })
    }

    redirectToCddReport(e: any) {
        let row = e.element.index
        if (row == 0) {
            return;
        }
        const queryParams = { row: row, totalNullCount: this.totalNullCount };
        this.router.navigate(['pages/cdd_status_report'], { queryParams })
    }


}
