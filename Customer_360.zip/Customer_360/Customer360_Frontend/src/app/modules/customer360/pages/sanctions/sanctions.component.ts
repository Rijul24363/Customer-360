import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Customer360Service } from '../../services/customer360.service';
import { SaveData } from '../../../../common-use/commonInterface';

@Component({
  selector: 'app-sanctions',
  templateUrl: './sanctions.component.html',
  styleUrls: ['./sanctions.component.css']
})
export class SanctionsComponent {

  sanctionForm: FormGroup = new FormGroup({
    startDate: new FormControl(null),
    endDate: new FormControl(null),
    comments: new FormControl(null),
  })
  accountId: any;
  custID: any;

  customerType = [
    { name: 'Individual - Employed by Others', code: 'Individual - Employed by Others' },
    { name: 'Individual - Self-employed', code: 'Individual - Self-employed' },
    { name: 'Individual - Unemployed', code: 'Individual - Unemployed' },
    { name: 'Entity Customer', code: 'Entity Customer' }
  ];
  saveData: SaveData;

  constructor(private service: Customer360Service) {
    this.getCustomerDetails()
    this.service.getAccountID().subscribe((res: any) => {
      this.accountId = res;
    })
  }

  foundValue: any = {
    SD_SCORE: "",
    OFAC_LIST: "Not Found",
    Accuity_PEP_List: "Not Found",
    LOCAL_LIST: "Not Found",
    CICL_List: "Not Found",
    PEP_List: "Not Found",
    HMT_List: "Not Found",
    Accuity_GWL_List: "Not Found",
    Accuity_EDD_List: "Not Found",
    EU_LIST: "Not Found",
    UN_List: "Not Found",
    Accuity: "Not Found",

  }


  getSanctionListInfo() {
    const datePipe = new DatePipe('en-US');
    this.service.getSanctionListInfo(this.custID, this.accountId, datePipe.transform(this.sanctionForm.value.startDate, 'yyyy-MM-dd'), datePipe.transform(this.sanctionForm.value.endDate, 'yyyy-MM-dd')).subscribe((res: any) => {
      const data = res;
      // const listInfo: any[] = [];
  
      for (const item of data) {
        const listName = item.listName;
        const count = item.count;

        if (listName === 'PEP List') {
          this.foundValue.PEP_List = "Found";
        } else if (listName === 'OFAC List') {
          this.foundValue.OFAC_LIST = "Found";
        } else if (listName === 'Accuity_GWL List' ||listName ==='Accuity_GWL List' ) {
          this.foundValue.Accuity = "Found";
        } else if (listName === 'LOCAL LIST') {
          this.foundValue.LOCAL_LIST = "Found";
        } else if (listName === 'EU List') {
          this.foundValue.EU_LIST = "Found";
        } else if (listName === 'UN List') {
          this.foundValue.UN_List = "Found";
        }else if (listName === 'CICL List') {
          this.foundValue.CICL_List = "Found";
        }else if (listName === 'HMT List') {
          this.foundValue.HMT_List = "Found";
        }else if (item.sdScore >this.foundValue.SD_SCORE) {
          this.foundValue.SD_SCORE=item.sdScore
        }
        // listInfo.push({ listName: listName, count: count, sdScore: this.foundValue.SD_SCORE });
      }
      this.foundValue.SD_SCORE=this.foundValue.SD_SCORE ? this.foundValue.SD_SCORE+" %" :"";

      // // Access the listName and count values in listInfo
      // console.log(listInfo);
    });
  }
  

getCustomerDetails() {
  let data: any = this.service.selectedCustomerData
  if (data) {
      this.custID = data.customerId
      this.getAccountListByCustomerId()
  }
}
  getAccountListByCustomerId() {
    this.service.setHideAccountPanel(this.custID,true,true)
  }

  onSubmit() {
    this.saveData = {
      customerId: this.custID,
     
      accountId: this.accountId,
      screenName: "Sanctions" ,
    };
    return this.saveData   
 
  }

}
