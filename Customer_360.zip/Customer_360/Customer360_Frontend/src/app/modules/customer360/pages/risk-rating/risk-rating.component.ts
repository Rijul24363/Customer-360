import { Component, OnInit } from '@angular/core';
import { Customer360Service } from '../../services/customer360.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { SaveData } from '../../../../common-use/commonInterface';
import { ActivatedRoute } from '@angular/router';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { MessageService } from 'primeng/api';
import * as moment from 'moment';

@Component({
  selector: 'app-risk-rating',
  templateUrl: './risk-rating.component.html',
  styleUrls: ['./risk-rating.component.css']
})
export class RiskRatingComponent implements OnInit {

  riskRatingForm: FormGroup = new FormGroup({
    startDate: new FormControl(null),
    endDate: new FormControl(null),
  })
  accountId: any
  custID: any;
  riskIndicators: any;
  staticScore: any = 0
  dynamicScore: any = 0
  staticTotalSum:any=0
  dynamicTotalSum:any=0
  staticWeightageSum:any=0
  dynamicWeightageSum:any=0
  netSum:any=0
  riskRatingLevel: any;
  custType: any;
  custName: any;
  panNo: any;
  riskIndicator = new Array();
  dynamicIndicator = new Array();
  finalRiskRating:any;
  autoOverride:any;

  constructor(private service: Customer360Service,  private formBuilder: FormBuilder,
    private route: ActivatedRoute,private messageService: MessageService) {

    this.getCustomerDetails()
    this.service.getAccountID().subscribe((res: any) => {
      this.accountId = res;
    })
  }
  
  ngOnInit() {
    const oneYearAgo = moment().subtract(1, 'year');

    this.riskRatingForm = this.formBuilder.group({
      startDate: oneYearAgo.format('DD/MM/YYYY'),
      endDate: moment().format('DD/MM/YYYY')
    });

    this.route.queryParams.subscribe((params: any) => {
      if (params && params.customerId) {
        this.custID = params.customerId;
        this.accountId = params.accountId;
        this.getComputationInfo()
        this.riskRatingForm = this.formBuilder.group({
          startDate: oneYearAgo.format('DD/MM/YYYY'),
          endDate: moment().format('DD/MM/YYYY')
        });
      }
    });
  }


  getAccountListByCustomerId() {
    this.service.setHideAccountPanel(this.custID, true, true)
  }

  getCustomerDetails() {
    let data: any = this.service.selectedCustomerData
    if (data) {
      this.custID = data.customerId
      this.custType = data.custType
      this.custName=data.fullName
      this.panNo=data.panNo
      this.getAccountListByCustomerId()
    }
  }

  

  getResArr(
    computationInfo:any[],
    arr: any[]
  ) {
    this.riskIndicator=[]
    this.dynamicIndicator=[]
    this.staticWeightageSum=0
    this.dynamicWeightageSum=0
    this.staticTotalSum=0
    this.dynamicTotalSum=0;
    this.netSum=0
    computationInfo.forEach(riskData=>{
      let key=riskData.split("=")[0];

      if(key !=""){
        let descriptionData=arr.find(data => data.riskIndicatorId == key);
          if(descriptionData){
            let data=riskData.split("=")[1];
            let weightage=data.split("~")[0];
            let riskParam=data.split("~")[1].split("$$")[0];
            let riskParamval=data.split("~")[1].split("$$")[1];
            let riskIndicatorValue=0;
            let label="NA";
            if (riskParam <= 2) {
              riskIndicatorValue = weightage * 2; // If riskScore is LOW
              label="LOW";
            } else if (riskParam >= 3 && riskParam < 5) {
                riskIndicatorValue = weightage * 3; // If riskScore is MEDIUM
                label="MEDIUM";
            }else if (riskParam >= 5) {
                riskIndicatorValue = weightage * 5; // If riskScore is HIGH or any other value
                label="HIGH";
            }
            
          if(key <= 20){
            this.staticWeightageSum=this.staticWeightageSum+parseFloat(weightage);
            this.staticTotalSum=this.staticTotalSum+riskIndicatorValue
            this.riskIndicator.push({
              "riskIndicatorName": descriptionData.riskIndicatorName,
              "weightage": weightage,
              "riskParam": label,
              "riskParameterValue": riskParamval,
              "SumProduct":riskIndicatorValue.toFixed(2)
            })
          }else{
            this.dynamicWeightageSum=this.dynamicWeightageSum+parseFloat(weightage);
            this.dynamicTotalSum=this.dynamicTotalSum+riskIndicatorValue
            this.dynamicIndicator.push({
              "riskIndicatorName": descriptionData.riskIndicatorName,
              "weightage": weightage,
              "riskParam": label,
              "riskParameterValue": riskParamval,
              "SumProduct":riskIndicatorValue.toFixed(2)
            })
          }
          }
         
        
      }
    })

    this.netSum=(this.staticTotalSum*this.staticScore)+(this.dynamicTotalSum*this.dynamicScore)
    
  }
  getComputationInfo() {
    this.riskIndicator = new Array();
    this.dynamicIndicator = new Array();
    const startDateFormatted = moment(this.riskRatingForm.value.startDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
    const endDateFormatted = moment(this.riskRatingForm.value.endDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
    
    if(!this.riskRatingForm.value.startDate && !this.riskRatingForm.value.endDate){
      return  this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Select Date ' });
    }
    else{
    this.service.getComputationInfo(this.custID, this.accountId, startDateFormatted, endDateFormatted).subscribe((res: any) => {
      let res2 = res[0].COMPUTATION_INFO;
      this.riskRatingLevel = this.getLevel(res[0].CRR_SYSTEM)
      this.finalRiskRating= this.getLevel(res[0].CRR_RATING)
      this.autoOverride=res[0].AUTO_OVERRIDE
      if (!this.autoOverride || this.autoOverride.toUpperCase() === 'N' || this.autoOverride.toUpperCase() === 'NO') {
        this.autoOverride = 'NO';
      } else if (this.autoOverride.toUpperCase() === 'Y') {
        this.autoOverride = 'Yes';
      }

      if (res2) {
        const dynamicDelimiter = '#';
        const dynamicIndex = res2.indexOf(dynamicDelimiter);
        const dynoValue = res2.substring(dynamicIndex + dynamicDelimiter.length);
        const splitValues = dynoValue.split("~");

        this.staticScore = parseFloat(splitValues[0]).toFixed(2);
        this.dynamicScore = parseFloat(splitValues[1]).toFixed(2);
        let computationInfo:any = res2.replace(/#.+$/, "");
        computationInfo=computationInfo.split("@");
        this.service.getRiskIndicatorData().subscribe((res: any) => {
          if (res) {
            this.riskIndicators = res;
            this.getResArr(computationInfo, res)
          }

        })
      }
    })
  }
  }
  
  exportExcel() {
    const wb = XLSX.utils.book_new();
  
    // Create a worksheet
    const worksheet = XLSX.utils.json_to_sheet([]);
  
    const customerInfo = [
          { Label: 'Customer Type', Value: this.custType },
          { Label: 'Customer Name', Value: this.custName },
          { Label: 'Customer ID', Value: this.custID },
          { Label: 'Account ID', Value: this.accountId },
          { Label: 'Static Indicator', Value: this.staticScore },
          { Label: 'Dynamic Indicator', Value: this.dynamicScore }
        ];
  
    // Add rows for customer information
    customerInfo.forEach((info, index) => {
      XLSX.utils.sheet_add_json(worksheet, [info], { skipHeader: true, origin: { r: index, c: 0 } });
    });
  
    // Define common column headers for tables
    const commonHeaders = ['Risk Indicator', 'Weightage', 'Risk Parameter', 'Risk Parameter Value','Sum Product'];
  
    // Create the riskIndicator table
    const riskIndicatorTable = [commonHeaders]; // Initialize with headers
    this.riskIndicator.forEach(data => {
      const rowData = [
        data.riskIndicatorName,
        data.weightage,
        data.riskParam,
        data.riskParameterValue,
        data.SumProduct
      ];
      riskIndicatorTable.push(rowData);
    });
  
    // Create the dynamicIndicator table
    const dynamicIndicatorTable = [commonHeaders]; // Initialize with headers
    this.dynamicIndicator.forEach(data => {
      const rowData = [
        data.riskIndicatorName,
        data.weightage,
        data.riskParam,
        data.riskParameterValue,
        data.SumProduct
      ];
      dynamicIndicatorTable.push(rowData);
    });
  
    // Calculate the maximum number of rows in both tables
    const maxRows = Math.max(riskIndicatorTable.length, dynamicIndicatorTable.length);
  
    // Create the combined table with spacing
    const combinedTable = [];
    for (let i = 0; i < maxRows; i++) {
      const row = [
        ...(riskIndicatorTable[i] || Array(5).fill('')), // Fill empty cells if necessary
        '', // Add spacing column 
        ...(dynamicIndicatorTable[i] || Array(5).fill('')) // Fill empty cells if necessary
      ];
      combinedTable.push(row);
    }
  
    // Add the combined table to the worksheet
    XLSX.utils.sheet_add_aoa(worksheet, combinedTable, { origin: { r: customerInfo.length + 1, c: 0 } });
  
    // Set column widths for columns to 180 pixels each
    worksheet['!cols'] = [{ width: 25 }, { width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 },{ width: 25 }];
  
    // Manually format header cells with bold style
    const headerStyle = { bold: true };
    commonHeaders.forEach((header, colIndex) => {
      const cell = XLSX.utils.encode_cell({ r: customerInfo.length, c: colIndex });
      worksheet[cell] = XLSX.utils.format_cell({ ...worksheet[cell], s: headerStyle });
    });
    const totalRow = ['TOTAL:','', '', '',this.staticTotalSum, '','', '', '', '', this.dynamicTotalSum];
    const weightageRow = ['Weightage:', this.staticWeightageSum, '', '', '', '', '', this.dynamicWeightageSum];
  
    // Create Net Sum and System Rating rows
    const systemRatingText = ['System Rating:',this.riskRatingLevel];
    const netSumRow = ['Net Sum:', this.netSum]
  
    // Adding additional rows to the worksheet
    XLSX.utils.sheet_add_aoa(worksheet, [totalRow], { origin: { r: customerInfo.length + maxRows + 2, c: 0 } });
    XLSX.utils.sheet_add_aoa(worksheet, [weightageRow], { origin: { r: customerInfo.length + maxRows + 3, c: 0 } });
    XLSX.utils.sheet_add_aoa(worksheet, [systemRatingText], { origin: { r: customerInfo.length + maxRows + 4, c: 0 } });
    XLSX.utils.sheet_add_aoa(worksheet, [netSumRow], { origin: { r: customerInfo.length + maxRows + 5, c: 0 } });

  
    // Set column widths for the additional columns
    worksheet['!cols'].push({ width: 25 }); 
    // Add the worksheet to the workbook
    XLSX.utils.book_append_sheet(wb, worksheet, 'Risk_Rating'); // Name the worksheet
  
    // Create the Excel file
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' });
    const data: Blob = new Blob([excelBuffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
    });
  
    // Save the Excel file
    FileSaver.saveAs(data, 'Risk_Rating.xlsx');
  }
  
  
  getSystemRatingText(): string {
    switch (this.riskRatingLevel) {
      case 'H':
        return 'HIGH';
      case 'M':
        return 'MEDIUM';
      case 'L':
        return 'LOW';
      default:
        return '';
    }
  }
  
  getLevel(level:string): string {
    switch (level) {
      case 'H':
        return 'HIGH';
      case 'M':
        return 'MEDIUM';
      case 'L':
        return 'LOW';
      default:
        return '';
    }
  }
  
  
  

}