import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SameNameCustomersComponent } from './same-name-customers.component';

describe('SameNameCustomersComponent', () => {
  let component: SameNameCustomersComponent;
  let fixture: ComponentFixture<SameNameCustomersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SameNameCustomersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SameNameCustomersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
