import { Component, OnDestroy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer360Service, loginSession } from '../../services/customer360.service';
import { CommonService } from 'src/app/common-use/common.service';
import { Subscription } from 'rxjs';
import { EncryptDecryptService } from 'src/app/services/encrypt-decrypt-service';

@Component({
  selector: 'app-customer-search-panel',
  templateUrl: './customer-search-panel.component.html',
  styleUrls: ['./customer-search-panel.component.css']
})
export class CustomerSearchPanelComponent implements OnDestroy {
  pageName: any
  searchPanelForm: FormGroup = new FormGroup({
    custType: new FormControl(null),
    custID: new FormControl(null),
    custName: new FormControl(null),
    panNo: new FormControl(null),
    accountId: new FormControl(null),
  })
  selectedCustDataOb:boolean=false
  viewSearchGridTable: boolean = false
  breadcrumbMenuLabel:any=null
  subscribe:Subscription
  accountSub:Subscription
  accountList: any;
  accountListSectionhide:boolean=false
  constructor(public route: Router, private service:Customer360Service,private commonService:CommonService,
    private cipher:EncryptDecryptService,private activeroute: ActivatedRoute) {      
    let data:any=sessionStorage.getItem('selectedCustDataOb')   
    if(data){
      var patchedData:loginSession=JSON.parse(this.cipher.decryptUsingAES(data))
      if(patchedData){
        this.commonService.setHideCustomerSubMenu(true)
        this.searchPanelForm.patchValue({
          custType:patchedData.custType,
          custID:patchedData.customerId,
          custName:patchedData.fullName,
          panNo:patchedData.panNo
        })
        this.service.selectedCustomerData=patchedData
        this.selectedCustDataOb=true
      }      
    }

    this.subscribe=commonService.getBreadcrumbMenu().subscribe((res:any)=>{
      if(res.title == "Customer360")
        this.breadcrumbMenuLabel=res.label
      else
        this.breadcrumbMenuLabel=null
    })

    this.accountSub=this.service.getHideAccountPanel().subscribe((res:any)=>{
      this.accountList=[]
      if(res.show){
        this.accountList=res.accountList
        this.accountListSectionhide=true
        if(res.selectedId){
          this.searchPanelForm.patchValue({"accountId":this.accountList[0]})
          this.changeAccountId(this.accountList[0])
        }else{
          this.accountList=["ALL"].concat(this.accountList)
          this.searchPanelForm.patchValue({"accountId":"ALL"})
          this.changeAccountId(this.accountList[0])
        }        
      }
    })
    this.activeroute.queryParams.subscribe(params => {
      const customerId = params['customerId'];
      if(customerId && customerId !="null"){
        this.searchCustomer(customerId)
      }
    });
  }
  ngOnDestroy(): void {
    this.subscribe.unsubscribe();
    this.accountSub.unsubscribe();

  }

  searchedCustomerList=[]
  searchCustomer(customerId?:any) {
    this.searchedCustomerList=[]
    this.selectedCustDataOb = false
    sessionStorage.removeItem('selectedCustDataOb');
    if(customerId){
      this.searchPanelForm.patchValue({
        "custID":customerId
      })
    }
    this.service.customerSearch(this.searchPanelForm.value).subscribe((res:any)=>{
      let resData=res;            
      if (res.length === 1) {
        // console.log(res[0])
        resData.forEach((element:any) => {
          element.fullName=(element.firstName ? element.firstName+" " : "").concat(element.middleName ? element.middleName+" " :"",element.lastName ? element.lastName:"")
        });
        this.selectedCustData(res[0])
      }
      else{
        this.viewSearchGridTable = true
        resData.forEach((element:any) => {
          element.fullName=(element.firstName ? element.firstName+" " : "").concat(element.middleName ? element.middleName+" " :"",element.lastName ? element.lastName:"")
        });
        this.searchedCustomerList=resData
      }
   
      
      // this.tableFilteredData=this.commonService.mappingKeyAndValue(this.searchedCustomerList)
    })
  }

  selectedCustData(data: any) {
    this.selectedCustDataOb = true
    sessionStorage.setItem('selectedCustDataOb', this.cipher.encryptUsingAES(JSON.stringify(data)))
    this.searchPanelForm.patchValue({
      custType:data.custType,
      custID:data.customerId,
      custName:data.fullName,
      panNo:data.panNo
    })
    this.service.selectedCustomerData=data
    this.viewSearchGridTable = false
    this.commonService.setHideCustomerSubMenu(true)
    this.route.navigate(['pages/view'])
  }

  resetCustomer(){
    this.commonService.setHideCustomerSubMenu(false)
    this.viewSearchGridTable = false
    this.selectedCustDataOb = false
    sessionStorage.removeItem('selectedCustDataOb');
    this.searchPanelForm.reset()
    this.route.navigate(['/pages'])
    this.commonService.setBreadcrumbMenu("")
    this.accountListSectionhide=false
  }

  changeAccountId(e:any){
    this.service.setAccountID(e)
  }
}