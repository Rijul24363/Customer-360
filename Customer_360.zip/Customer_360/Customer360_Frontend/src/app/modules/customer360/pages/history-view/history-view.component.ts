import { Component } from '@angular/core';
import { Customer360Service } from '../../services/customer360.service';
import { CommonService } from 'src/app/common-use/common.service';
import { RoleFunctionalityService } from 'src/app/services/role-functionality.service';
import { FormControl, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment';
import { SaveData, loggedinUserDetails } from 'src/app/common-use/commonInterface';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-history-view',
  templateUrl: './history-view.component.html',
  styleUrls: ['./history-view.component.css']
})
export class HistoryViewComponent {
  histroyView: FormGroup = new FormGroup({
    startDate: new FormControl(null),
    endDate: new FormControl(null),
    comments: new FormControl(null),
    columnValue: new FormControl(null),
    columnName: new FormControl(null),
    lastUpdatedOn: new FormControl(null),
  })
  loggedinUserDetails: loggedinUserDetails = {
    userName: '',
    roleName: '',
    userId: '',
    roleId: ''
  }
  accountId: any;
  custID: any;
  historyViewList: any = [];
  loading: boolean;
  unsub: Subscription
  configFile = environment.audit;
  showData: boolean = false;
  showDataValue:any=[]
  constructor(private service: Customer360Service, private commonService: CommonService,
    private roleService: RoleFunctionalityService, private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {
    this.getCustomerDetails()
    this.unsub = this.roleService.logedInUserInfo.subscribe((res: loggedinUserDetails) => {
      if (res.userId) {
        this.loggedinUserDetails = res
      }
    })
  }
  ngOnDestroy(): void {
    this.unsub.unsubscribe();
  }

  //  public forms: CddForms
  getHistoryViewInfo() {
    const datePipe = new DatePipe('en-US');
    this.service.getHistoryViewInfo(this.custID, this.accountId, datePipe.transform(this.histroyView.value.startDate, 'yyyy-MM-dd'), datePipe.transform(this.histroyView.value.endDate, 'yyyy-MM-dd')).subscribe((res: any) => {
      this.historyViewList = res;
      this.loading = false;

    })
  }


  getCustomerDetails() {
    let data: any = this.service.selectedCustomerData
    if (data) {
      this.custID = data.customerId
      this.accountId = data.accountId
      this.getHistoryViewInfo()

    }
  }

  formatDate(date: any) {
    const datePipe = new DatePipe('en-US');
    return datePipe.transform(date, 'dd/MM/yyyy')
  }

  statusUpdate(data: any, status: String) {
    let mess: string = ''
    if (status == 'A') {
      mess = "accept"
    } else { mess = 'reject' }
    let saveData: SaveData = {
      customerId: this.custID,
      requestId: data.requestId,
      screenName: "History View",
      status: status,
      auditedBy: this.loggedinUserDetails.roleName
    }
    let allFormDataUpdate = new Array();
    allFormDataUpdate.push(saveData)
    this.confirmationService.confirm({
      message: 'Are you sure that you want to ' + mess + ' ?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.service.onCommnetSubmit(allFormDataUpdate).subscribe((res: any) => {
            if (res == 'Success') {
              this.messageService.add({ severity: 'info', summary: 'Success', detail: 'Your Data has been saved' });
            }
            this.getCustomerDetails()
          },
            (error: any) => {
            })
           
      },
    });
  }

  showDialog(data:any) {
    const parseData=JSON.parse(data)
    const dataArray = Object.keys(parseData).map(key => ({
      field: this.camelCaseToNormal(key),
      oldValue: parseData[key]?.oldValue,
      newValue: parseData[key]?.newValue
    }));
    this.showDataValue=dataArray
    this.showData = true;
  }

  closeDialod(){
    this.showData = false;
    this.showDataValue=[]
  }

  camelCaseToNormal(input: string): string {
    return input
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/([A-Z])([A-Z][a-z])/g, '$1 $2')
      .toUpperCase();
  }
}
