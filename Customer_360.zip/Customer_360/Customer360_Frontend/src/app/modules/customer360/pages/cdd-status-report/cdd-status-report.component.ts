import { Component, OnInit } from '@angular/core';
import { Customer360Service } from '../../services/customer360.service';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/common-use/common.service';

@Component({
  selector: 'app-cdd-status-report',
  templateUrl: './cdd-status-report.component.html',
  styleUrls: ['./cdd-status-report.component.css']
})
export class CddStatusReportComponent implements OnInit {
  totalNullCount: number = 0
  temptotalNullCount: number = 0
  kycMasterList = []
  cddStatusReportList: any;
  dtInputFields: any
  constructor(private service: Customer360Service, private route: ActivatedRoute, private commonSerc: CommonService) {
    this.route.queryParams.subscribe((event: any) => {
      this.totalNullCount = event.totalNullCount
      this.temptotalNullCount = this.totalNullCount
      this.getKycMasterData().then((res:any)=>{
        this.getCDDStatus()
      })
    })
  }
  ngOnInit(): void {

  }
  getCDDStatus(event?: any) {
    this.cddStatusReportList = []
    let event2: any = 0;
    if (event)
      event2 = event.first;
    this.service.getCddStatus(event2, this.dtInputFields).subscribe((res: any) => {
      if (res.innerList) {
        if (res.totalCount) {
          this.totalNullCount = res.totalCount
        } else {
          this.totalNullCount = this.temptotalNullCount
        }
        res.innerList.map((obj: any) => {
          const filteredKeys2 = Object.keys(obj).filter(key => !['fullName', 'branchName', 'customerId', 'des'].includes(key));
          let multiColumns = ""
          for (const key of filteredKeys2) {
            this.kycMasterList.forEach((element:any) => {
              if(key == element.FULLY_CLASSIFIED_NAME){
                 multiColumns = multiColumns + element.TITLE + ", ";
               }
            });
             
          }
          multiColumns.slice(0, -1)

          const filteredKeys = Object.keys(obj).filter(key => ['fullName', 'branchName', 'customerId', 'des'].includes(key));
          const filteredObj: any = {};
          for (const key of filteredKeys) {
            filteredObj[key] = obj[key];
          }
          filteredObj.columnList = multiColumns
          this.cddStatusReportList.push(filteredObj)
        });
      }
    })
  }

  getKycMasterData() {
    return new Promise((resolve, reject) => {
      this.commonSerc.getKycMasterData().subscribe((res: any) => {
        this.kycMasterList = res
        resolve(true)
      })
    })
  }

}
