import { Component, OnDestroy } from '@angular/core';
import { Customer360Service, loginSession } from '../../services/customer360.service';
import { FormControl, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { EncryptDecryptService } from 'src/app/services/encrypt-decrypt-service';
import { SaveData } from '../../../../common-use/commonInterface';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-transaction-profile',
  templateUrl: './transaction-profile.component.html',
  styleUrls: ['./transaction-profile.component.css']
})
export class TransactionProfileComponent implements OnDestroy {
  customerType = [
    { name: 'Individual - Employed by Others', code: 'Individual - Employed by Others' },
    { name: 'Individual - Self-employed', code: 'Individual - Self-employed' },
    { name: 'Individual - Unemployed', code: 'Individual - Unemployed' },
    { name: 'Entity Customer', code: 'Entity Customer' }
  ];
  trnsactionAmount: any;
  trnsactionCount: any;
  trnsactionAmount2: any;
  trnsactionCount2: any;
  trnsactionModeFundAmount: any;
  trnsactionModeFundCount: any;
  options: any;
  documentStyle: any
  textColorSecondary: any
  surfaceBorder: any
  transactionForm: FormGroup = new FormGroup({
    startDate: new FormControl(null),
    endDate: new FormControl(null),
  })
  accountId: any;
  custID: any;
  saveData: SaveData;
  StrCount: number;
  TTRCount: number;
  manualCount: number;
  systemGeneratedCount: number;
  accIdSub:Subscription
  selectedAccountId:any
  trnsactionModeAmount: any;
  trnsactionModeCount: any;
  constructor(private service: Customer360Service, private cipher:EncryptDecryptService) {
    this.accIdSub = this.service.getAccountID().subscribe((res: any) => {
      this.selectedAccountId=res
    })
    this.getCustomerDetails()
    this.documentStyle = getComputedStyle(document.documentElement);
    this.textColorSecondary = this.documentStyle.getPropertyValue('--text-color-secondary');
    this.surfaceBorder = this.documentStyle.getPropertyValue('--surface-border');
    this.options = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      plugins: {
        legend: {
          labels: {
            color:  this.documentStyle.getPropertyValue('--text-color')
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: this.textColorSecondary,

            font: {
              weight: 500
            }
          },
          grid: {
            color: this.surfaceBorder,
            drawBorder: false
          }
        },
        y: {
          ticks: {
            color: this.textColorSecondary
          },
          grid: {
            color: this.surfaceBorder,
            drawBorder: false
          }
        }

      }
    };
  }
  ngOnDestroy(): void {
    this.accIdSub.unsubscribe()
  }

  getTransactionDetailsBasedOnChannels() {
    const datePipe = new DatePipe('en-US');

    let channel = new Array();
    let amount = new Array();
    let count = new Array();

    
    let channelMode = new Array();
    let amountMode = new Array();
    let countMode = new Array();

    let accTransferData={
      deposit_amount:0,
      deposit_count:0,
      transaction_type:"ACCOUNT TRANSFER",
      withdrawal_amount:0,
      withdrawal_count:0
    };
    let clearingData={
      deposit_amount:0,
      deposit_count:0,
      transaction_type:"CLEARING",
      withdrawal_amount:0,
      withdrawal_count:0
    };
     let cashData={
      deposit_amount:0,
      deposit_count:0,
      transaction_type:"CASH",
      withdrawal_amount:0,
      withdrawal_count:0
    };

    const fromDate = this.transactionForm.value.startDate
    const endDate = this.transactionForm.value.endDate
    
    this.service.getTransactionDetailsBasedOnChannels(this.custID,datePipe.transform(fromDate, 'yyyy-MM-dd'), datePipe.transform(endDate, 'yyyy-MM-dd'),this.selectedAccountId).subscribe((res: any) => {
      if(res){
        this.TTRCount=res.TTRCount
        this.StrCount=res.STRCount
        this.manualCount=res.getManualGeneratedCount
        this.systemGeneratedCount=res.getSystemGeneratedCount
        let getTxnCountAndChannel = res.getTxnCountAndChannel
        getTxnCountAndChannel.forEach((element: any) => {
          channel.push(element.channel)
          amount.push(element.amt)
          count.push(element.cnt)
        })

        let getTransModeFundType = res.getTransModeFundType
        getTransModeFundType.forEach((element: any) => {
          channelMode.push(element.decription)
          amountMode.push(element.amt)
          countMode.push(element.cnt)
        })

        let getModeWiseTxnAmtAndCount = res.getModeWiseTxnAmtAndCount
        getModeWiseTxnAmtAndCount.forEach((element: any) => {
          if(element.transMode == "TRANSFER" && element.transaction_type=="Deposit"){
            accTransferData.deposit_amount=accTransferData.deposit_amount+element.amt;    
            accTransferData.deposit_count=accTransferData.deposit_count+element.cnt;    
          }                
          else if(element.transMode == "CASH" && element.transaction_type=="Deposit"){
            cashData.deposit_amount=cashData.deposit_amount+element.amt;    
            cashData.deposit_count=cashData.deposit_count+element.cnt;    
          }          
          else if(element.transMode == "CLEARING" && element.transaction_type=="Deposit"){
            clearingData.deposit_amount=clearingData.deposit_amount+element.amt;    
            clearingData.deposit_count=clearingData.deposit_count+element.cnt;    
          }
            
          if(element.transMode == "TRANSFER" && element.transaction_type=="Withdrawal"){
            accTransferData.withdrawal_amount=accTransferData.withdrawal_amount+element.amt;    
            accTransferData.withdrawal_count=accTransferData.withdrawal_count+element.cnt;    
          }                
          else if(element.transMode == "CASH" && element.transaction_type=="Withdrawal"){
            cashData.withdrawal_amount=cashData.withdrawal_amount+element.amt;    
            cashData.withdrawal_count=cashData.withdrawal_count+element.cnt;    
          }          
          else if(element.transMode == "CLEARING" && element.transaction_type=="Withdrawal"){
            clearingData.withdrawal_amount=clearingData.withdrawal_amount+element.amt;    
            clearingData.withdrawal_count=clearingData.withdrawal_count+element.cnt;    
          }
        })
  
        this.trnsactionAmount = {
          labels: channel,
          datasets: [
            {
              label:"Transaction Amount",
              backgroundColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              borderColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              data: amount
            }
          ]
        };
        this.trnsactionCount = {
          labels: channel,
          datasets: [
            {
              label:"Transaction Count",
              backgroundColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              borderColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              data: count
            }
          ]
        };
  
        this.trnsactionAmount2 = {
          labels: ['Account Transfer', 'Cash', 'Clearing'],
          datasets: [
            {
              label: 'Incoming',
              backgroundColor: this.documentStyle.getPropertyValue('--blue-500'),
              borderColor: this.documentStyle.getPropertyValue('--blue-500'),
              data: [accTransferData.deposit_amount, cashData.deposit_amount, clearingData.deposit_amount]
            },
            {
              label: 'Outgoing',
              backgroundColor: this.documentStyle.getPropertyValue('--orange-500'),
              borderColor: this.documentStyle.getPropertyValue('--orange-500'),
              data: [accTransferData.withdrawal_amount, cashData.withdrawal_amount, clearingData.withdrawal_amount]
            },
  
          ]
        };
        this.trnsactionCount2 = {
          labels: ['Account Transfer', 'Cash', 'Clearing'],
          datasets: [
            {
              label: 'Incoming',
              backgroundColor: this.documentStyle.getPropertyValue('--blue-500'),
              borderColor: this.documentStyle.getPropertyValue('--blue-500'),
              data: [accTransferData.deposit_count, cashData.deposit_count, clearingData.deposit_count]
            },
            {
              label: 'Outgoing',
              backgroundColor: this.documentStyle.getPropertyValue('--orange-500'),
              borderColor: this.documentStyle.getPropertyValue('--orange-500'),
              data: [accTransferData.withdrawal_count, cashData.withdrawal_count, clearingData.withdrawal_count]
            },
  
          ]
        };

        this.trnsactionModeAmount = {
          labels: channelMode,
          datasets: [
            {
              label:"Transaction Mode Amount",
              backgroundColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              borderColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              data: amountMode
            }
          ]
        };
        this.trnsactionModeCount = {
          labels: channelMode,
          datasets: [
            {
              label:"Transaction Mode Count",
              backgroundColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              borderColor: [this.documentStyle.getPropertyValue('--blue-500'), this.documentStyle.getPropertyValue('--orange-500'), this.documentStyle.getPropertyValue('--yellow-500'), this.documentStyle.getPropertyValue('--green-500')],
              data: countMode
            }
          ]
        };
      }
    })
  }
  getCustomerDetails() {
    let data:any=sessionStorage.getItem('selectedCustDataOb')   
    if(data){
      var patchedData:loginSession=JSON.parse(this.cipher.decryptUsingAES(data))
      if (patchedData) {
        this.custID = patchedData.customerId
        this.getAccountListByCustomerId(this.custID)
      }
    }
  }
  onSubmit() {
    this.saveData = {
      customerId: this.custID,
     
      accountId: this.accountId,
      screenName: "TransactionProfile" ,
    };
    return this.saveData 
  }

  getAccountListByCustomerId(custID:any) {
    this.service.setHideAccountPanel(custID,false,true)
  }
}

