import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer360Service } from '../../services/customer360.service';

@Component({
  selector: 'app-customer-risk-rating-report',
  templateUrl: './customer-risk-rating-report.component.html',
  styleUrls: ['./customer-risk-rating-report.component.css']
})
export class CustomerRiskRatingReportComponent implements OnInit {
  row: any;
  totalTempCount=0;
  totalCount=0;
  products: any;

  crrListData: any;
  customerRisk:any
  dtInputFields:any
  constructor(private route: ActivatedRoute, private service: Customer360Service,private router: Router) {
    this.route.queryParams.subscribe(
      params => {
        this.row = params['row'];
        this.totalCount = params['count']
        this.totalTempCount = this.totalCount
      })
    this.getEmployeeList();

  }

  ngOnInit() {

  }
  getEmployeeList(event?:any) {
    let event2: any = 0;
    if (event)
      event2 = event.first;
    let crr
    if (this.row ==0) {
      crr = "H"
      this.customerRisk="High"
    }
    else if (this.row == 1) {
      crr = "M"
      this.customerRisk="Medium"
    }
    else if (this.row == 2) {
      crr = "L"
      this.customerRisk="Low"
    }
    this.crrListData = []
    this.service.getCrrData(crr,event2,this.dtInputFields).subscribe((res: any) => {
      this.crrListData = res.listData;
      if (res.totalCount) {
        this.totalCount = res.totalCount
      } else {
        this.totalCount = this.totalTempCount
      }
      this.crrListData.forEach((ele2: any) => {
        ele2.fullName = ((ele2.firstName ? ele2.firstName + " " : "")
          .concat(ele2.middleName ? ele2.middleName + " " : "")
          .concat(ele2.lastName ? ele2.lastName : ""))
          .trim();
      });
    });
  
  }

  navigateToRiskRating(customerId: string, accountId: string) {
    this.router.navigate(['pages/risk_rating'], { queryParams: { customerId, accountId } });
  }
}
