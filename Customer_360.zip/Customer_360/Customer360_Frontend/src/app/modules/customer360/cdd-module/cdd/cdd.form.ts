import { DatePipe } from "@angular/common";
import { Injectable } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import * as moment from "moment";
import { CommonService } from "src/app/common-use/common.service";
import { FieldsConfig } from "src/app/services/fields.config";
import { ValidationService } from "src/app/services/validationService";
import { ValidationInterface } from "../../../../common-use/commonInterface";
import { Regex } from "src/app/common-use/staticData";


@Injectable({
    providedIn: 'root'
})

export class CddForms {

    datePipe: any = new DatePipe('en-US')

    constructor(private commonSer: CommonService) { }

    public configFile = FieldsConfig.appConfigData.pages.cddPage;

    personalForm: FormGroup = new FormGroup({
        salutation: new FormControl({ value: null, disabled: !this.configFile.personalForm.salutation.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.personalForm.salutation.error))]),
        shortName: new FormControl({ value: null, disabled: !this.configFile.personalForm.shortName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.personalForm.shortName.error))]),
        age: new FormControl({ value: null, disabled: !this.configFile.personalForm.age.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.personalForm.age.error))]),
        lastName: new FormControl({ value: null, disabled: !this.configFile.personalForm.lastName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.personalForm.lastName.error))]),
        dateOfBirthAd: new FormControl({ value: null, disabled: !this.configFile.personalForm.dateOfBirthAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.personalForm.dateOfBirthAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        firstName: new FormControl({ value: null, disabled: !this.configFile.personalForm.firstName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.personalForm.firstName.error))]),
        middleName: new FormControl({ value: null, disabled: !this.configFile.personalForm.middleName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.personalForm.middleName.error))]),
        nationality: new FormControl({ value: null, disabled: !this.configFile.personalForm.nationality.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.personalForm.nationality.error))]
        ),
        gender: new FormControl({ value: null, disabled: !this.configFile.personalForm.gender.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHABET_REGEX, this.configFile.personalForm.gender.error))]),
        residence: new FormControl({ value: null, disabled: !this.configFile.personalForm.residence.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHABET_REGEX, this.configFile.personalForm.residence.error))]),
        maritalStatus: new FormControl({ value: null, disabled: !this.configFile.personalForm.maritalStatus.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHABET_REGEX, this.configFile.personalForm.maritalStatus.error))]),
        ),
        educationLevel: new FormControl({ value: null, disabled: !this.configFile.personalForm.educationLevel.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHABET_REGEX, this.configFile.personalForm.educationLevel.error))]
        ),
        dateOfBirthBs: new FormControl({ value: null, disabled: !this.configFile.personalForm.dateOfBirthBs.editable }),
    })

    entityForm: FormGroup = new FormGroup({
        fullName: new FormControl({ value: null, disabled: !this.configFile.entityForm.fullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.entityForm.fullName.error))]),
        shortName: new FormControl({ value: null, disabled: !this.configFile.entityForm.shortName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.entityForm.shortName.error))]),
        dateOfEstablismentAd: new FormControl({ value: null, disabled: !this.configFile.entityForm.dateOfEstablismentAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.entityForm.dateOfEstablismentAd.error, null, null, new Date(1500, 0, 1), new Date()))]),
        dateOfEstablismentBs: new FormControl({ value: null, disabled: !this.configFile.entityForm.dateOfEstablismentBs.editable }),
        typeOfIndustry: new FormControl({ value: null, disabled: !this.configFile.entityForm.typeOfIndustry.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.entityForm.typeOfIndustry.error))]
        ),
        businessList: new FormControl({ value: null, disabled: !this.configFile.entityForm.businessList.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.entityForm.businessList.error))]
        ),
        incorporationNumber: new FormControl({ value: null, disabled: !this.configFile.entityForm.incorporationNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.INCORPORATION_NUMBER_REGEX, this.configFile.entityForm.incorporationNumber.error))]),
        incorporationDate: new FormControl({ value: null, disabled: !this.configFile.entityForm.incorporationDate.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.entityForm.incorporationDate.error, null, null, new Date(1500, 0, 1), new Date()))]),
        incorporatingBody: new FormControl({ value: null, disabled: !this.configFile.entityForm.incorporatingBody.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.entityForm.incorporatingBody.error))]),
        incorporatingCountry: new FormControl({ value: null, disabled: !this.configFile.entityForm.incorporatingCountry.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.entityForm.incorporatingCountry.error))]
        ),
        panNumber: new FormControl({ value: null, disabled: !this.configFile.entityForm.panNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.INDIAN_PAN_REGEX, this.configFile.entityForm.panNumber.error))]),
        panIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.entityForm.panIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.personalForm.dateOfBirthAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        panIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.entityForm.panIssueDateBs.editable })
    })

    identificationForm: FormGroup = new FormGroup({
        id: new FormControl(null),
        identificationDocType: new FormControl({ value: null, disabled: !this.configFile.identificationForm.identificationDocType.editable }),
        identificationDocNumber: new FormControl({ value: null, disabled: !this.configFile.identificationForm.identificationDocNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.identificationForm.identificationDocNumber.error))]),
        identificationDocIssuedDateAd: new FormControl({ value: null, disabled: !this.configFile.identificationForm.identificationDocIssuedDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.identificationForm.identificationDocIssuedDateAd.error, null, null, new Date(1500, 0, 1), new Date()))]),
        identificationDocIssuedDateSb: new FormControl({ value: null, disabled: !this.configFile.identificationForm.identificationDocIssuedDateBs.editable }),
        idenificationDocIssuedBy: new FormControl({ value: null, disabled: !this.configFile.identificationForm.idenificationDocIssuedBy.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.identificationForm.idenificationDocIssuedBy.error))]),
        countryOfIssue: new FormControl({ value: null, disabled: !this.configFile.identificationForm.countryOfIssue.editable }),
        expiredDateBs: new FormControl({ value: null, disabled: !this.configFile.identificationForm.expiredDateBs.editable }),
        expiredDateAd: new FormControl({ value: null, disabled: !this.configFile.identificationForm.expiredDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.identificationForm.expiredDateAd.error, null, null, new Date(1500, 0, 1), new Date(2100, 0, 1)))]),
    })

    addressForm: FormGroup = new FormGroup({
        mobileNumber: new FormControl({ value: null, disabled: !this.configFile.addressForm.mobileNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_REGEX, this.configFile.addressForm.mobileNumber.error))]
        ),
        currentCountry: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.currentCountry.error))]
        ),
        currentProvince: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.currentProvince.error))]
        ),
        currentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.currentHouseNumber.error))]
        ),
        currentDistrict: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.currentDistrict.error))]
        ),
        landLineNumber: new FormControl({ value: null, disabled: !this.configFile.addressForm.landLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.addressForm.landLineNumber.error))]
        ),
        currentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.addressForm.currentGooglePlusCode.error))]
        ),
        currentWard: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.addressForm.currentWard.error))]
        ),
        currentTole: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.currentTole.error))]
        ),
        currentState: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.currentState.error))]
        ),
        currentMnVdcCity: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentMnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.currentMnVdcCity.error))]
        ),
        parmanentCountry: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.parmanentCountry.error))]
        ),
        parmanentProvince: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.parmanentProvince.error))]
        ),
        parmanentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.parmanentHouseNumber.error))]
        ),
        parmanentzipCode: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.parmanentzipCode.error))]
        ),
        currentzipCode: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.currentzipCode.error))]
        ),
        parmanentDistrict: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.parmanentDistrict.error))]
        ),
        parmanentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.addressForm.parmanentGooglePlusCode.error))]
        ),
        parmanentWard: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.addressForm.parmanentWard.error))]
        ),
        parmanentTole: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.addressForm.parmanentTole.error))]
        ),
        parmanentState: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.parmanentState.error))]
        ),
        emailAddress: new FormControl({ value: null, disabled: !this.configFile.addressForm.emailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.addressForm.emailAddress.error))]
        ),
        website: new FormControl({ value: null, disabled: !this.configFile.addressForm.website.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.WEBSITE_REGEX, this.configFile.addressForm.website.error))]
        ),
        parmanentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.parmanentmnVdcCity.error))]
        ),
        parmanentCountryCode: new FormControl({ value: null, disabled: !this.configFile.addressForm.parmanentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.parmanentCountryCode.error))]
        ),
        currentCountryCode: new FormControl({ value: null, disabled: !this.configFile.addressForm.currentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.addressForm.currentCountryCode.error))]
        ),
        accountId: new FormControl({ value: null, disabled: !this.configFile.addressForm.accountId.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_REGEX, this.configFile.addressForm.accountId.error))]
        ),
    })

    accountForm: FormGroup = new FormGroup({
        upperLimitOnLoanAccounts: new FormControl({ value: null, disabled: !this.configFile.accountForm.upperLimitOnLoanAccounts.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_COMMA_DOT_REGEX, this.configFile.accountForm.upperLimitOnLoanAccounts.error))]),
        relatedPersonalType: new FormControl({ value: null, disabled: !this.configFile.accountForm.relatedPersonalType.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.accountForm.relatedPersonalType.error))]),
        estimatedMonthlyIncome: new FormControl({ value: null, disabled: !this.configFile.accountForm.estimatedMonthlyIncome.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_COMMA_DOT_REGEX, this.configFile.accountForm.estimatedMonthlyIncome.error))]),
        estimatedAnnualIncome: new FormControl({ value: null, disabled: !this.configFile.accountForm.estimatedAnnualIncome.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_COMMA_DOT_REGEX, this.configFile.accountForm.estimatedAnnualIncome.error))]),
        estimatedAnnualTurnover: new FormControl({ value: null, disabled: !this.configFile.accountForm.estimatedAnnualTurnover.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_COMMA_DOT_REGEX, this.configFile.accountForm.estimatedAnnualTurnover.error))]),
        accountCurrency: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountCurrency.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.accountForm.accountCurrency.error))]),
        accountStatusType: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountStatusType.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.accountForm.accountStatusType.error))]),
        purposeOfAccount: new FormControl({ value: null, disabled: !this.configFile.accountForm.purposeOfAccount.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.accountForm.purposeOfAccount.error))]),
        accountOpeningDate: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountOpeningDate.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.accountForm.accountOpeningDate.error, null, null, new Date(1500, 0, 1), new Date()))]),
        accountAge: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountAge.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_REGEX, this.configFile.accountForm.accountAge.error))]),
        accountBranch: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountBranch.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.accountForm.accountBranch.error))]),
        accountType: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountType.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.accountForm.accountType.error))]),
        accountName: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.accountForm.accountName.error))]),
        accountNumber: new FormControl({ value: null, disabled: !this.configFile.accountForm.accountNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_REGEX, this.configFile.accountForm.accountNumber.error))]),
    })

    revenueForm: FormGroup = new FormGroup({
        nameOfTheEmployer: new FormControl({ value: null, disabled: !this.configFile.revenueForm.nameOfTheEmployer.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.revenueForm.nameOfTheEmployer.error))]),
        designation: new FormControl({ value: null, disabled: !this.configFile.revenueForm.designation.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.designation.error))]),
        employerLineOfBusiness: new FormControl({ value: null, disabled: !this.configFile.revenueForm.employerLineOfBusiness.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.revenueForm.employerLineOfBusiness.error))]),
        title: new FormControl({ value: null, disabled: !this.configFile.revenueForm.title.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.title.error))]),
        workExperience: new FormControl({ value: null, disabled: !this.configFile.revenueForm.workExperience.editable }),
        department: new FormControl({ value: null, disabled: !this.configFile.revenueForm.department.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.department.error))]),
        regularSourceOfIncome: new FormControl({ value: null, disabled: !this.configFile.revenueForm.regularSourceOfIncome.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.regularSourceOfIncome.error))]),
        sourceOfWealth: new FormControl({ value: null, disabled: !this.configFile.revenueForm.sourceOfWealth.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.sourceOfWealth.error))]),
        netWorth: new FormControl({ value: null, disabled: !this.configFile.revenueForm.netWorth.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_COMMA_DOT_REGEX, this.configFile.revenueForm.netWorth.error))]),
        panNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.panNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.INDIAN_PAN_REGEX, this.configFile.revenueForm.panNumber.error))]),
        employersContactNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.employersContactNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_REGEX, this.configFile.revenueForm.employersContactNumber.error))]),
        city: new FormControl({ value: null, disabled: !this.configFile.revenueForm.city.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.city.error))]),
        country: new FormControl({ value: null, disabled: !this.configFile.revenueForm.country.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.country.error))]),
        state: new FormControl({ value: null, disabled: !this.configFile.revenueForm.state.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.state.error))]),
        nameOfBusiness: new FormControl({ value: null, disabled: !this.configFile.revenueForm.nameOfBusiness.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.revenueForm.nameOfBusiness.error))]),
        typeOfBusiness: new FormControl({ value: null, disabled: !this.configFile.revenueForm.typeOfBusiness.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.revenueForm.typeOfBusiness.error))]),
        lineOfBusiness: new FormControl({ value: null, disabled: !this.configFile.revenueForm.lineOfBusiness.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.revenueForm.lineOfBusiness.error))]),
        contactNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.contactNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NUMERIC_REGEX, this.configFile.revenueForm.contactNumber.error))]),
        nameOfProvider: new FormControl({ value: null, disabled: !this.configFile.revenueForm.nameOfProvider.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.nameOfProvider.error))]),
        sourceOfIncomeOfTheProvider: new FormControl({ value: null, disabled: !this.configFile.revenueForm.sourceOfIncomeOfTheProvider.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ENTERPRISE_NAME_REGEX, this.configFile.revenueForm.sourceOfIncomeOfTheProvider.error))]),
        status: new FormControl({ value: null, disabled: !this.configFile.revenueForm.status.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.status.error))]),
        parmanentLandlineNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentLandlineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.parmanentLandlineNumber.error))]),
        parmanentCountry: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentCountry.error))]),
        parmanentProvince: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentProvince.error))]),
        parmanentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.revenueForm.parmanentHouseNumber.error))]),
        parmanentzipCode: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.revenueForm.parmanentzipCode.error))]),
        parmanentDistrict: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentDistrict.error))]),
        parmanentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.parmanentLandLineNumber.error))]),
        parmanentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.revenueForm.parmanentGooglePlusCode.error))]),
        parmanentWard: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.revenueForm.parmanentWard.error))]),
        parmanentMobileNumber: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentMobileNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.revenueForm.parmanentMobileNumber.error))]),
        parmanentTole: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentTole.error))]),
        parmanentState: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentState.error))]),
        parmanentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.revenueForm.parmanentEmailAddress.error))]),
        parmanentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentmnVdcCity.error))]),
        parmanentCountryCode: new FormControl({ value: null, disabled: !this.configFile.revenueForm.parmanentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.revenueForm.parmanentCountryCode.error))]),

    })

    familyForm: FormGroup = new FormGroup({
        motherName: new FormControl({ value: null, disabled: !this.configFile.familyForm.motherName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.motherName.error))]),
        fatherName: new FormControl({ value: null, disabled: !this.configFile.familyForm.fatherName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.fatherName.error))]),
        grandMotherName: new FormControl({ value: null, disabled: !this.configFile.familyForm.grandMotherName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.grandMotherName.error))]),
        grandFatherName: new FormControl({ value: null, disabled: !this.configFile.familyForm.grandFatherName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.grandFatherName.error))]),
        spouseName: new FormControl({ value: null, disabled: !this.configFile.familyForm.spouseName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.spouseName.error))]),
        daughterFullName: new FormControl({ value: null, disabled: !this.configFile.familyForm.daughterFullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.daughterFullName.error))]),
        sonFullName: new FormControl({ value: null, disabled: !this.configFile.familyForm.sonFullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.sonFullName.error))]),
        daughterFullName2: new FormControl({ value: null, disabled: !this.configFile.familyForm.daughterFullName2.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.daughterFullName2.error))]),
        sonFullName2: new FormControl({ value: null, disabled: !this.configFile.familyForm.sonFullName2.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.familyForm.sonFullName2.error))]),
    })

    nomineeForm: FormGroup = new FormGroup({
        fullName: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.fullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.fullName.error))]),
        relationship: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.relationship.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.relationship.error))]),
        contactNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.contactNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.nomineeForm.contactNumber.error))]),
        dateOfBirthAd: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.dateOfBirthAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.dateOfBirthAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        dateOfBirthBs: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.dateOfBirthBs.editable }),
        tPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.nomineeForm.tPrimaryIdType.error))]
        ),
        pPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.nomineeForm.pPrimaryIdType.error))]
        ),
        pPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.nomineeForm.pPrimaryIdNumber.error))]),
        tPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.nomineeForm.tPrimaryIdNumber.error))]),
        pIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.pIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pIssueDateBs.editable }),
        pIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.pIssuseCountry.error))]),
        tIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.tIssuseCountry.error))]),
        tToleAddress: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tToleAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.nomineeForm.tToleAddress.error))]),
        selectedNominee: new FormControl(null),
        tIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tIssueDateBs.editable }),
        tIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.tIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.pIssueAuthority.error))]),
        tIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.tIssueAuthority.error))]),
        currentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.nomineeForm.currentHouseNumber.error))]),
        currentDistrict: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentDistrict.error))]),
        currentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.currentLandLineNumber.error))]),
        currentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.currentGooglePlusCode.error))]),
        currentWard: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.nomineeForm.currentWard.error))]),
        currentTole: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentTole.error))]),
        currentState: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentState.error))]),
        currentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.nomineeForm.currentEmailAddress.error))]),
        parmanentLandlineNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentLandlineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.parmanentLandlineNumber.error))]),
        parmanentCountry: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentCountry.error))]),
        currentCountryCode: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentCountryCode.error))]),
        parmanentProvince: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentProvince.error))]),
        parmanentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.nomineeForm.parmanentHouseNumber.error))]),
        parmanentzipCode: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.nomineeForm.parmanentzipCode.error))]),
        currentzipCode: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.nomineeForm.currentzipCode.error))]),
        parmanentDistrict: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentDistrict.error))]),
        parmanentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.parmanentLandLineNumber.error))]),
        parmanentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.parmanentGooglePlusCode.error))]),
        parmanentWard: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.nomineeForm.parmanentWard.error))]),
        parmanentMobileNumber: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentMobileNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.nomineeForm.parmanentMobileNumber.error))]),
        parmanentTole: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentTole.error))]),
        parmanentState: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentState.error))]),
        parmanentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.nomineeForm.parmanentEmailAddress.error))]),
        parmanentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentmnVdcCity.error))]),
        parmanentCountryCode: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.parmanentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.parmanentCountryCode.error))]),
        pExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.pExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        pExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.pExpiryDateBs.editable }),
        tExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.nomineeForm.tExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        tExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.tExpiryDateBs.editable }),
        currentCountry: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentCountry.error))]),
        currentProvince: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentProvince.error))]),
        currentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.nomineeForm.currentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.nomineeForm.currentmnVdcCity.error))]),
        selectedAccountData: new FormControl(null),
    })

    beneficiaryForm: FormGroup = new FormGroup({
        fullName: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.fullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.fullName.error))]),
        relationship: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.relationship.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.relationship.error))]),
        contactNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.contactNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.beneficiaryForm.contactNumber.error))]),
        dateOfBirthAd: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.dateOfBirthAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.dateOfBirthAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        dateOfBirthBs: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.dateOfBirthBs.editable }),
        tPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.beneficiaryForm.tPrimaryIdType.error))]
        ),
        pPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.beneficiaryForm.pPrimaryIdType.error))]
        ),
        pPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.beneficiaryForm.pPrimaryIdNumber.error))]),
        tPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.beneficiaryForm.tPrimaryIdNumber.error))]),
        pIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.pIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pIssueDateBs.editable }),
        pIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.pIssuseCountry.error))]),
        tIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.tIssuseCountry.error))]),
        tToleAddress: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tToleAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.beneficiaryForm.tToleAddress.error))]),
        selectedBeneficiary: new FormControl(null),
        tIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tIssueDateBs.editable }),
        tIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.tIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.pIssueAuthority.error))]),
        tIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.tIssueAuthority.error))]),
        currentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.beneficiaryForm.currentHouseNumber.error))]),
        currentDistrict: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentDistrict.error))]),
        currentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.currentLandLineNumber.error))]),
        currentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.currentGooglePlusCode.error))]),
        currentWard: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.beneficiaryForm.currentWard.error))]),
        currentTole: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentTole.error))]),
        currentState: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentState.error))]),
        currentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.beneficiaryForm.currentEmailAddress.error))]),
        parmanentLandlineNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentLandlineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.parmanentLandlineNumber.error))]),
        parmanentCountry: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentCountry.error))]),
        currentCountryCode: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentCountryCode.error))]),
        parmanentProvince: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentProvince.error))]),
        parmanentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentHouseNumber.error))]),
        parmanentzipCode: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.beneficiaryForm.parmanentzipCode.error))]),
        currentzipCode: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.beneficiaryForm.currentzipCode.error))]),
        parmanentDistrict: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentDistrict.error))]),
        parmanentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.parmanentLandLineNumber.error))]),
        parmanentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.parmanentGooglePlusCode.error))]),
        parmanentWard: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.beneficiaryForm.parmanentWard.error))]),
        parmanentMobileNumber: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentMobileNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.beneficiaryForm.parmanentMobileNumber.error))]),
        parmanentTole: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentTole.error))]),
        parmanentState: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentState.error))]),
        parmanentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.beneficiaryForm.parmanentEmailAddress.error))]),
        parmanentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentmnVdcCity.error))]),
        parmanentCountryCode: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.parmanentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.parmanentCountryCode.error))]),
        pExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.pExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        pExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.pExpiryDateBs.editable }),
        tExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.beneficiaryForm.tExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        tExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.tExpiryDateBs.editable }),
        currentCountry: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentCountry.error))]),
        currentProvince: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentProvince.error))]),
        currentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.beneficiaryForm.currentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.beneficiaryForm.currentmnVdcCity.error))]),
        selectedAccountData: new FormControl(null),
    })

    signatoriesForm: FormGroup = new FormGroup({
        fullName: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.fullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.fullName.error))]),
        relationship: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.relationship.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.relationship.error))]),
        contactNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.contactNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.signatoriesForm.contactNumber.error))]),
        dateOfBirthAd: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.dateOfBirthAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.dateOfBirthAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        dateOfBirthBs: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.dateOfBirthBs.editable }),
        tPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.signatoriesForm.tPrimaryIdType.error))]
        ),
        pPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.signatoriesForm.pPrimaryIdType.error))]
        ),
        pPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.signatoriesForm.pPrimaryIdNumber.error))]),
        tPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.signatoriesForm.tPrimaryIdNumber.error))]),
        pIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.pIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pIssueDateBs.editable }),
        pIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.pIssuseCountry.error))]),
        tIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.tIssuseCountry.error))]),
        tToleAddress: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tToleAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.signatoriesForm.tToleAddress.error))]),
        selectedSignatories: new FormControl(null),
        tIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tIssueDateBs.editable }),
        tIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.tIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.pIssueAuthority.error))]),
        tIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.tIssueAuthority.error))]),
        currentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.signatoriesForm.currentHouseNumber.error))]),
        currentDistrict: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentDistrict.error))]),
        currentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.currentLandLineNumber.error))]),
        currentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.currentGooglePlusCode.error))]),
        currentWard: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.signatoriesForm.currentWard.error))]),
        currentTole: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentTole.error))]),
        currentState: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentState.error))]),
        currentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.signatoriesForm.currentEmailAddress.error))]),
        parmanentLandlineNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentLandlineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.parmanentLandlineNumber.error))]),
        parmanentCountry: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentCountry.error))]),
        currentCountryCode: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentCountryCode.error))]),
        parmanentProvince: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentProvince.error))]),
        parmanentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.signatoriesForm.parmanentHouseNumber.error))]),
        parmanentzipCode: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.signatoriesForm.parmanentzipCode.error))]),
        currentzipCode: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.signatoriesForm.currentzipCode.error))]),
        parmanentDistrict: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentDistrict.error))]),
        parmanentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.parmanentLandLineNumber.error))]),
        parmanentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.parmanentGooglePlusCode.error))]),
        parmanentWard: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.signatoriesForm.parmanentWard.error))]),
        parmanentMobileNumber: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentMobileNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.signatoriesForm.parmanentMobileNumber.error))]),
        parmanentTole: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentTole.error))]),
        parmanentState: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentState.error))]),
        parmanentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.signatoriesForm.parmanentEmailAddress.error))]),
        parmanentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentmnVdcCity.error))]),
        parmanentCountryCode: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.parmanentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.parmanentCountryCode.error))]),
        pExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.pExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        pExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.pExpiryDateBs.editable }),
        tExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.signatoriesForm.tExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        tExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.tExpiryDateBs.editable }),
        currentCountry: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentCountry.error))]),
        currentProvince: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentProvince.error))]),
        currentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.signatoriesForm.currentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.signatoriesForm.currentmnVdcCity.error))]),
        selectedAccountData: new FormControl(null),
    })

    directorsForm: FormGroup = new FormGroup({
        fullName: new FormControl({ value: null, disabled: !this.configFile.directorsForm.fullName.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.fullName.error))]),
        relationship: new FormControl({ value: null, disabled: !this.configFile.directorsForm.relationship.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.relationship.error))]),
        contactNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.contactNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.directorsForm.contactNumber.error))]),
        dateOfBirthAd: new FormControl({ value: null, disabled: !this.configFile.directorsForm.dateOfBirthAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.dateOfBirthAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        dateOfBirthBs: new FormControl({ value: null, disabled: !this.configFile.directorsForm.dateOfBirthBs.editable }),
        tPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.directorsForm.tPrimaryIdType.error))]
        ),
        pPrimaryIdType: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pPrimaryIdType.editable },
            // [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex., this.configFile.directorsForm.pPrimaryIdType.error))]
        ),
        pPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.directorsForm.pPrimaryIdNumber.error))]),
        tPrimaryIdNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tPrimaryIdNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.directorsForm.tPrimaryIdNumber.error))]),
        pIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.pIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pIssueDateBs.editable }),
        pIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.pIssuseCountry.error))]),
        tIssuseCountry: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tIssuseCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.tIssuseCountry.error))]),
        tToleAddress: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tToleAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.directorsForm.tToleAddress.error))]),
        selectedDirector: new FormControl(null),
        tIssueDateBs: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tIssueDateBs.editable }),
        tIssueDateAd: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tIssueDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.tIssueDateAd.error, null, null, new Date(1900, 0, 1), new Date()))]),
        pIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.pIssueAuthority.error))]),
        tIssueAuthority: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tIssueAuthority.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.tIssueAuthority.error))]),
        currentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.directorsForm.currentHouseNumber.error))]),
        currentDistrict: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentDistrict.error))]),
        currentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.currentLandLineNumber.error))]),
        currentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.currentGooglePlusCode.error))]),
        currentWard: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.directorsForm.currentWard.error))]),
        currentTole: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentTole.error))]),
        currentState: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentState.error))]),
        currentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.directorsForm.currentEmailAddress.error))]),
        parmanentLandlineNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentLandlineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.parmanentLandlineNumber.error))]),
        parmanentCountry: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentCountry.error))]),
        currentCountryCode: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentCountryCode.error))]),
        parmanentProvince: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentProvince.error))]),
        parmanentHouseNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentHouseNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_NUMERIC_SPACE_REGEX, this.configFile.directorsForm.parmanentHouseNumber.error))]),
        parmanentzipCode: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.directorsForm.parmanentzipCode.error))]),
        currentzipCode: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentzipCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.UNIVERSAL_ZIP_CODE_REGEX, this.configFile.directorsForm.currentzipCode.error))]),
        parmanentDistrict: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentDistrict.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentDistrict.error))]),
        parmanentLandLineNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentLandLineNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.parmanentLandLineNumber.error))]),
        parmanentGooglePlusCode: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentGooglePlusCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.parmanentGooglePlusCode.error))]),
        parmanentWard: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentWard.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.NEPALI_WARD_REGEX, this.configFile.directorsForm.parmanentWard.error))]),
        parmanentMobileNumber: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentMobileNumber.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.MOBILE_NUMBER_REGEX, this.configFile.directorsForm.parmanentMobileNumber.error))]),
        parmanentTole: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentTole.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentTole.error))]),
        parmanentState: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentState.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentState.error))]),
        parmanentEmailAddress: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentEmailAddress.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.EMAIL_REGEX, this.configFile.directorsForm.parmanentEmailAddress.error))]),
        parmanentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentmnVdcCity.error))]),
        parmanentCountryCode: new FormControl({ value: null, disabled: !this.configFile.directorsForm.parmanentCountryCode.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.parmanentCountryCode.error))]),
        pExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.pExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        pExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.directorsForm.pExpiryDateBs.editable }),
        tExpiryDateAd: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tExpiryDateAd.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.directorsForm.tExpiryDateAd.error, null, null, new Date(1900, 0, 1), new Date(2100, 0, 1)))]),
        tExpiryDateBs: new FormControl({ value: null, disabled: !this.configFile.directorsForm.tExpiryDateBs.editable }),
        currentCountry: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentCountry.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentCountry.error))]),
        currentProvince: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentProvince.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentProvince.error))]),
        currentmnVdcCity: new FormControl({ value: null, disabled: !this.configFile.directorsForm.currentmnVdcCity.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ALPHA_SPACE_REGEX, this.configFile.directorsForm.currentmnVdcCity.error))]),
        selectedAccountData: new FormControl(null),
    })

    otherForm: FormGroup = new FormGroup({
        serviceAvailed: new FormControl({ value: null, disabled: !this.configFile.otherForm.serviceAvailed.editable }),
        customerLiabilityReport: new FormControl({ value: null, disabled: !this.configFile.otherForm.customerLiabilityReport.editable}),
        otherReport: new FormControl({ value: null, disabled: !this.configFile.otherForm.otherReport.editable },
            [Validators.required, (control: FormControl) => ValidationService.validate(control, this.patchValue(false, Regex.ANY_REGEX, this.configFile.otherForm.otherReport.error))]),
    })

    adToBsDateConverter(adDate: string): string {
        adDate = this.datePipe.transform(adDate, 'dd/MM/yyyy') || ''; // Add null check and fallback value
        const adMoment = moment(adDate, 'DD/MM/YYYY');
        const adYear = adMoment.year();
        const adMonth = adMoment.month() + 1; // Moment.js months are zero-based
        const adDay = adMoment.date();
        // Perform the conversion to BS
        const bsYear = adYear - 57; // AD to BS year offset
        const bsMonth = adMonth + 8; // AD to BS month offset
        const bsDay = adDay + 16; // AD to BS day offset
        // Create a Moment.js object for the BS date
        const bsMoment = moment({ year: bsYear, month: bsMonth - 1, date: bsDay });
        // Format the BS date as dd/mm/yyyy
        const bsDate = bsMoment.format('DD/MM/YYYY');
        return bsDate;
    }

    patchFormData(data: any) {

        this.personalForm.patchValue({
            salutation: data.customerProfile?.title || '',
            shortName: data.customerProfile?.alias || '',
            age: this.calculateAge(data.customerProfile?.dateOfBirth),
            lastName: data.customerProfile?.lastName || '',
            dateOfBirthAd: this.datePipe.transform(data.customerProfile?.dateOfBirth, 'dd/MM/yyyy') || '',
            dateOfBirthBs: data.customerProfile?.dateOfBirth ? this.commonSer.adtobs(this.datePipe.transform(data.customerProfile?.dateOfBirth, 'dd/MM/yyyy')) : '',
            firstName: data.customerProfile?.firstName || '',
            middleName: data.customerProfile?.middleName || '',
            nationality: data.customerProfile?.nationality || '',
            gender: data.customerProfile?.sex || '',
            residence: data.customerProfile?.residence || '',
            maritalStatus: data.customerProfile?.maritalStatusDiscription || '',
            educationLevel: data.customerProfile?.educationLevel || ''
        });
        
        
        this.entityForm.patchValue({
            fullName: (data.customerProfile?.firstName ? data.customerProfile.firstName : "") + " " +
                (data.customerProfile?.middleName ? data.customerProfile.middleName : "") + " " +
                (data.customerProfile?.lastName ? data.customerProfile.lastName : ""),
            shortName: data.customerProfile?.alias || '',
            dateOfEstablismentAd: this.datePipe.transform(data.customerProfile?.dateOfBirth, 'dd/MM/yyyy') || '',
            typeOfIndustry: data.customerProfile?.typeOfBusiness,
            dateOfEstablismentBs: this.commonSer.adtobs(this.datePipe.transform(data.customerProfile?.dateOfBirth, 'dd/MM/yyyy')) || '',
            businessList: data.customerProfile?.accountRelation || '',
            incorporationNumber: data.customerProfile?.incorporationNumber || '',
            incorporatingBody: data.customerProfile?.incoprporationIssuedBy || '',
            incorporatingCountry: data.customerProfile?.incoporationIssuedCountry || '',
            panNumber: data.customerProfile?.panNo || '',
            panIssueDateAd: this.datePipe.transform(data.customerProfile?.panIssueDate, 'dd/MM/yyyy') || '',
            panIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(data.customerProfile?.panIssueDate, 'dd/MM/yyyy')) || ''
        });

        this.addressForm.patchValue({
            landLineNumber: data.customerProfile && data.customerProfile.landlineNumber ? data.customerProfile.landlineNumber : '',
            mobileNumber: data.customerProfile && data.customerProfile.mobileNumber ? data.customerProfile.mobileNumber : '',
            emailAddress: data.customerProfile && data.customerProfile.emailId ? data.customerProfile.emailId : '',
            website: data.customerProfile && data.customerProfile.website ? data.customerProfile.website : '',
            currentHouseNumber: data.address && data.address.address1 ? data.address.address1 : '',
            currentTole: data.address && data.address.address2 ? data.address.address2 : '',
            currentWard: data.address && data.address.address3 ? data.address.address3 : '',
            currentDistrict: data.address && data.address.address4 ? data.address.address4 : '',
            currentmnVdcCity: data.address && data.address.pcityName ? data.address.pcityName : '',
            currentCountry: data.address && data.address.country ? data.address.country : '',
            currentProvince: data.address && data.address.state ? data.address.state : '',
            currentCountryCode: data.address && data.address.country ? data.address.country : '',
            currentGooglePlusCode: data.address && data.address.GPlusCode ? data.address.GPlusCode : '',
            currentMnVdcCity: data.address && data.address.cityName ? data.address.cityName : '',
            parmanentHouseNumber: data.address && data.address.PAddress1 ? data.address.PAddress1 : '',
            parmanentTole: data.address && data.address.PAddress2 ? data.address.PAddress2 : '',
            parmanentWard: data.address && data.address.PAddress3 ? data.address.PAddress3 : '',
            parmanentDistrict: data.address && data.address.PAddress4 ? data.address.PAddress4 : '',
            parmanentmnVdcCity: data.address && data.address.PCityName ? data.address.PCityName : '',
            parmanentProvince: data.address && data.address.PState ? data.address.PState : '',
            parmanentCountry: data.address && data.address.PCountry ? data.address.PCountry : '',
            parmanentCountryCode: data.address && data.address.PCountry ? data.address.PCountry : '',
            parmanentGooglePlusCode: data.address && data.address.pgPlusCode ? data.address.pgPlusCode : '',
            parmanentzipCode: data.address && data.address.PZipcode ? data.address.PZipcode : '',
            currentzipCode: data.address && data.address.zipcode ? data.address.zipcode : '',
        });

        this.revenueForm.patchValue({
            nameOfTheEmployer: data.customerProfile?.nameOfTheEmployer || '',
            designation: data.customerProfile?.designation || '',
            employerLineOfBusiness: data.customerProfile?.nameOfBusiness || '',
            workExperience: data.customerProfile?.workExperience ? data.customerProfile.workExperience+ " months" : '',
            department: data.customerProfile?.department || '',
            regularSourceOfIncome: data.customerProfile?.sourceOfIncome || '',
            sourceOfWealth: data.customerProfile?.sourceOfWealth || '',
            netWorth: this.commonSer.formatValue(data.customerProfile?.netWorth) || '',
            panNumber: data.customerProfile?.panNo || '',
            employersContactNumber: data.customerProfile?.employersContactNumber || '',
            parmanentHouseNumber: data.address ? data.address.empAddress1 : '',
            parmanentTole: data.address ? data.address.empAddress2 : '',
            parmanentWard: data.address ? data.customerProfile.empAddress3 : '',
            parmanentDistrict: data.address ? data.address.empAddress4 : '',
            parmanentmnVdcCity: data.address ? data.address.empCityName : '',
            parmanentProvince: data.address ? data.address.empState : '',
            parmanentCountry: data.address ? data.address.empCountry : '',
            parmanentCountryCode: data.address ? data.address.empCountry : '',
            parmanentGooglePlusCode: data.address ? data.address.empgPlusCode : '',
            parmanentzipCode: data.address ? data.address.empZipcode : '',
            nameOfBusiness: data.customerProfile?.nameOfBusiness || '',
            typeOfBusiness: data.customerProfile?.typeOfBusiness || '',
            lineOfBusiness: data.customerProfile?.nameOfBusiness || '',
            contactNumber: data.customerProfile?.mobileNumber || '',
            sourceOfIncomeOfTheProvider: data.customerProfile?.sourceOfIncome || '',
        });

        this.familyForm.patchValue({
            fatherName: data.customerProfile?.fatherName ? data.customerProfile.fatherName : "",
            motherName: data.customerProfile?.motherName ? data.customerProfile.motherName : "",
            spouseName: data.customerProfile?.spouseName ? data.customerProfile.spouseName : "",
            grandFatherName: data.customerProfile?.grandFatherName ? data.customerProfile.grandFatherName : "",
            grandMotherName: data.customerProfile?.grandMotherName ? data.customerProfile.grandMotherName:"",
            sonFullName: JSON.parse(data.customerProfile?.childName || '{}').child?.sonFullName || '',
            daughterFullName: JSON.parse(data.customerProfile?.childName || '{}').child?.daughterFullName || '',
            daughterFullName2: JSON.parse(data.customerProfile?.childName || '{}').child?.daughterFullName2 || '',
            sonFullName2: JSON.parse(data.customerProfile?.childName || '{}').child?.sonFullName2 || ''
        });

        this.otherForm.patchValue({
            serviceAvailed: data.otherInfo?.service_availed || '',
            customerLiabilityReport: data.otherInfo?.customer_liability_report || '',
            otherReport: data.otherInfo?.other_report || ''
        });
    }

    calculateAge(dateOfBirth: string): number {
        const today: Date = new Date();
        const birthDate: Date = new Date(dateOfBirth);
        let age: number = today.getFullYear() - birthDate.getFullYear();
        const monthDiff: number = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    }

    getAccountDetailsByCustIdAndAddIdPatch(data: any) {
        let accountStatusType;
        try {
            accountStatusType=data.accountStatusCode.toString();
        } catch (error) {
            
        }
        this.accountForm.patchValue({
            estimatedMonthlyIncome: this.commonSer.formatValue(data?.income/12),
            estimatedAnnualIncome: this.commonSer.formatValue(data?.income),
            estimatedAnnualTurnover: this.commonSer.formatValue(data?.turnover),
            accountStatusType: accountStatusType,
            accountCurrency: data?.currencyType || '',
            accountOpeningDate: this.datePipe.transform(data?.accountOpenDate, 'dd/MM/yyyy') || '',
            accountAge: data?.accountAge || '',
            accountBranch: data?.branchName || '',
            accountType: data?.accountType || '',
            accountName: data?.accountName || '',
            accountNumber: data?.accountId || '',
            purposeOfAccount: data?.purpose || '',
            upperLimitOnLoanAccounts: this.commonSer.formatValue(data?.overdraftLimit),
            relatedPersonalType: 'Beneficiary or Beneficial Owner',
        });
    }

    changeDocument(doc: any) {
        const identificationDocIssuedDateAd = doc ? this.datePipe.transform(doc.ID_ISSUE_DATE, 'dd/MM/yyyy') : null;
        const identificationDocIssuedDateSb = doc ? this.commonSer.adtobs(identificationDocIssuedDateAd) : null;
        const expiredDateAd = doc ? this.datePipe.transform(doc.ID_EXPIRY_DATE, 'dd/MM/yyyy') : null;
        const expiredDateBs = doc ? this.commonSer.adtobs(expiredDateAd) : null;
        this.identificationForm.patchValue({
            identificationDocType: doc ? doc.ID_TYPE : null,
            identificationDocNumber: doc ? doc.ID_NUMBER : null,
            identificationDocIssuedDateAd: identificationDocIssuedDateAd,
            identificationDocIssuedDateSb: identificationDocIssuedDateSb,
            idenificationDocIssuedBy: doc ? doc.ID_ISSUED_BY : null,
            expiredDateAd: expiredDateAd,
            expiredDateBs: expiredDateBs,
            countryOfIssue: doc ? doc.ID_ISSUE_COUNTRY : null
        });
    }
    

    changeNominee(nominee: any) {
        this.nomineeForm.patchValue({
            fullName: nominee.fullName,
            relationship: nominee.cbs_account_person_role_type,
            contactNumber: nominee.contactNumber,
            dateOfBirthAd: this.datePipe.transform(nominee.dob, 'dd/MM/yyyy'),
            pPrimaryIdType: nominee.identification_doc_type,
            pPrimaryIdNumber: nominee.identification_doc_number,
            pIssueDateAd: this.datePipe.transform(nominee.identification_doc_issued_date, 'dd/MM/yyyy'),
            pIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(nominee.identification_doc_issued_date, 'dd/MM/yyyy')),
            tPrimaryIdType: nominee.sIdentification_doc_type,
            tPrimaryIdNumber: nominee.sIdentification_doc_number,
            tIssueDateAd: this.datePipe.transform(nominee.sIdentification_doc_issued_date, 'dd/MM/yyyy'),
            tIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(nominee.sIdentification_doc_issued_date, 'dd/MM/yyyy')),
            pIssueAuthority: nominee.identification_doc_issued_by,
            tIssueAuthority: nominee.sIdenification_doc_issued_by,
            pIssuseCountry: nominee.identification_doc_issue_country,
            tIssuseCountry: nominee.sIdentification_doc_issue_country,
            dateOfBirthBs: this.commonSer.adtobs(this.datePipe.transform(nominee.dob, 'dd/MM/yyyy')),
            currentWard: nominee.taddress3,
            currentDistrict: nominee.taddress4,
            currentmnVdcCity: nominee.tCity,
            currentProvince: nominee.tState,
            currentCountry: nominee.tcountry,
            currentCountryCode: nominee.tcountry,
            currentGooglePlusCode: nominee.gPlusCode,
            parmanentHouseNumber: nominee.paddress1,
            parmanentTole: nominee.paddress2,
            parmanentWard: nominee.paddress3,
            parmanentDistrict: nominee.paddress4,
            parmanentmnVdcCity: nominee.pCity,
            parmanentProvince: nominee.pState,
            parmanentCountry: nominee.pcountry,
            parmanentCountryCode: nominee.pcountry,
            parmanentGooglePlusCode: nominee.pgPlusCode,
            parmanentzipCode: nominee.pzipcode,
            currentzipCode: nominee.tzipcode,
            pExpiryDateAd: this.datePipe.transform(nominee.identification_doc_expiry_date, 'dd/MM/yyyy'),
            pExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(nominee.identification_doc_expiry_date, 'dd/MM/yyyy')),
            tExpiryDateAd: this.datePipe.transform(nominee.sIdentification_doc_expiry_date, 'dd/MM/yyyy'),
            tExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(nominee.sIdentification_doc_expiry_date, 'dd/MM/yyyy')),
            currentHouseNumber: nominee.taddress1,
            currentTole: nominee.taddress2,
            selectedAccountData: nominee.id,


        })

    }

    changeDirectors(directors: any) {
        this.directorsForm.patchValue({
            fullName: directors.fullName,
            relationship: directors.cbs_account_person_role_type,
            contactNumber: directors.contactNumber,
            dateOfBirthAd: this.datePipe.transform(directors.dob, 'dd/MM/yyyy'),
            pCountry: directors.pcountry,
            pPrimaryIdType: directors.identification_doc_type,
            pPrimaryIdNumber: directors.identification_doc_number,
            pIssueDateAd: this.datePipe.transform(directors.identification_doc_issued_date, 'dd/MM/yyyy'),
            pIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(directors.identification_doc_issued_date, 'dd/MM/yyyy')),
            tPrimaryIdType: directors.sIdentification_doc_type,
            tPrimaryIdNumber: directors.sIdentification_doc_number,
            tIssueDateAd: this.datePipe.transform(directors.sIdentification_doc_issued_date, 'dd/MM/yyyy'),
            tIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(directors.sIdentification_doc_issued_date, 'dd/MM/yyyy')),
            pIssueAuthority: directors.identification_doc_issued_by,
            tIssueAuthority: directors.sIdenification_doc_issued_by,
            pIssuseCountry: directors.identification_doc_issue_country,
            tIssuseCountry: directors.sIdentification_doc_issue_country,
            dateOfBirthBs: this.commonSer.adtobs(this.datePipe.transform(directors.dob, 'dd/MM/yyyy')),
            currentWard: directors.taddress3,
            currentDistrict: directors.taddress4,
            currentmnVdcCity: directors.tCity,
            currentProvince: directors.tState,
            currentCountry: directors.tcountry,
            currentCountryCode: directors.tcountry,
            currentGooglePlusCode: directors.gPlusCode,
            parmanentHouseNumber: directors.paddress1,
            parmanentTole: directors.paddress2,
            parmanentWard: directors.paddress3,
            parmanentDistrict: directors.paddress4,
            parmanentmnVdcCity: directors.pCity,
            parmanentProvince: directors.pState,
            parmanentCountry: directors.pcountry,
            parmanentCountryCode: directors.pcountry,
            parmanentGooglePlusCode: directors.pgPlusCode,
            parmanentzipCode: directors.pzipcode,
            currentzipCode: directors.tzipcode,
            pExpiryDateAd: this.datePipe.transform(directors.identification_doc_expiry_date, 'dd/MM/yyyy'),
            pExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(directors.identification_doc_expiry_date, 'dd/MM/yyyy')),
            tExpiryDateAd: this.datePipe.transform(directors.sIdentification_doc_expiry_date, 'dd/MM/yyyy'),
            tExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(directors.sIdentification_doc_expiry_date, 'dd/MM/yyyy')),
            currentHouseNumber: directors.taddress1,
            currentTole: directors.taddress2,
            selectedAccountData: directors.id,

        })

    }

    changeSignatories(signatories: any) {
        this.signatoriesForm.patchValue({
            fullName: signatories.fullName,
            relationship: signatories.cbs_account_person_role_type,
            contactNumber: signatories.contactNumber,
            dateOfBirthAd: this.datePipe.transform(signatories.dob, 'dd/MM/yyyy'),
            pCountry: signatories.pcountry,
            pPrimaryIdType: signatories.identification_doc_type,
            pPrimaryIdNumber: signatories.identification_doc_number,
            pIssueDateAd: this.datePipe.transform(signatories.identification_doc_issued_date, 'dd/MM/yyyy'),
            pIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(signatories.identification_doc_issued_date, 'dd/MM/yyyy')),
            tPrimaryIdType: signatories.sIdentification_doc_type,
            tPrimaryIdNumber: signatories.sIdentification_doc_number,
            tIssueDateAd: this.datePipe.transform(signatories.sIdentification_doc_issued_date, 'dd/MM/yyyy'),
            tIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(signatories.sIdentification_doc_issued_date, 'dd/MM/yyyy')),
            pIssueAuthority: signatories.identification_doc_issued_by,
            tIssueAuthority: signatories.sIdenification_doc_issued_by,
            pIssuseCountry: signatories.identification_doc_issue_country,
            tIssuseCountry: signatories.sIdentification_doc_issue_country,
            dateOfBirthBs: this.commonSer.adtobs(this.datePipe.transform(signatories.dob, 'dd/MM/yyyy')),
            currentWard: signatories.taddress3,
            currentDistrict: signatories.taddress4,
            currentmnVdcCity: signatories.tCity,
            currentProvince: signatories.tState,
            currentCountry: signatories.tcountry,
            currentCountryCode: signatories.tcountry,
            currentGooglePlusCode: signatories.gPlusCode,
            parmanentHouseNumber: signatories.paddress1,
            parmanentTole: signatories.paddress2,
            parmanentWard: signatories.paddress3,
            parmanentDistrict: signatories.paddress4,
            parmanentmnVdcCity: signatories.pCity,
            parmanentProvince: signatories.pState,
            parmanentCountry: signatories.pcountry,
            parmanentCountryCode: signatories.pcountry,
            parmanentGooglePlusCode: signatories.pgPlusCode,
            parmanentzipCode: signatories.pzipcode,
            currentzipCode: signatories.tzipcode,
            pExpiryDateAd: this.datePipe.transform(signatories.identification_doc_expiry_date, 'dd/MM/yyyy'),
            pExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(signatories.identification_doc_expiry_date, 'dd/MM/yyyy')),
            tExpiryDateAd: this.datePipe.transform(signatories.sIdentification_doc_expiry_date, 'dd/MM/yyyy'),
            tExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(signatories.sIdentification_doc_expiry_date, 'dd/MM/yyyy')),
            currentHouseNumber: signatories.taddress1,
            currentTole: signatories.taddress2,
            selectedAccountData: signatories.id,

        })
    }

    changeBeneficiary(beneficiary: any) {
        this.beneficiaryForm.patchValue({
            fullName: beneficiary.fullName,
            relationship: beneficiary.cbs_account_person_role_type,
            contactNumber: beneficiary.contactNumber,
            dateOfBirthAd: this.datePipe.transform(beneficiary.dob, 'dd/MM/yyyy'),
            pCountry: beneficiary.pcountry,
            pPrimaryIdType: beneficiary.identification_doc_type,
            pPrimaryIdNumber: beneficiary.identification_doc_number,
            pIssueDateAd: this.datePipe.transform(beneficiary.identification_doc_issued_date, 'dd/MM/yyyy'),
            pIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(beneficiary.identification_doc_issued_date,'dd/MM/yyyy')),
            tPrimaryIdType: beneficiary.sIdentification_doc_type,
            tPrimaryIdNumber: beneficiary.sIdentification_doc_number,
            tIssueDateAd: this.datePipe.transform(beneficiary.sIdentification_doc_issued_date, 'dd/MM/yyyy'),
            tIssueDateBs: this.commonSer.adtobs(this.datePipe.transform(beneficiary.sIdentification_doc_issued_date,'dd/MM/yyyy')),
            pIssueAuthority: beneficiary.identification_doc_issued_by,
            tIssueAuthority: beneficiary.sIdenification_doc_issued_by,
            pIssuseCountry: beneficiary.identification_doc_issue_country,
            tIssuseCountry: beneficiary.sIdentification_doc_issue_country,
            dateOfBirthBs: this.commonSer.adtobs(this.datePipe.transform(beneficiary.dob, 'dd/MM/yyyy')),
            currentWard: beneficiary.taddress3,
            currentDistrict: beneficiary.taddress4,
            currentmnVdcCity: beneficiary.tCity,
            currentProvince: beneficiary.tState,
            currentCountry: beneficiary.tcountry,
            currentCountryCode: beneficiary.tcountry,
            currentGooglePlusCode: beneficiary.gPlusCode,
            parmanentHouseNumber: beneficiary.paddress1,
            parmanentTole: beneficiary.paddress2,
            parmanentWard: beneficiary.paddress3,
            parmanentDistrict: beneficiary.paddress4,
            parmanentmnVdcCity: beneficiary.pCity,
            parmanentProvince: beneficiary.pState,
            parmanentCountry: beneficiary.pcountry,
            parmanentCountryCode: beneficiary.pcountry,
            parmanentGooglePlusCode: beneficiary.pgPlusCode,
            parmanentzipCode: beneficiary.pzipcode,
            currentzipCode: beneficiary.tzipcode,
            pExpiryDateAd: this.datePipe.transform(beneficiary.identification_doc_expiry_date, 'dd/MM/yyyy'),
            pExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(beneficiary.identification_doc_expiry_date,'dd/MM/yyyy')),
            tExpiryDateAd: this.datePipe.transform(beneficiary.sIdentification_doc_expiry_date, 'dd/MM/yyyy'),
            tExpiryDateBs: this.commonSer.adtobs(this.datePipe.transform(beneficiary.sIdentification_doc_expiry_date,'dd/MM/yyyy')),
            currentHouseNumber: beneficiary.taddress1,
            currentTole: beneficiary.taddress2,
            selectedAccountData: beneficiary.id,

        })
    }

    compareFormValues(previousValueOb: any, form: FormGroup) {
        const changedValues: any = {};
        Object.keys(previousValueOb).forEach((controlName: any) => {
            const control: any = form.get(controlName);
            const previousValue = previousValueOb[controlName];
            const currentValue = control.value;
            if (previousValue != currentValue && !(previousValue == null && currentValue == "")) {
                changedValues[controlName] = {
                    oldValue: previousValue, newValue: currentValue
                }
            }
        })
        return JSON.stringify(changedValues);
    }

    separateSonAndDaughterNames(value: string, condition: any) {
        const sonRegex = /son:(\w+)/;
        const daughterRegex = /daughter:(\w+)/;

        const sonMatch = value.match(sonRegex);
        const daughterMatch = value.match(daughterRegex);

        let son = sonMatch ? sonMatch[1] : '';
        const daughter = daughterMatch ? daughterMatch[1] : '';
        if (condition == 1) {
            return son
        }
        return daughter;
    }

    patchValue(req: boolean, regex: RegExp, errorMessage: {}, maxlength?: any, minlength?: any, minDate?: Date, maxDate?: Date) {
        let validationInterface: ValidationInterface = {
            errorMessage: errorMessage,
            require: req,
            regexPattern: regex,
            minlength: (minlength !== null && minlength !== undefined) ? minlength : null,
            maxlength: (maxlength !== null && maxlength !== undefined) ? maxlength : null,
            minDate: (minDate !== null && minDate !== undefined) ? minDate : null,
            maxDate: (maxDate !== null && maxDate !== undefined) ? maxDate : null,

        };
        return validationInterface
    }


}