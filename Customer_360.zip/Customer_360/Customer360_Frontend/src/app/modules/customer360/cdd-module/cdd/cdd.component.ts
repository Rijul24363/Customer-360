import { Component, EventEmitter, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Customer360Service } from '../../services/customer360.service';
import { CommonService } from 'src/app/common-use/common.service';
import { Subscription } from 'rxjs';
import { RoleFunctionalityService } from 'src/app/services/role-functionality.service';
import { IRoleConfig } from 'src/app/services/role.interface';
import { CddForms } from './cdd.form';
import { TabView } from 'primeng/tabview';
import { SaveData } from '../../../../common-use/commonInterface';
import { ConfirmationService, MessageService } from 'primeng/api';
import { DropdownOptions } from 'src/app/common-use/staticData';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-cdd',
  templateUrl: './cdd.component.html',
  styleUrls: ['./cdd.component.css']
})
export class CDDComponent implements OnDestroy {
  @ViewChild(TabView) tabView: TabView;
  submitData = new EventEmitter<SaveData>();

  employedByOthers: boolean = false
  selfEmployed: boolean = false
  unemployed: boolean = false
  entity: boolean = false
  custID: string = ''
  selectedAccountId: any = "";
  selectedIdentictionNumber: any = "";
  //  DropdownOptions.relatedPersonalType;
  genderList = DropdownOptions.genderList;
  serviceAvailed = DropdownOptions.serviceAvailed;
  relationship = DropdownOptions.relationship;

  personalForm = this.forms.personalForm;
  entityForm = this.forms.entityForm;
  identificationForm = this.forms.identificationForm;
  addressForm = this.forms.addressForm;
  accountForm = this.forms.accountForm;
  revenueForm = this.forms.revenueForm;
  familyForm = this.forms.familyForm;
  nomineeForm = this.forms.nomineeForm;
  beneficiaryForm = this.forms.beneficiaryForm;
  signatoriesForm = this.forms.signatoriesForm;
  directorsForm = this.forms.directorsForm;
  otherForm = this.forms.otherForm;

  customerList: any = [];
  natureOfBusinessList: any = [];
  tableFilteredData: any = [];
  countryList: any = [];
  accountTypeList: any = [];
  stateList: any = [];
  employeeList: any = []
  identificationType = [];
  accountType = [];
  directorsList: any = [];
  beneficiaryList: any = [];
  signatoriesList: any = [];
  nomineeList: any = [];
  maritalStatus = []
  educationLevel = []
  currency = [];
  accIdSub: Subscription
  roleWisePage: IRoleConfig
  selectedIndex: number = 0;
  enumSub: Subscription
  listOfBusiness: any[];
  beneficiary: string = "Beneficiary";
  identificationData: any;
  relatedPersonalType = [
    { name: this.beneficiary, code: this.beneficiary },
    { name: 'Signatory', code: 'Signatory' },
    { name: 'Director', code: 'Director' },
  ];
  previousValue: any = {}
  addCBS: any = {
    beneficiary: null,
    nominiee: null,
    signatories: null,
    directors: null
  };
  constructor(private service: Customer360Service, private commonService: CommonService, private roleService: RoleFunctionalityService,
    public forms: CddForms, private confirmationService: ConfirmationService) {
    this.roleWisePage = this.roleService.roleWisePageObs.getValue()

    this.onSelectionChange(this.service.selectedCustomerData)
    this.getCustomerDetails()
    this.forms.identificationForm.reset()
    // this.getEnumsData()
    this.accIdSub = this.service.getAccountID().subscribe((res: any) => {
      this.signatoriesForm.reset();
      this.nomineeForm.reset();
      this.beneficiaryForm.reset();
      this.directorsForm.reset();
      this.selectedAccountId = res;
      this.getAccountDetailsByCustIdAndAddId(res);
      this.patchFormbasedOnAccountId(res)
    })
    this.enumSub = this.commonService.eNumList.subscribe((res: any) => {
      if (res) {
        this.accountTypeList = res.accountTypeList
        this.countryList = res.countryList
        this.accountType = res.accStatusList
        this.currency = res.currencyList
        this.maritalStatus = res.maritalStatusList
        this.identificationType = res.docTypeList
        this.educationLevel = res.educationList
        this.natureOfBusinessList = res.natureOfBusinessList
        this.listOfBusiness = res.getBusinessList
      }
    })
  }

  ngOnDestroy(): void {
    this.accIdSub.unsubscribe()
    this.enumSub.unsubscribe()
  }

  getCustomerDetails() {
    let data: any = this.service.selectedCustomerData
    if (data) {
      this.custID = data.customerId
      this.getAccountListByCustomerId()
    }
    this.service.getCustomerDetailsBaseOnCustId(this.custID).subscribe((res: any) => {
      this.customerList = res
      this.identificationData = res.identificationData
      this.forms.patchFormData(this.customerList)
      this.getPreviousValue()

    })
  }

  onSelectionChange(event: any) {
    if (event.custType == 'Non-Individual') {
      this.entity = true
      this.employedByOthers = false
      this.selfEmployed = false
      this.unemployed = false
      this.beneficiary = "Beneficial Owner";
    } else if (event.custType == 'Individual') {
      this.employedByOthers = true
      this.entity = false
      this.selfEmployed = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Employed by Others') {
      this.employedByOthers = true
      this.entity = false
      this.selfEmployed = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Self-employed') {
      this.selfEmployed = true
      this.employedByOthers = false
      this.entity = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Unemployed') {
      this.unemployed = true
      this.employedByOthers = false
      this.entity = false
      this.selfEmployed = false
      this.beneficiary = "Beneficiary";
    } else if (event.custType == 'Individual - Self-employed') {
      this.selfEmployed = true
      this.employedByOthers = false
      this.entity = false
      this.unemployed = false
      this.beneficiary = "Beneficiary";
    }
  }

  getAccountListByCustomerId() {
    this.service.setHideAccountPanel(this.custID, true, true)
  }

  getAccountDetailsByCustIdAndAddId(accId: any) {
    this.service.getAccountDetailsByCustIdAndAddId(this.custID, accId).subscribe((res: any) => {
      let res2 = res
      if (res2) {
        this.forms.getAccountDetailsByCustIdAndAddIdPatch(res2)
        this.previousValue.accountForm = this.accountForm.value;
      }

    })
  }
  patchFormbasedOnAccountId(accId: any) {
    this.service.getCddDataBasedOnAccountId(this.custID, accId).subscribe((res: any) => {
      let res2 = res
      if (res2) {
        this.directorsList = res2.directors
        this.beneficiaryList = res2.beneficiary
        this.signatoriesList = res2.signatories
        this.nomineeList = res2.nominee
        if (this.directorsList.length != 0) {
          this.directorsForm.patchValue({ selectedDirector: this.directorsList[0].id })
          this.forms.changeDirectors(this.directorsList[0])
        }
        if (this.beneficiaryList.length != 0) {
          this.beneficiaryForm.patchValue({ selectedBeneficiary: this.beneficiaryList[0].id })
          this.forms.changeBeneficiary(this.beneficiaryList[0])
        }
        if (this.signatoriesList.length != 0) {
          this.signatoriesForm.patchValue({ selectedSignatories: this.signatoriesList[0].id })
          this.forms.changeSignatories(this.signatoriesList[0])
        }
        if (this.nomineeList.length != 0) {
          this.nomineeForm.patchValue({ selectedNominee: this.nomineeList[0].id })
          this.forms.changeNominee(this.nomineeList[0])
        }
        this.previousValue.nomineeForm = this.nomineeForm.value;
        this.previousValue.beneficiaryForm = this.beneficiaryForm.value;
        this.previousValue.signatoriesForm = this.signatoriesForm.value;
        this.previousValue.directorsForm = this.directorsForm.value;
        this.previousValue.otherForm = this.otherForm.value;
      }

    })

  }

  onSubmit() {
    let changedValues = {}
    let selectedAccountData = null;

    this.confirmationService.confirm({
      message: 'Are you sure that you want to save?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        let allFormDataUpdate = new Array();
        this.tabView.tabs.forEach(element => {
          let previousValue = {};
          if (element.header == "Personal") {
            previousValue = this.previousValue.personalForm
          } else if (element.header == "Entity") {
            previousValue = this.previousValue.entityForm
          } else if (element.header == "Identification") {
            previousValue = this.previousValue.identificationForm
          }
          else if (element.header == "Address") {
            previousValue = this.previousValue.addressForm
          }
          else if (element.header == "Account") {
            previousValue = this.previousValue.accountForm
          }
          else if (element.header == "Revenue") {
            previousValue = this.previousValue.revenueForm
          }
          else if (element.header == "Family") {
            previousValue = this.previousValue.familyForm
          }
          else if (element.header == "Nominee") {
            previousValue = this.previousValue.nomineeForm
          }
          else if (element.header == this.beneficiary) {
            previousValue = this.previousValue.beneficiaryForm
          }
          else if (element.header == "Signatories") {
            previousValue = this.previousValue.signatoriesForm
          }
          else if (element.header == "Directors") {
            previousValue = this.previousValue.directorsForm
          }
          else if (element.header == "Other") {
            previousValue = this.previousValue.otherForm
          }
          this.changedValues(element.header, previousValue).then((res: any) => {
            changedValues = res.changedValues
            selectedAccountData = res.selectedAccountData
            if (changedValues != JSON.stringify({})) {
              let saveData: SaveData = {
                customerId: this.custID,
                accountId: this.selectedAccountId,
                screenName: "CDD/" + element.header,
                fieldsUpdated: changedValues,
                selectedAccountData: selectedAccountData,
                selectedIdentictionNumber: this.selectedIdentictionNumber
              }
              allFormDataUpdate.push(saveData)
            }
          })
        })
        this.service.setSaveData(allFormDataUpdate)

      }

    });

  }


  getPreviousValue() {
    this.previousValue.personalForm = this.personalForm.value;
    this.previousValue.entityForm = this.entityForm.value;
    this.previousValue.identificationForm = this.identificationForm.value;
    this.previousValue.addressForm = this.addressForm.value;
    this.previousValue.revenueForm = this.revenueForm.value;
    this.previousValue.familyForm = this.familyForm.value;
    this.previousValue.nomineeForm = this.nomineeForm.value;

  }

  refreshData() {
    this.signatoriesForm.reset();
    this.nomineeForm.reset();
    this.beneficiaryForm.reset();
    this.directorsForm.reset();
    this.addCBS = {
      beneficiary: null,
      nominiee: null,
      signatories: null,
      directors: null
    };
    this.getCustomerDetails();
    this.getAccountDetailsByCustIdAndAddId(this.selectedAccountId);
    this.patchFormbasedOnAccountId(this.selectedAccountId)
  }

  onDocumentTypeChange(event: any) {
    this.forms.identificationForm.reset()
    this.selectedIdentictionNumber = null
    if (this.identificationData.length === 0) {
      this.forms.identificationForm.patchValue({
        identificationDocType: event.code
      })
    } else {
      this.identificationData.forEach((ele: any) => {
        if (ele.ID_TYPE == event.code) {
          this.selectedIdentictionNumber = ele.ID
          this.forms.changeDocument(ele)
        } else {
          this.forms.identificationForm.patchValue({
            identificationDocType: event.code
          })
        }
      })
    }
  }


  changedValues(tabName: any, previousValue: any) {
    let changedValues = {}
    let selectedAccountData: any = null;
    return new Promise((resolve, reject) => {
      if (tabName == "Personal") {
        changedValues = this.forms.compareFormValues(previousValue, this.personalForm)
      }
      else if (tabName == "Entity") {
        changedValues = this.forms.compareFormValues(previousValue, this.entityForm)
      }
      else if (tabName == "Identification") {
        changedValues = this.forms.compareFormValues(previousValue, this.identificationForm)
      }
      else if (tabName == "Address") {
        changedValues = this.forms.compareFormValues(previousValue, this.addressForm)
      }
      else if (tabName == "Account") {
        changedValues = this.forms.compareFormValues(previousValue, this.accountForm)
      }
      else if (tabName == "Revenue") {
        changedValues = this.forms.compareFormValues(previousValue, this.revenueForm)
      }
      else if (tabName == "Family") {
        changedValues = this.forms.compareFormValues(previousValue, this.familyForm)
      }
      else if (tabName == "Nominee") {
        selectedAccountData = this.nomineeForm.value.selectedAccountData
        changedValues = this.forms.compareFormValues(previousValue, this.nomineeForm)
      }
      else if (tabName == this.beneficiary) {
        selectedAccountData = this.beneficiaryForm.value.selectedAccountData
        changedValues = this.forms.compareFormValues(previousValue, this.beneficiaryForm)
      }
      else if (tabName == "Signatories") {
        selectedAccountData = this.signatoriesForm.value.selectedAccountData
        changedValues = this.forms.compareFormValues(previousValue, this.signatoriesForm)
      }
      else if (tabName == "Directors") {
        selectedAccountData = this.directorsForm.value.selectedAccountData
        changedValues = this.forms.compareFormValues(previousValue, this.directorsForm)
      }
      else if (tabName == "Other") {
        changedValues = this.forms.compareFormValues(previousValue, this.otherForm)
      }
      resolve({ changedValues: changedValues, selectedAccountData: selectedAccountData })
    })

  }

  addNewCBS(addfor: any) {

    if (addfor == 'nominee') {
      this.addCBS.nominee = addfor
      this.nomineeForm.reset();
      this.previousValue.nomineeForm = this.nomineeForm.value;
    } else if (addfor == 'beneficiary') {
      this.addCBS.beneficiary = addfor
      this.beneficiaryForm.reset();
      this.previousValue.beneficiaryForm = this.beneficiaryForm.value;
    } else if (addfor == 'signatories') {
      this.addCBS.signatories = addfor
      this.beneficiaryForm.reset();
      this.previousValue.signatoriesForm = this.signatoriesForm.value;
    } else if (addfor == 'directors') {
      this.addCBS.directors = addfor
      this.beneficiaryForm.reset();
      this.previousValue.directorsForm = this.directorsForm.value;
    }
  }

  cancelCBS(evt: any) {
    if (evt == 'nominee') {
      this.addCBS.nominee = null;
      this.nomineeForm.reset();
      this.previousValue.nomineeForm = this.nomineeForm.value;
    } else if (evt == 'beneficiary') {
      this.addCBS.beneficiary = null;
      this.beneficiaryForm.reset();
      this.previousValue.beneficiaryForm = this.beneficiaryForm.value;
    } else if (evt == 'signatories') {
      this.addCBS.signatories = null;
      this.beneficiaryForm.reset();
      this.previousValue.signatoriesForm = this.signatoriesForm.value;
    } else if (evt == 'directors') {
      this.addCBS.directors = null;
      this.beneficiaryForm.reset();
      this.previousValue.directorsForm = this.directorsForm.value;
    }
  }

  changeDateForBS(evet: any, formName: any, formControlName: any) {
    if (formName == 'entityForm') {
      if (formControlName == 'dateOfEstablismentBs') {
        this.entityForm.patchValue({ dateOfEstablismentBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'panIssueDateBs') {
        this.entityForm.patchValue({ panIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
    }
    if (formName == 'personalForm') {
      if (formControlName == 'dateOfBirthBs') {
        this.personalForm.patchValue({ dateOfBirthBs: this.commonService.changeDateToBS(evet) });
      }
    }
    else if (formName == 'identificationForm') {
      if (formControlName == 'identificationDocIssuedDateSb') {
        this.identificationForm.patchValue({ identificationDocIssuedDateSb: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'expiredDateBs') {
        this.identificationForm.patchValue({ expiredDateBs: this.commonService.changeDateToBS(evet) });
      }
    }
    else if (formName == 'nomineeForm') {
      if (formControlName == 'dateOfBirthBs') {
        this.nomineeForm.patchValue({ dateOfBirthBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pIssueDateBs') {
        this.nomineeForm.patchValue({ pIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pExpiryDateBs') {
        this.nomineeForm.patchValue({ pExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tIssueDateBs') {
        this.nomineeForm.patchValue({ tIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tExpiryDateBs') {
        this.nomineeForm.patchValue({ tExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
    }

    else if (formName == 'beneficiaryForm') {
      if (formControlName == 'dateOfBirthBs') {
        this.beneficiaryForm.patchValue({ dateOfBirthBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pIssueDateBs') {
        this.beneficiaryForm.patchValue({ pIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pExpiryDateBs') {
        this.beneficiaryForm.patchValue({ pExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tIssueDateBs') {
        this.beneficiaryForm.patchValue({ tIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tExpiryDateBs') {
        this.beneficiaryForm.patchValue({ tExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
    }
    else if (formName == 'signatoriesForm') {
      if (formControlName == 'dateOfBirthBs') {
        this.signatoriesForm.patchValue({ dateOfBirthBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pIssueDateBs') {
        this.signatoriesForm.patchValue({ pIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pExpiryDateBs') {
        this.signatoriesForm.patchValue({ pExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tIssueDateBs') {
        this.signatoriesForm.patchValue({ tIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tExpiryDateBs') {
        this.signatoriesForm.patchValue({ tExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
    }
    else if (formName == 'directorsForm') {
      if (formControlName == 'dateOfBirthBs') {
        this.directorsForm.patchValue({ dateOfBirthBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pIssueDateBs') {
        this.directorsForm.patchValue({ pIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'pExpiryDateBs') {
        this.directorsForm.patchValue({ pExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tIssueDateBs') {
        this.directorsForm.patchValue({ tIssueDateBs: this.commonService.changeDateToBS(evet) });
      }
      if (formControlName == 'tExpiryDateBs') {
        this.directorsForm.patchValue({ tExpiryDateBs: this.commonService.changeDateToBS(evet) });
      }
    }


  }
}