import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CddRoutingModule } from './cdd-routing.module';
import { CommonUseModule } from 'src/app/common-use/common-use.module';
import { CDDComponent } from './cdd/cdd.component';
import { AuthGuard } from 'src/app/services/auth.gaurd';


@NgModule({
  declarations: [
    CDDComponent
  ],
  imports: [
    CommonModule,
    CddRoutingModule,
    CommonUseModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers:[AuthGuard]
})
export class CddModule { }
