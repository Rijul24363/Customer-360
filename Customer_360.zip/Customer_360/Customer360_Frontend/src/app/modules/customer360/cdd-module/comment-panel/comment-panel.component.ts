import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CddForms } from '../cdd/cdd.form';
import { CommonService } from 'src/app/common-use/common.service';
import { RoleFunctionalityService } from 'src/app/services/role-functionality.service';
import { Customer360Service } from '../../services/customer360.service';
import { loggedinUserDetails } from '../../../../common-use/commonInterface';
import { Subscription } from 'rxjs';
import { MessageService } from 'primeng/api';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-comment-panel',
  templateUrl: './comment-panel.component.html',
  styleUrls: ['./comment-panel.component.css']
})
export class CommentPanelComponent implements OnInit, OnDestroy {
  @Input() data: any;
  @Output() clickSubmitButton = new EventEmitter<boolean>();
  @Input() custId: string;
  @Input() cdd: boolean;
  audit = environment.audit;

  commentForm: FormGroup = new FormGroup({
    comments: new FormControl(null),
    userId: new FormControl(null)
  })
  sub: Subscription;
  employeeList: any = []
  loggedinUserDetails: loggedinUserDetails = {
    userName: '',
    roleName: '',
    userId: '',
    roleId: ''
  }
  unsub: Subscription
  @Output() refreshCddData = new EventEmitter<boolean>();

  auditedBy: boolean = environment.audit;


  constructor(private service: Customer360Service, private commonService: CommonService, private roleService: RoleFunctionalityService,
    public forms: CddForms, private messageService: MessageService) {

    this.sub = this.service.getSaveData().subscribe((res: any) => {
      this.onSubmitSaveCddData(res);

    })
    this.unsub = this.roleService.logedInUserInfo.subscribe((res: loggedinUserDetails) => {
      if (res.userId) {
        this.loggedinUserDetails = res
        this.getEmployeeList()
      }
    })
  }
  ngOnDestroy(): void {
    this.sub.unsubscribe()
    this.unsub.unsubscribe();
  }
  ngOnInit(): void {
  }

  getEmployeeList() {
    this.employeeList = []
    this.service.getEmployeeListExceptEmpId(this.loggedinUserDetails.userId).subscribe((res: any) => {
      let employeeList = res;
      employeeList.forEach((res: any) => {
        res.fullName = res.firstName + " " + res.lastName
      })
      this.employeeList = employeeList
    })
  }
  

  fillData(data: any) {
    if (Array.isArray(data) && data.length > 0) {
      data.forEach((element: any) => {
        try {
          if (this.commentForm.value.comments == null) {
            element.comment = ""
          }
          else element.comment = this.commentForm.value.comments;
        }
        catch (error) {
          element.comment = ""

        }
        try {
          element.createdBy = this.loggedinUserDetails.userId;
        } catch (error) {
          element.createdBy = ''
        }
        try {
          if (!this.auditedBy) {
            element.auditedBy = this.loggedinUserDetails.userId;
            element.status = 'A';
          } else {
            element.auditedBy = this.loggedinUserDetails.userId;
            element.status = 'P';
          }
        } catch (error) {
          element.auditedBy = ''
          element.status = 'P';

        }
      });
      return true
    }
    else return false
  }

  onSubmitSaveCddData(data: any) {
    let conditionCheck: boolean = false
    setTimeout(() => {
      conditionCheck = this.fillData(data);
      if (conditionCheck) {
        console.log(data)
        this.service.onCommnetSubmit(data).subscribe((res: any) => {
          if (res == 'Success') {
            if(this.audit){
              this.messageService.add({ severity: 'info', summary: 'Success', detail: 'Your Data has been saved for review.' });
            }else{
              this.messageService.add({ severity: 'info', summary: 'Success', detail: 'Your Data has been saved' });
            }
            this.refreshCddData.emit(true)
          }
        })

      }

    }, 500);



  }

  onSubmit() {
    this.clickSubmitButton.emit(true);
  }

  downloadCddReport() {
    let uId2: any = sessionStorage.getItem("userId")
    let rId2: any = sessionStorage.getItem("roleId")
    this.commonService.getToken(uId2, rId2).then((res: any) => {
      this.service.downloadCddReport(this.custId, this.forms.configFile, res.userId)
    })

  }

}
