import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Customer360RoutingModule } from './customer360-routing.module';
import { MainPageComponent } from './pages/main-page/main-page.component';
import { ViewCustomerComponent } from './pages/view-customer/view-customer.component';
import { ChartModule } from 'primeng/chart';
import { CommonUseModule } from 'src/app/common-use/common-use.module';
import { TransactionProfileComponent } from './pages/transaction-profile/transaction-profile.component';
import { RiskRatingComponent } from './pages/risk-rating/risk-rating.component';
import { SanctionsComponent } from './pages/sanctions/sanctions.component';
import { CustomerRiskRatingReportComponent } from './pages/customer-risk-rating-report/customer-risk-rating-report.component';
import { CddStatusReportComponent } from './pages/cdd-status-report/cdd-status-report.component';
import { HistoryViewComponent } from './pages/history-view/history-view.component';
import { SameNameCustomersComponent } from './pages/same-name-customers/same-name-customers.component';
import { CustomerRiskRatingCustomerDetailsComponent } from './pages/customer-risk-rating-customer-details/customer-risk-ratingd-customer-details.component';
import { CustomerSearchPanelComponent } from './pages/customer-search-panel/customer-search-panel.component';
import { AuthGuard } from 'src/app/services/auth.gaurd';
import { CddDataRequirementsComponent } from './pages/cdd-data-requirements/cdd-data-requirements.component';

@NgModule({
  declarations: [
    ViewCustomerComponent,
    MainPageComponent,
    TransactionProfileComponent,
    RiskRatingComponent,
    SanctionsComponent,
    CustomerRiskRatingReportComponent,
    CddStatusReportComponent,
    HistoryViewComponent,
    SameNameCustomersComponent,
    CustomerRiskRatingCustomerDetailsComponent,
    CustomerSearchPanelComponent,
    CddDataRequirementsComponent
  ],
  imports: [
    CommonModule,
    Customer360RoutingModule,
    ChartModule,
    CommonUseModule,

  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers:[AuthGuard]
})
export class Customer360Module { }

