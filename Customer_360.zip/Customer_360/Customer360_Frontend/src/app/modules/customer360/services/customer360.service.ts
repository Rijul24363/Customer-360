import { Injectable } from '@angular/core';
import { Observable, ReplaySubject, Subject } from 'rxjs';
import { HttpService } from '../../../services/http.service';
import { HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ViewConstantUrl, CddConstantUrl, TransactionProfileConstantUrl, RiskRatingConstantUrl, SanctionConstantUrl, SaveConstantUrl, HistoryViewConstantUrl, MainPageConstantUrl, CustomerListConstantUrl, CommonUserUrl, PDFUrl } from '../../../common-use/constantUrl';
import { SaveData } from '../../../common-use/commonInterface';
import { DatePipe } from '@angular/common';
export interface loginSession {
  custType: any,
  customerId: any,
  fullName: any,
  panNo: any
}
@Injectable({
  providedIn: 'root'
})
export class Customer360Service {
  selectedCustomerData: any;
  hideObs = new Subject<any>
  sendAccountId = new Subject<any>
  saveData = new Subject<any>
  datePipe: any = new DatePipe('en-US')

  constructor(private httpService: HttpService) { }

  customerSearch(obj: any) {    
      let params = new HttpParams();
      if (obj.custType)
        params = params.append('custType', obj.custType);
      if (obj.custID)
        params = params.append('custID', obj.custID);
      if (obj.custName)
        params = params.append('custName', obj.custName);
      if (obj.panNo)
        params = params.append('panNo', obj.panNo);
      var url = environment.apiUrl + ViewConstantUrl.CUSTOMER_SEARCH;
      return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getEmployeeListExceptEmpId(userId: any) {
    let url = environment.apiUrl + ViewConstantUrl.GET_EMPLOYEE_LIST_EXCEPT_EMP_ID;
    let params = new HttpParams();
    params = params.append('userId', userId);
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getCustomerDetails(custID: any) {
    let url = environment.apiUrl + ViewConstantUrl.GET_CUSTOMER_DETAILS_FOR_VIEW;
    let params = new HttpParams();
    params = params.append('custID', custID);
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getCustomerDetailsBaseOnCustId(custID: string) {
    let params = new HttpParams();
    params = params.append('custID', custID);
    var url = environment.apiUrl + CddConstantUrl.GET_CUSTOMER_DETAILS_FOR_CDD;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }


  getTransactionDetailsBasedOnChannels(custId:any,startDate: any, endDate: any,accountId:any) {
    let params = new HttpParams();
    params = params.append('custId', custId);
    params = params.append('startDate', startDate);
    params = params.append('endDate', endDate);
    params = params.append('accountId', accountId);
    var url = environment.apiUrl + TransactionProfileConstantUrl.TRANSACTION_DETAILS;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }
  getAccountListByCustomerId(custID: string) {
    let params = new HttpParams();
    params = params.append('customerId', custID);
    var url = environment.apiUrl + CddConstantUrl.GET_ACCOUNT_LIST_BY_CUSTOMER_ID;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  setHideAccountPanel(custID: any,byDefualtSelected:boolean,show:boolean) {
    this.getAccountListByCustomerId(custID).subscribe((res: any) => {
      this.hideObs.next({ "show": show, "accountList": res ,"selectedId":byDefualtSelected});
    })
  }
  getHideAccountPanel(): Observable<any> {
    return this.hideObs;
  }

  setAccountID(accId: any) {
    this.sendAccountId.next(accId);
  }
  getAccountID(): Observable<any> {
    return this.sendAccountId;
  }

  getAccountDetailsByCustIdAndAddId(custID: string, accId: any) {
    let params = new HttpParams();
    params = params.append('customerId', custID);
    params = params.append("accountId", accId)
    var url = environment.apiUrl + CddConstantUrl.GET_ACCOUNT_DETAILS_BY_CUSTID_AND_ACC_ID;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getCddDataBasedOnAccountId(custID: string, accId: any) {
    let params = new HttpParams();
    params = params.append('customerId', custID);
    params = params.append("accountId", accId)
    var url = environment.apiUrl + CddConstantUrl.GET_CDD_DATA_BASED_ON_ACCOUNTID;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getRiskIndicatorData() {
    let params = new HttpParams();
    var url = environment.apiUrl + RiskRatingConstantUrl.GET_RISK_INDICATOR_DATA;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getComputationInfo(custID: string, accId: any, startDate: any, endDate: any) {
    let params = new HttpParams();
    params = params.append('customerId', custID);
    params = params.append("accountId", accId)
    params = params.append("startDate", startDate)
    params = params.append("endDate", endDate)
    var url = environment.apiUrl + RiskRatingConstantUrl.GET_COMPUTATION_INFO;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }
  getSanctionListInfo(custID: string, accId: any, startDate: any, endDate: any) {
    let params = new HttpParams();
    params = params.append('customerId', custID);
    params = params.append("accountId", accId)
    params = params.append("startDate", startDate)
    params = params.append("endDate", endDate)
    var url = environment.apiUrl + SanctionConstantUrl.GET_SANCTION_LIST_INFO;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }
   onCommnetSubmit(saveData: any) {
    console.log("Service",saveData)
    var url = environment.apiUrl + SaveConstantUrl.SAVE_INFO;
    return this.httpService.decryptDataResponse(this.httpService.postMethod(url, saveData));
  }

  getHistoryViewInfo(custID: string, accId: any, startDate: any, endDate: any) {
    let params = new HttpParams();
    params = params.append('customerId', custID);
    params = params.append("accountId", accId)
    params = params.append("startDate", startDate)
    params = params.append("endDate", endDate)
    var url = environment.apiUrl + HistoryViewConstantUrl.GET_HISTORY_VIEW_INFO;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getRiskDisrtibution() {
    let params = new HttpParams();
    var url = environment.apiUrl + MainPageConstantUrl.GET_RISK_DISTRIBUTION;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  setSaveData(data: any) {
    this.saveData.next(data);
  }
  getSaveData(): Observable<any> {
    return this.saveData;
  }
  getCrrData(crr:any,startFrom:number,dtInputFields:any) {
    let params = new HttpParams();
    params =  params.append("crr",crr)
    params =  params.append("startFrom",startFrom)
    if(dtInputFields)
      params=params.append("dtInputFields",dtInputFields);
    var url = environment.apiUrl + CustomerListConstantUrl.GET_CRR_DATA
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getCddCount() {
    let params = new HttpParams();
    var url = environment.apiUrl + MainPageConstantUrl.GET_CDD_COUNT
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }


  getEnumsData(){
    let params = new HttpParams();
    var url = environment.apiUrl + CommonUserUrl.GET_ENUM;
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params))
  }

  downloadCddReport(custId:any,configFile:any,userId:any){
    let date=new Date();
    let latest_date =this.datePipe.transform(date, 'yyyy-MM-dd');
    let data = {"custID": custId,"configFile":configFile,"userId":userId}
    var url = environment.apiUrl + PDFUrl.Download_CDD_Report;
    return this.httpService.postMethodPdf(url, data).subscribe((response:any)=>{
      var binaryData = [];
      binaryData.push(response);
      var url = window.URL.createObjectURL(new Blob(binaryData, {type: "application/pdf"}));
      var a = document.createElement('a');
      document.body.appendChild(a);
      a.setAttribute('style', 'display: none');
      a.setAttribute('target', 'blank');
      a.href = url;
      a.download = "CDD_Report_"+custId+"_"+latest_date+".pdf";
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    })
  }

  getCddStatus(row:any,dtInputFields:any) {
    let params = new HttpParams();
    params=params.append("startFrom",row);
    if(dtInputFields)
      params=params.append("dtInputFields",dtInputFields);
    var url = environment.apiUrl + MainPageConstantUrl.GET_CDD_STATUS
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }
}
