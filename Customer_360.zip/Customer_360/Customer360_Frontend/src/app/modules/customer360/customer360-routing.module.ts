import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CddStatusReportComponent } from './pages/cdd-status-report/cdd-status-report.component';
import { CustomerRiskRatingCustomerDetailsComponent } from './pages/customer-risk-rating-customer-details/customer-risk-ratingd-customer-details.component';
import { CustomerRiskRatingReportComponent } from './pages/customer-risk-rating-report/customer-risk-rating-report.component';
import { HistoryViewComponent } from './pages/history-view/history-view.component';
import { MainPageComponent } from './pages/main-page/main-page.component';
import { RiskRatingComponent } from './pages/risk-rating/risk-rating.component';
import { SameNameCustomersComponent } from './pages/same-name-customers/same-name-customers.component';
import { SanctionsComponent } from './pages/sanctions/sanctions.component';
import { TransactionProfileComponent } from './pages/transaction-profile/transaction-profile.component';
import { ViewCustomerComponent } from './pages/view-customer/view-customer.component';
import { CustomerSearchPanelComponent } from './pages/customer-search-panel/customer-search-panel.component';
import { AuthGuard } from '../../services/auth.gaurd';
import { CddDataRequirementsComponent } from './pages/cdd-data-requirements/cdd-data-requirements.component';

const routes: Routes = [
  {path:"", component:CustomerSearchPanelComponent,children: [
    {path:"", component:MainPageComponent, canActivate: [AuthGuard]},
    {path:"view", component:ViewCustomerComponent, canActivate: [AuthGuard] },
    {path:"transaction_profile", component:TransactionProfileComponent, canActivate: [AuthGuard]},
    {path:"risk_rating", component:RiskRatingComponent, canActivate: [AuthGuard]},
    {path:"sanctions", component:SanctionsComponent, canActivate: [AuthGuard]},
    {path:"customer_risk_rating_report", component:CustomerRiskRatingReportComponent, canActivate: [AuthGuard]},
    {path:"cdd_status_report", component:CddStatusReportComponent, canActivate: [AuthGuard]},
    {path:"same_name_customer", component:SameNameCustomersComponent, canActivate: [AuthGuard]},
    {path:"history_view", component:HistoryViewComponent, canActivate: [AuthGuard]},
    {path:"customer_risk_rating_customer_details", component:CustomerRiskRatingCustomerDetailsComponent, canActivate: [AuthGuard]},
    {path:"cdd-data-requirements", component:CddDataRequirementsComponent, canActivate: [AuthGuard]},
    {path:"cdd", loadChildren: () => import('./cdd-module/cdd.module').then(m => m.CddModule)},

  ]},




];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Customer360RoutingModule { }
