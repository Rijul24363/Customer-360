import { APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SideMenuComponent } from './menus/side-menu/side-menu.component';
import { TopMenuComponent } from './menus/top-menu/top-menu.component';
import { SidebarModule } from 'primeng/sidebar';
import { PanelMenuModule } from 'primeng/panelmenu';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LoaderInterceptorComponent } from './loader-interceptor/loader-interceptor.component';
import { AvatarModule } from 'primeng/avatar';
import { InterceptorService } from './loader-interceptor/interceptor.service';
import { FieldsConfig } from './services/fields.config';
import { ToastModule } from 'primeng/toast';
import { ConfirmationService, MessageService } from 'primeng/api';

export function initializeApp(appConfig: FieldsConfig) {
  return () => appConfig.load();
}
@NgModule({
  declarations: [
    AppComponent,
    SideMenuComponent,
    TopMenuComponent,
    LoaderInterceptorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SidebarModule,
    PanelMenuModule,
    HttpClientModule,
    AvatarModule,
    ToastModule
  ],
  providers: [
    FieldsConfig,
    MessageService,
    ConfirmationService,
    { provide: APP_INITIALIZER,
      useFactory: initializeApp,
      deps: [FieldsConfig], multi: true },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
   },
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class AppModule { }
