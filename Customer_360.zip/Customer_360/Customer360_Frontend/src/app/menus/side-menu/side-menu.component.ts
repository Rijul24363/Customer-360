import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { CommonService } from 'src/app/common-use/common.service';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css']
})
export class SideMenuComponent {
  @Input() sidebarVisible: boolean = false;
  @Output() sidebarVisibleEmit = new EventEmitter<boolean>();
  items: MenuItem[]
  constructor(private commonService:CommonService) {
    this.items = [
      {
        label: 'Customer360',
        icon: 'pi pi-fw pi-file',
      },
      // {
      //   label: 'Bi Dashboard',
      //   icon: 'pi pi-fw pi-pencil'
      // },
    ]

    commonService.getHideCustomerSubMenu().subscribe((res:boolean)=>{      
      if(res){
        this.items = [
          {
            label: 'Customer360',
            icon: 'pi pi-fw pi-file',
            items: [
              {
                label: 'View',
                icon: 'pi pi-fw pi-external-link',
                routerLink: "pages/view",
                title:"Customer360",
                command: (event) => { this.getMenuDetails(event); }
              },
              {
                label: 'CDD',
                icon: 'pi pi-fw pi-external-link',
                routerLink: "pages/cdd",
                title:"Customer360",
                command: (event) => { this.getMenuDetails(event); }
              },
              {
                label: 'Transaction Profile',
                icon: 'pi pi-fw pi-external-link',
                routerLink: "pages/transaction_profile",
                title:"Customer360",
                command: (event) => { this.getMenuDetails(event); }
              },
              {
                label: 'Risk Rating',
                icon: 'pi pi-fw pi-external-link',
                routerLink: "pages/risk_rating",
                title:"Customer360",
                command: (event) => { this.getMenuDetails(event); }
              },
              // {
              //   label: 'Customer Risk Rating Report',
              //   icon: 'pi pi-fw pi-external-link',
              //   routerLink: "pages/customer_risk_rating_report",
              //   title:"Customer360",
              //   command: (event) => { this.getMenuDetails(event); }
              // },
              // {
              //   label: 'CDD Status Report',
              //   icon: 'pi pi-fw pi-external-link',
              //   routerLink: "pages/cdd_status_report",
              //   title:"Customer360",
              //   command: (event) => { this.getMenuDetails(event); }
              // },
              {
                label: 'History View',
                icon: 'pi pi-fw pi-external-link',
                routerLink: "pages/history_view",
                title:"Customer360",
                command: (event) => { this.getMenuDetails(event); }
              },
              {
                label: 'Sanctions',
                icon: 'pi pi-fw pi-external-link',
                routerLink: "pages/sanctions",
                title:"Customer360",
                command: (event) => { this.getMenuDetails(event); }
              },
            ]
          },
          // {
          //   label: 'Bi Dashboard',
          //   icon: 'pi pi-fw pi-pencil'
          // },
        ]
      }else{
        this.items = [
          {
            label: 'Customer360',
            icon: 'pi pi-fw pi-file',
          },
          // {
          //   label: 'Bi Dashboard',
          //   icon: 'pi pi-fw pi-pencil'
          // },
        ]
      }
    })
  }

  closeSideBar() {
    this.sidebarVisibleEmit.emit(false);
  }

  getMenuDetails(event:any){
    this.closeSideBar()
    this.commonService.setBreadcrumbMenu(event.item)
  }
}