import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { loggedinUserDetails } from 'src/app/common-use/commonInterface';
import { EncryptDecryptService } from 'src/app/services/encrypt-decrypt-service';
import { RoleFunctionalityService } from 'src/app/services/role-functionality.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css']
})

export class TopMenuComponent implements OnDestroy {
  sidebarVisible: boolean = false;
  today: number = Date.now();
  loggedinUserDetails:loggedinUserDetails={
    userName: '',
    roleName: '',
    userId: '',
    roleId: ''
  }
  unsub:Subscription
  constructor(private roleService:RoleFunctionalityService,private encryptS:EncryptDecryptService) {
    setInterval(() => { this.today = Date.now() }, 1);
    this.unsub= this.roleService.logedInUserInfo.subscribe((res:any)=>{
      this.loggedinUserDetails.userName=res.userName;
      this.loggedinUserDetails.roleName=res.roleName;
    })   
  }
  ngOnDestroy(): void {
    this.unsub.unsubscribe()
  }

  backToCF(){
    const form = document.createElement('form');
    var userName = document.createElement("input"); 
    var roleId = document.createElement("input");  

    form.method = 'POST';
    form.action = environment.returnToCf;

    
    userName.value=this.encryptS.encryptUsingAES(this.loggedinUserDetails.userName);
    userName.name="userName";
    form.appendChild(userName); 

    roleId.value=this.loggedinUserDetails.roleName;
    roleId.name="roleId";
    form.appendChild(roleId); 
    userName.hidden=true
    roleId.hidden=true
    document.body.appendChild(form);    
    form.submit();
    sessionStorage.removeItem('userId')
    sessionStorage.removeItem('roleId')
    sessionStorage.removeItem('selectedCustDataOb')

  }
}
