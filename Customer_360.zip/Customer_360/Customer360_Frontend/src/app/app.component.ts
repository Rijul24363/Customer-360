import { Component, HostListener, OnInit } from '@angular/core';
import { RoleFunctionalityService } from './services/role-functionality.service';
import { CommonService } from './common-use/common.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { loggedinUserDetails } from './common-use/commonInterface';
import { EncryptDecryptService } from './services/encrypt-decrypt-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Customer360';
  userId: boolean;
  roleId: boolean;
  @HostListener('window:beforeunload', [ '$event' ])
   beforeUnloadHandler(event:any) {
    // sessionStorage.clear()
   }
  constructor(private roleService: RoleFunctionalityService, private commonService: CommonService,
    private route: ActivatedRoute,private aesAlgo:EncryptDecryptService,
    private router: Router) {
      commonService.getEnumsData()

  }

  ngOnInit(): void {
    this.route.queryParams.subscribe((event: any) => {
      let uId: any = event.utoken
      let rId: any = event.rtoken
      let customerId: any = event.customerId
      try {
        environment.returnToCf=this.aesAlgo.decryptUsingAES(event.returnUrl)
      } catch (error) {
      }
      // sessionStorage.setItem("userId","0y9feFB8cmLEzMff1p0Krw==")
      // sessionStorage.setItem("roleId","U6ilaf8z3sVcXoIO2E4ylQ==")
      let uId2: any = sessionStorage.getItem("userId")
      let rId2: any = sessionStorage.getItem("roleId")
      
      if (uId && rId) {
        this.commonService.getToken(uId, rId).then((res: any) => {
          this.getUserDetails(res.userId, res.roleId, "param", uId, rId,customerId)
        })

      } else if (uId2 && rId2) {
        this.commonService.getToken(uId2, rId2).then((res: any) => {
          this.getUserDetails(res.userId, res.roleId, "session", uId2, rId2)
        })
      }

    },
    (error:any)=>{
      console.log(error);
      
    });

  }

  getUserDetails(userId: any, roleId: any, userfor: any, encryptedUId: any, encryRoleId: any,customerId?:string) {

    this.roleService.getLogInUserDetails(userId, roleId).subscribe((res: any) => {
      let userName = res.userName;
      let roleName = res.roleName;
      if (!(userName && roleName)) {
        window.location.href = environment.cfLoginUrl
      } else {
        if (userfor == "param") {
          this.userId = true
          this.roleId = true
          this.roleService.mappingRolePage(userId);
          if (!sessionStorage.getItem("userId"))
            sessionStorage.setItem("userId", encryptedUId)

          if (!sessionStorage.getItem("roleId"))
            sessionStorage.setItem("roleId", encryRoleId)

          if(customerId){
            const navigationExtras = {
                queryParams: {
                  customerId: customerId, // Replace 'value1' with your parameter value                 
                },
              };
            this.router.navigate(['/pages'],navigationExtras)
          }else{
            this.router.navigate(['/pages'])
          }          
        } else if (userfor == "session") {
          this.userId = true
          this.roleId = true
          this.roleService.mappingRolePage(userId);
        }
        let logInDat:loggedinUserDetails={
          userName:res.userName,
          roleName:res.roleName,
          userId:userId,
          roleId:roleId 
        }
        this.roleService._logedInUserInfo.next(logInDat);
      }
    },
      (error: any) => {
        window.location.href = environment.cfLoginUrl
      });
  }

}
