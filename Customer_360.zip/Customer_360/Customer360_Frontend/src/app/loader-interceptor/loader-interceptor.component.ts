import { Component } from '@angular/core';
import { LoaderInterceptorService } from './loader-interceptor.service';
import { NavigationCancel, NavigationEnd, NavigationError, RouteConfigLoadEnd, RouteConfigLoadStart, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-loader-interceptor',
  templateUrl: './loader-interceptor.component.html',
  styleUrls: ['./loader-interceptor.component.css']
})
export class LoaderInterceptorComponent {
  isRoutingLoader:boolean=false
  httpLoader:boolean=false

  constructor(private loaderService: LoaderInterceptorService, private route:Router,private messageService: MessageService) {

    route.events.subscribe(
      (event) =>{
        if(event instanceof RouteConfigLoadStart)
        this.isRoutingLoader=true
        else if(event instanceof RouteConfigLoadEnd)
          this.isRoutingLoader=false
        else if(event instanceof NavigationEnd)
          this.isRoutingLoader=false
        else if(event instanceof NavigationCancel)
          this.isRoutingLoader=false
        else if(event instanceof NavigationError)
          this.isRoutingLoader=false  

      }
    )

    this.loaderService.isLoading.subscribe((v) => {
      this.httpLoader = v;
    });
    this.loaderService.errorShowing.subscribe((v) => {
      if(v){
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Server Error' });
      }
    });
  }


}
