import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, } from 'rxjs';
import { LoaderInterceptorService } from './loader-interceptor.service';
import { EncryptDecryptService } from '../services/encrypt-decrypt-service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {
  private requests: HttpRequest<any>[] = [];

  constructor(private service:LoaderInterceptorService,private encryptDecryptService: EncryptDecryptService) { }
  removeRequest(req: HttpRequest<any>) {
    const i = this.requests.indexOf(req);
    if (i >= 0) {
      this.requests.splice(i, 1);
    }
    this.service.isLoading.next(this.requests.length > 0);
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({
      setHeaders: { Authorization: `Bearer ${this.encryptDecryptService.encryptUsingAES(environment.tokenfForApi)}` }
    });
    this.service.errorShowing.next(false);
    this.requests.push(req);

    this.service.isLoading.next(true);

      // if (req.method == "GET") {
      //     if (req.url.indexOf("?") > 0) {
      //         let encriptURL = req.url.substr(0, req.url.indexOf("?") + 1) + this.encryptDecryptService.encryptUsingAES256(req.url.substr(req.url.indexOf("?") + 1, req.url.length));
      //         const cloneReq = req.clone({
      //             url: encriptURL
      //         });
      //         return next.handle(cloneReq);
      //     }
      //     return next.handle(req);
      // } else if (req.method == "POST") {
      //     if (req.body || req.body.length > 0) {
      //         const cloneReq = req.clone({
      //             body: this.encryptDecryptService.encryptUsingAES256(req.body)
      //         });
      //         return next.handle(cloneReq);
      //     }
      //     let data = req.body as FormData;
      //     return next.handle(req);
      // }

    return Observable.create((observer:any) => {
      const subscription = next.handle(req)
        .subscribe(
          event => {

            if (event instanceof HttpResponse) {
              this.removeRequest(req);
              observer.next(event);
            }
          },
          err => {
            // alert('error' + err);
            this.removeRequest(req);
            this.service.errorShowing.next(true);
            observer.error(err);
          },
          () => {
            this.removeRequest(req);
            observer.complete();
          });
      // remove request from queue when cancelled
      return () => {
        this.removeRequest(req);
        subscription.unsubscribe();
      };
    });
  }
}
