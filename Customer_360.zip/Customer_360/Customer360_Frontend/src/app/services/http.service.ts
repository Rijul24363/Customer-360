import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, map } from 'rxjs';
import { EncryptDecryptService } from './encrypt-decrypt-service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  headers: HttpHeaders = new HttpHeaders({
    'content-type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  })

  constructor(private http: HttpClient, private ciper: EncryptDecryptService) { }
  decryptDataResponse(url: any) {
    return Observable.create((observer: any) => {
      url.subscribe((res: any) => {
        if (environment.production) {
          observer.next(JSON.parse(this.ciper.decryptUsingAES(res.data)));
        } else {
          observer.next(res.data);
        }

      }, (error: Error) => {
        console.log(error);
        observer.error(error);

      }, () => {
        observer.complete();
      }
      );
    })
  }
  getMethod(url: string, params: HttpParams): Observable<any> {
    return this.http.get(url, { params: params, headers: this.headers });
  }

  postMethod(url: string, body: any): Observable<any> {
    return this.http.post(url, body, { headers: this.headers });
  }

  postMethodPdf(url: string, body: any): Observable<any> {
    let headerOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/pdf',
    });
    let requestOptions = { headers: headerOptions, responseType: 'blob' as 'blob' };

    return this.http.post(url, body, requestOptions).pipe(map((res: any) => {
      return new Blob([res], {
        type: 'application/pdf'
      })
    }));
  }
}
