export interface IRoleConfig {
    CDD:{
        personal:boolean,
        entity:boolean,
        identification:boolean,
        address:boolean,
        account:boolean,
        revenue:boolean,
        family:boolean,
        nominee:boolean,
        beneficiary:boolean,
        signatories:boolean,
        directors:boolean,
        other:boolean,
    }
}
