import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IFieldsConfig } from "./fields-config.model";
import { environment } from '../../environments/environment';

@Injectable()
export class FieldsConfig {
    static appConfigData: IFieldsConfig;
    constructor(private http: HttpClient) {}
    load() {
        const jsonFile = environment.fieldsConfigPath;
        return new Promise<void>((resolve, reject) => {
            this.http.get(jsonFile).toPromise().then((response:any) => {
                FieldsConfig.appConfigData = <IFieldsConfig>response;
               resolve();
            }).catch((response: any) => {                
               reject(`Could not load file '${jsonFile}': ${JSON.stringify(response)}`);
            });
        });
    }
}