import { Injectable } from '@angular/core';
import { UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard {

  constructor() { }
  canActivate():
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    let userId=sessionStorage.getItem("userId")
    let roleId=sessionStorage.getItem("roleId") 
    if(!userId || !roleId){    
      sessionStorage.clear()
      window.location.href = environment.cfLoginUrl;
      return false;
    }
    // logged in, so return true
    return true;
  }
}
