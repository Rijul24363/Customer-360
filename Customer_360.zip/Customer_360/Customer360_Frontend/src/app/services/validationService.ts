import { FormControl, ValidationErrors, Validators } from "@angular/forms";
import { ValidationInterface } from "../common-use/commonInterface";
import { DatePipe } from "@angular/common";

export class ValidationService {

  static validate(control: FormControl, validation: ValidationInterface): ValidationErrors | null {
    if (validation.minDate && validation.maxDate) {
      const selectedDate: Date = control.value;
      if (selectedDate && (selectedDate < validation.minDate || selectedDate > validation.maxDate)) {
        const datePipe: DatePipe = new DatePipe('en-US');
        let minDateString = datePipe.transform(validation.minDate, 'dd/MM/yyyy');
        let maxDateString = datePipe.transform(validation.maxDate, 'dd/MM/yyyy');
        return {
          error: `Selected date should be between ${minDateString} and ${maxDateString}.`
        };
      }
    }

    if (validation.require && control.value === null) {
      return { error: validation.errorMessage.requiredErrorMessage };
    }

    if (
      validation.regexPattern &&
      control.value !== null &&
      !validation.regexPattern.test(control.value)
    ) {
      return { error: validation.errorMessage.patternErrorMessage };
    }

    if (
      validation.minlength &&
      control.value !== null &&
      control.value.length < validation.minlength
    ) {
      return { error: validation.errorMessage.minLengthErrorMessage};
    }

    if (
      validation.maxlength &&
      control.value !== null &&
      control.value.length > validation.maxlength
    ) {
      return { error: validation.errorMessage.maxLengthErrorMessage };
    }

    return null;
  }

  // validateDateRange(control: FormControl, minDate: Date, maxDate: Date): ValidationErrors | null {
  //   const selectedDate: Date = control.value;

  //   if (selectedDate && (selectedDate < minDate || selectedDate > maxDate)) {
  //     const datePipe: DatePipe = new DatePipe('en-US');
  //     let minDateString = datePipe.transform(minDate, 'dd/MM/yyyy');
  //     let maxDateString = datePipe.transform(maxDate, 'dd/MM/yyyy');

  //     return {
  //       error: `Selected date should be between ${minDateString} and ${maxDateString}.`
  //     };
  //   }

  //   return null;
  // }



  // (control: FormControl) => this.validateDateRange(control,null,mull, new Date(2023, 0, 1), new Date(2023, 0, 1),)

}
