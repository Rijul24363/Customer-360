import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { RoleFunctionalityUrl } from '../common-use/constantUrl';
import { HttpParams } from '@angular/common/http';
import { HttpService } from './http.service';
import { IRoleConfig } from './role.interface';
import { BehaviorSubject, Subject } from 'rxjs';
import { loggedinUserDetails } from '../common-use/commonInterface';

interface getRoleRes{
  functionId:number,
  description:string,
  functionalityName:string,
  module:string,
  subModule:string
}
@Injectable({
  providedIn: 'root'
})
export class RoleFunctionalityService {
  roleWisePage:IRoleConfig={
    CDD: {
      personal: false,
      entity: false,
      identification: false,
      address: false,
      account: false,
      revenue: false,
      family: false,
      nominee: false,
      beneficiary: false,
      signatories: false,
      directors: false,
      other: false
    }
  }
  roleWisePageObs=new BehaviorSubject<IRoleConfig>(this.roleWisePage);
  public _logedInUserInfo=new BehaviorSubject<loggedinUserDetails>({
    userName:"",
    roleName:"",
    userId:"",
    roleId:""
  });
  public logedInUserInfo = this._logedInUserInfo.asObservable();
  constructor(private httpService:HttpService) { }

  mappingRolePage(userId:any){
    this.getRoleWisePageList(userId).subscribe((res:Array<getRoleRes>)=>{
      let getCddListData:Array<getRoleRes>=res.filter((res:getRoleRes)=> res.module == "Customer 360" && res.subModule=="CDD")
      getCddListData.forEach((res2:getRoleRes)=>{
        if(res2.functionalityName == "Personal"){
          this.roleWisePage.CDD.personal=true
        }
        else if(res2.functionalityName == "Entity"){
          this.roleWisePage.CDD.entity=true
        }
        else if(res2.functionalityName == "Identification"){
          this.roleWisePage.CDD.identification=true
        }
        else if(res2.functionalityName == "Address"){
          this.roleWisePage.CDD.address=true
        }
        else if(res2.functionalityName == "Account"){
          this.roleWisePage.CDD.account=true
        }
        else if(res2.functionalityName == "Revenue"){
          this.roleWisePage.CDD.revenue=true
        }
        else if(res2.functionalityName == "Family"){
          this.roleWisePage.CDD.family=true
        }
        else if(res2.functionalityName == "Nominee"){
          this.roleWisePage.CDD.nominee=true
        }
        else if(res2.functionalityName == "Beneficiary"){
          this.roleWisePage.CDD.beneficiary=true
        }
        else if(res2.functionalityName == "Signatories"){
          this.roleWisePage.CDD.signatories=true
        }
        else if(res2.functionalityName == "Directors"){
          this.roleWisePage.CDD.directors=true
        }
        else if(res2.functionalityName == "Other"){
          this.roleWisePage.CDD.other=true
        }
      })    
      // console.log(this.roleWisePage);
      
      this.roleWisePageObs.next(this.roleWisePage);
    })
  }

  getRoleWisePageList(userId: any) {
    let url = environment.apiUrl + RoleFunctionalityUrl.get_Role_Wise_Page_List;
    let params = new HttpParams();
    params = params.append('userId', userId);
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params));
  }

  getLogInUserDetails(userId: any, roleId:any) {
    let url = environment.apiUrl + RoleFunctionalityUrl.get_user_details;
    let params = new HttpParams();
    params = params.append('userId', userId);
    params = params.append('roleId', roleId);
    return this.httpService.decryptDataResponse(this.httpService.getMethod(url, params))
  }
  
}
