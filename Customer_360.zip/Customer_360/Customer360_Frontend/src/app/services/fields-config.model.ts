export interface IFieldsConfig {
    pages: {
        cddPage: {
            personalForm: {
                salutation: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                shortName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                age: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                lastName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                firstName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                middleName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                nationality: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                gender: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                residence: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                maritalStatus: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                educationLevel: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
            },
            entityForm: {
                fullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                shortName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfEstablismentAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfEstablismentBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                typeOfIndustry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                businessList: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                incorporationNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                incorporationDate: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                incorporatingBody: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                incorporatingCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                panNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                panIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                panIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            identificationForm: {
                identificationDocType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                identificationDocNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                identificationDocIssuedDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                identificationDocIssuedDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                idenificationDocIssuedBy: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                countryOfIssue: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                issueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                expiredDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                expiredDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            addressForm: {
                currentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                landLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentWardNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentLandlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                emailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                website: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentMnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
                parmanentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWardNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                landlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountId: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                mobileNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {},
                }
            },
            accountForm: {
                upperLimitOnLoanAccounts: {
                    visible: boolean,
                    editable: boolean,
                    error: {},
                },
                relatedPersonalType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                estimatedMonthlyIncome: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                estimatedAnnualIncome: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                estimatedAnnualTurnover: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountCurrency: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountStatusType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                purposeOfAccount: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountOpeningDate: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountAge: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountBranch: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                accountNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            revenueForm: {
                nameOfTheEmployer: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                designation: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                employerLineOfBusiness: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                title: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                workExperience: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                department: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                regularSourceOfIncome: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                sourceOfWealth: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                netWorth: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                panNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                employersContactNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                address: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                city: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                country: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                state: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                nameOfBusiness: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                typeOfBusiness: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                lineOfBusiness: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                contactNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                nameOfProvider: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                sourceOfIncomeOfTheProvider: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                status: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentMobileNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            familyForm: {
                motherName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                fatherName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                grandMotherName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                grandFatherName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                spouseName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                daughterFullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                sonFullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                daughterFullName2: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                sonFullName2: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            nomineeForm: {
                selectedDirector: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                fullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                relationship: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                contactNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tToleAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateBs: {
                    visible: true,
                    editable: boolean,
                    error: {}
                },
                pIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
                parmanentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentMobileNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
                pExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            beneficiaryForm: {
                fullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                relationship: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                contactNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tToleAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateBs: {
                    visible: true,
                    editable: boolean,
                    error: {}
                },
                pIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
                parmanentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentMobileNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            signatoriesForm: {
                fullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                relationship: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                contactNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tToleAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateBs: {
                    visible: true,
                    editable: boolean,
                    error: {}
                },
                pIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
                parmanentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentMobileNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            directorsForm: {
                fullName: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                relationship: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                contactNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                dateOfBirthBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdType: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tPrimaryIdNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssuseCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tToleAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tExpiryDateBs: {
                    visible: true,
                    editable: boolean,
                    error: {}
                },
                pIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                tIssueAuthority: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandlineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountry: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentHouseNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentzipCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
                parmanentDistrict: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentLandLineNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentGooglePlusCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentWard: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentMobileNumber: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentTole: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentState: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentEmailAddress: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                parmanentCountryCode: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateAd: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                pExpiryDateBs: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentProvince: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                currentmnVdcCity: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            },
            otherForm: {
                serviceAvailed: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                customerLiabilityReport: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                },
                otherReport: {
                    visible: boolean,
                    editable: boolean,
                    error: {}
                }
            }
        };
    };

    auditedBy: {
        audit: boolean,
        userId: []
    }

};