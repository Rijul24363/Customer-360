import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';

const routes: Routes = [
  {path:"",component:AppComponent},
  {path:"appLog",component:AppComponent},
  {path:"pages", loadChildren: () => import('./modules/customer360/customer360.module').then(m => m.Customer360Module)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
